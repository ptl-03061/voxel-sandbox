# Build the upgraded APK with no PC (GitHub Actions)

1. Create a GitHub account, then create a new repository (works in the phone browser).
2. Upload this source tree: Add file > Upload files. Zip the folder first on your phone
   (any file manager can zip), or upload the folder contents directly.
3. Open the repo > Actions tab > "Android build" > "Run workflow".
4. Wait ~10 minutes, then open the completed run and download the artifact
   "VoxelSandbox-upgraded-debug" - it contains the APK.
5. On the phone, allow your browser to install apps, then install the APK.

## What is in this upgrade
- Rope / chain / cable / spring physics with breakable joints (new Rope & Cut Rope & Weld tools)
- Machinery: generators, batteries, breakers, panels + conveyors, lifts, fans, press, powered doors
- Electricity: boolean power flow, explosion-tripped breakers, battery drain
- Structural stress system: repeated hits weaken voxels until they fail (cascading collapse)
- Fire system: spreading fire on flammable materials, smoke, burn-away collapse, budget-capped
- New materials: Ice, Snow, Ceramic
- Save system: versioned saves with persistent destruction (auto slot + API for UI slots)
- New ULTRA graphics preset
