# Voxel Sandbox — Expansion Master Plan ("Harbor Heights → Metropolitan")
**Version 0.1 — grounded in source audit of VoxelSandbox-source.zip (Nov 2026)**
**Base:** ~9,400 lines C++17, NativeActivity, OpenGL ES 3.0, AAudio, Jolt Physics, glm. Single map (128×32×128 m, 1687 chunks).

---

## 0. Ground rules (from brief, restated as engineering constraints)

1. **Nothing existing is removed or stubbed.** Every change is additive or a strict superset.
2. **One module per feature area**, behind the interfaces below. No feature reaches into another module's internals.
3. **Compile after every stage.** Stages are ordered so the game is always shippable.
4. **Presets are contracts, not suggestions.** LOW/MEDIUM/HIGH/ULTRA each define hard budgets (debris, NPCs, chunks, draw distance); the simulation must degrade gracefully, never silently.
5. **Saves are versioned from day one.** Save format v1 ships with Stage 1 even before most features exist.

---

## 1. Current architecture audit (what we're building on)

| Module | Files | Lines | Role | Expansion verdict |
|---|---|---|---|---|
| `core/` | Input, Settings, Jobs, Common | 366 | input abstraction, job pool, settings persistence | Extend: add action-map + haptic API; Settings gains per-preset overrides |
| `engine/` | Renderer, Textures, Particles, Audio | 1,523 | GLES3 renderer, procedural textures, particle pools, AAudio synth | Extend: renderer needs instancing pass upgrade, shadow map, UBO for lights; Audio needs material→sound table + reverb zones |
| `physics/` | PhysicsWorld | 256 | Jolt init, layers (STATIC/MOVING/DEBRIS/RAGDOLL/VEHICLE/KINEMATIC), contact events, raycast | Extend: add constraint manager, soft-body proxy layer, sensors; add layers SENSOR, TRIGGER only if collision matrix needs it |
| `destruction/` | VoxelWorld, Mesher, VoxelObject, Destruction | 1,367 | chunked voxel storage, greedy mesher w/ AO + LOD, 19 materials, sphere damage, fragment carving, flood-fill support collapse, debris budget | **Core asset.** Extend: material table → data-driven; stress/weakness field per chunk; save/load of damage masks |
| `gameplay/` | Sandbox, Player, Vehicle, Npc, Props, Interactions | 2,503 | tools, character controller, 5 vehicles, crash dummies, props | Extend: Vehicle gets def table + parts; Npc gets brain/preset split; Interactions becomes generic "Usable" registry |
| `world/` | MapBuilder, Environment | 994 | procedural city gen, day/night, weather | Extend: MapBuilder → district graph + streaming; Environment → climate zones |
| `ui/` | UI | 902 | ImGui-based menus, touch controls | Extend: screen/stack system, browser panels, editor overlays |
| `platform/` | android_main, desktop_main | 881 | NativeActivity glue, EGL | Mostly untouched; add thermal/battery listeners, Vulkan decision point |
| `Game` | Game.cpp/h | 612 | orchestrator, fixed-step sim, camera, state machine | Gains: mode manager, save manager, scenario runner |

**Key strengths to preserve:** the flood-fill structural collapse is genuinely good (most voxel games don't have it); the debris budget with sleeping/distance culling is exactly the right pattern for mobile; materials already carry hardness/density/sound — the material simulation section is an *extension* of an existing table, not a new system.

**Key risks found in audit:**
- World is a fixed 128×32×128 array. Every expansion feature (districts, subway, sewers) depends on replacing this with a streamed, unbounded world — **this is Stage 0 and nothing else starts before it's done.**
- MapBuilder generates one city procedurally in code. 30 new locations hand-coded in C++ will not scale → move location definitions to data (JSON), MapBuilder becomes an interpreter + keeps procedural filler.
- UI is one 902-line file; browsers (object/vehicle/NPC), editors and mod manager need a panel framework or UI becomes the bottleneck.

---

## 2. Target module map (all new code lives here)

```
src/
  world/        MapBuilder (interpreter), DistrictGen/, Terrain/, Streaming/   [new: streaming, terrain]
  destruction/  + StressField, MaterialDB (data-driven), DamageStore            [new: persistence]
  physics/      + Constraints (rope/chain/spring/hinge), Sensors, TimeControl    [new]
  gameplay/     + Machinery, Electricity, FireSim, WaterSim, Character (replaces Npc internals additively)
  vehicles/     VehicleDefs + parts (split from Vehicle.cpp)                     [new dir]
  npc/          Brain, Schedules, Navigation                                     [new dir, wraps Npc]
  modes/        FreeSandbox, Challenges, Missions, Scenario, Benchmark           [new dir]
  editor/       MapEditor, ObjectEditor                                          [new dir]
  mods/         ModManager, Schema validation                                    [new dir]
  save/         SaveManager (versioned slots, autosave, corruption guard)        [new dir]
  fx/           Explosions, FireFx, Smoke, Scorch decals                         [new dir, wraps Particles]
  ui/           + Panel framework, browsers, HUD editor
```

Dependency rule: `modes/`, `editor/`, `mods/` may depend on everything; `world/` and `destruction/` depend on nothing above `engine/` and `physics/`.

---

## 3. Staged roadmap (each stage = compilable, testable, shippable)

> Ordering principle: **foundation → systems that others depend on → content → modes.** Content (districts, vehicles) is cheap once the systems exist; systems are expensive. Brief sections in brackets.

### Stage 0 — World streaming & data-driven maps [§1, §16 foundation, §22]
Unbounded world: chunk hash map replacing fixed array; district descriptors in JSON; stream in/out by distance with a destroyed-state overlay (DamageStore). Terrain heightmap for mountain/forest/farmland/quarry belts. **Exit test:** 1 km² world, walk/drive across district borders at 60 fps on MEDIUM, destruction persists across chunk reload.
*This is the single largest technical risk in the entire plan; it is deliberately first.*

### Stage 1 — Save/load + settings profiles [§18, §22 presets]
SaveManager with versioned slots (v1 schema below), autosave, corruption quarantine. Formalize LOW/MEDIUM/HIGH/ULTRA budgets in Settings. Desktop test harness gets save/load round-trip test.
*Everything after this can persist state, so it's second.*

### Stage 2 — Material simulation v2 [§2]
Move the 19-material table to JSON (hardness, density, fracture pattern, sound set, flammability, conductivity). Add the 13 brief materials as entries. Add per-chunk weakness accumulation (progressive structural weakening) feeding the existing flood-fill — small change, big payoff. Stress visualization = debug overlay tinting weakness field.

### Stage 3 — Structural destruction v2 [§2]
Multi-layer walls (already implicit in voxel stack — expose it), destructible pillars/roofs/bridges via weakness field (no new physics needed — the support flood-fill already handles arbitrary geometry), cascading failure by re-queuing support checks when a collapse lands. Debris: persistent piles (merge sleeping debris into static "pile" bodies after N seconds).

### Stage 4 — Constraints & advanced physics [§3]
Constraints manager on Jolt (SixDOF, hinge, slider, spring, breakable constraints w/ force limit → structural failure ties into Stage 3). Rope/chain/cable as chained bodies with distance constraints. Buoyancy: sampled-volume approximation per body vs water plane per district. Wind: global vector + per-district gusts; applies to particles, cloth proxies, trees, ragdolls. Time control: the Game already has `timeScale` — expose pause/step/slow-mo as first-class UI (Physics Laboratory mode is 90% done at this point).

### Stage 5 — Electricity + machinery [§11, §12]
This is the recommended **first vertical slice** (self-contained, high visibility, exercises physics + UI + save):
- `PowerGrid`: nodes (generators, batteries, panels) and edges (cables). Simplified: Boolean/level flow, not circuit simulation. Power state propagates on change events only.
- `Machinery`: conveyors (kinematic surface velocity), hydraulic lifts (slider + motor), rotating fans, industrial presses (kinematic crusher w/ damageAt on contact), garage lifts, automated doors, pressure plates (already exists for vault — generalize!), circuit breakers, control panels.
- All machinery is data-spawned from JSON, so the map editor gets it for free in Stage 8.

### Stage 6 — Fire & water [§9, §10]
FireSim: cellular automaton over voxel materials (flammability from Stage 2 table) + heat field; stylized, opt-in quality slider. Emits smoke via existing particle pools. Extinguishing: water particles reduce heat; sprinklers tie to electricity (Stage 5). WaterSim: heightfield/puddle plane per district + flow approximation along terrain gradient; floodable rooms as interior water volumes; rain accumulation feeds puddles. Buoyancy from Stage 4 makes vehicles/debris float.

### Stage 7 — Character system v2 + NPC AI [§4, §5]
Split Npc into body (existing ragdoll, extended: more proportions/clothing/colors — all cosmetic overrides on the same rig) and Brain. Brain: waypoint navigation over district walk graphs (hand-authored nodes + auto-generated on roads/sidewalks), obstacle avoidance via raycast whiskers, schedules (day/night, per-NPC-type routine tables), event reactions (loud noise events already exist as sounds — add an event bus: explosions, collapse, fire → flee/evacuate). NPC limits per preset. Test dummies stay as the no-AI preset.

### Stage 8 — Editor + object editor [§16, §17]
MapEditor = the Stage 0/5 payoff: grid/free placement, rotate/scale, all content is JSON-described so palette is automatic. Object inspector = the object editor (mass/friction/restitution/color/material/visibility/grouping — all are already fields on props/objects).

### Stage 9 — Vehicles v2 [§6]
Vehicle definitions to JSON (engine, suspension, mass, wheel layout, sounds, lights). Add the 24 new vehicles as data entries using existing archetypes: wheeled (most), tracked (excavator/bulldozer), rail (train/tram — follow spline tracks laid in districts), water (boat/jet ski — Stage 4 buoyancy), air (heli/plane — arcade aerodynamics, this is a sandbox not a sim). Parts (doors, windows, wheels) as detachable sub-bodies with breakable constraints → repair system is "re-weld part." Customization = paint/wheels/suspension sliders writing to the def.

### Stage 10 — Districts & locations content [§1]
With streaming + JSON locations + machinery + AI, all 30 locations become content passes: author district JSONs (city center, suburbs, industrial, mall, hospital, police/fire, school, supermarket, gas station, railway+depot, airport, port+shipyard, power station, water treatment, fictional nuclear facility, fictional military base, mine, subway/sewer/tunnels, mountain/forest/lakeside/farmland/quarry, abandoned factory, offices, residential complexes). Subway/sewer = underground districts at negative Y, connected by the tunnel system.

### Stage 11 — Tools & gadgets [§7, §13]
Tool framework generalization (each tool = pointer-down/move/up handlers + a settings row). New tools map onto existing primitives: rope/cable/joint/spring → Stage 4 constraints; gravity/time controllers → existing globals; clone/erase/freeze/weld/repair → existing object ops; measuring/inspector → Stage 8 editor data; weather/lighting/wind/water controllers → Environment; paint/material replacement → voxel material swap (re-mesh dirty chunks); force-field → radial impulse volumes; portals → paired teleport volumes with momentum preservation; telekinesis/magnet → targeted force application; freeze ray → kinematic toggle + material swap to ice; EMP visual → electricity grid blackout event (Stage 5). Remote toy vehicles/drones = vehicles with camera swap.

### Stage 12 — FX pass [§8]
Explosion styles (dust-heavy concrete vs sparking metal vs woody splinters — all from Stage 2 material table), scorch decals as decal quads on voxel surfaces (persist via DamageStore), screen shake settings, dynamic light flashes (already have `mLightBuf`). Optimization: particle budget tied to preset.

### Stage 13 — Game modes & missions [§14, §15]
Mode manager in Game (mode = update/render/UI hooks). Free sandbox = current behavior. Destruction challenges / timed / collection / delivery / rescue / vehicle challenges = objective descriptors in JSON + checkpoint tracking; missions reference world landmarks (no disconnected levels, per brief). Physics lab & benchmark = scripted spawn + measurement harness (desktop harness already exists). Scenario editor = Stage 8 editor + save slots.

### Stage 14 — Modding [§19]
Mods = folders with JSON manifests validated against schemas (object defs, materials, textures, sounds, vehicles, NPC configs, physics presets, scenarios, map packs). ModManager: enable/disable, dependency/version check, merge order. No source modification needed. Ship `docs/MODDING.md` with schema reference.

### Stage 15 — Audio, graphics, camera polish [§20, §21]
Material-dependent collision audio (Stage 2 table already names sound sets), reverb zones per district type (interior/exterior = zone volumes), distance attenuation + occlusion via raycast. Cameras: first/third/free/cinematic/replay = camera controllers on existing orbit/chase code; replay = ring buffer of transforms (cheap, no video). PBR-lite for materials, dynamic shadows (one cascade), improved water shader, fog/AA/AO toggles. Vulkan evaluation — only after profiling says GLES3 is the bottleneck.

### Stage 16 — UI unification & tutorial [§23]
Panel framework: main menu, sandbox/map/mission selection, browsers (object/vehicle/NPC = one browser, three data sources), save/load manager, mod manager, performance monitor, customizable HUD (drag anchors), context-sensitive hints (interactHint already exists), tutorial = scripted objective chain reusing mission system.

### Continuous — Android optimization [§22]
ARM64 (verify abiFilters), thermal headroom listener (existing NativeActivity → add callbacks), dynamic resolution (already exists — `updateDynamicResolution`), battery saver + FPS limiter, device capability detection → default preset. Profile at every stage; budgets enforced in debug builds as hard asserts.

### Continuous — Debug menu [§24]
Game::perf already exists and desktop harness logs it. Add: frame-time graph, body/chunk/debris/NPC counters (all exist as stats somewhere — surface them), collision viz + wireframe (debug draw pass), physics pause/step (Stage 4), console (ImGui input → command dispatch).

---

## 4. Save format v1 (ships at Stage 1)

```json
{
  "format": "voxelsandbox-save",
  "version": 1,
  "created": "2026-11-04T15:20:00Z",
  "world": {
    "map": "harbor_heights",
    "timeOfDay": 0.62, "weather": "rain",
    "damage": { "chunks": [ { "c": [12,0,7], "mask": "base64…", "mats": "base64…" } ] }
  },
  "player": { "pos": [x,y,z], "yaw": 1.2, "tool": 3 },
  "vehicles": [ { "def": "pickup", "pos": [..], "rot": [..], "paint": "#a03030", "parts": [ {"id":"door_fl","state":"attached"} ], "damage": 0.15 } ],
  "objects": [ { "def": "crate", "pos": [..], "scale": 1.0, "mass": 40, "frozen": false, "group": "site_a" } ],
  "npcs": [ { "type": "worker", "pos": [..], "schedule": "day_shift" } ],
  "grid": { "generators": [...], "breakers": [...] },
  "settings": { "preset": "MEDIUM", "custom": { ... } }
}
```
Rules: unknown fields ignored (forward compat); version mismatch → migration chain v1→v2→…; corruption → quarantine file, never crash; autosave every 60 s into slot 0.

## 5. Mod manifest (ships at Stage 14, schema stable from Stage 2)

```json
{ "mod": "example_pack", "version": "1.0.0", "game": ">=0.5",
  "content": { "materials": ["materials.json"], "objects": ["objects.json"],
               "vehicles": ["vehicles/"], "maps": ["maps/"], "textures": ["tex/"], "sounds": ["sfx/"] } }
```

## 6. Recommended first builds (pick one)

| Slice | Why first |
|---|---|
| **A. Electricity + machinery (Stage 5)** | Self-contained; touches physics, UI, saves, JSON content; instantly visible; no dependency on Stage 0 streaming. |
| **B. Structural stress v2 (Stage 2+3)** | The game's identity is destruction; weakness field + cascading collapse is the biggest gameplay-per-line win. Depends only on existing destruction module. |
| C. Constraints pack (Stage 4) | Unlocks ropes/chains/springs → crane rigging, bridges, wrecking ball v2; feeds tools, editor, missions. |

Default recommendation: **B first** (it deepens what makes the game special and needs no new subsystems), then A, then C.

## 7. What I will NOT do (scope honesty)

- No real fluid simulation (brief itself asks for approximation), no FEM soft-body (Jolt proxies only), no real circuit simulation, no networked multiplayer (absent from brief), no flight sim aerodynamics. Every one of these would consume a stage-sized budget for sandbox-game payoff.
- The 30-location list ships incrementally across Stage 10 content passes, not in one drop — but the world streaming in Stage 0 is sized for all of them from day one.
