# Voxel Sandbox — Harbor Heights

A native C++17 3D physics sandbox for Android touchscreens: a fully destructible voxel city
(0.25 m voxels) with Jolt Physics rigid bodies, structural collapse, ragdoll characters, drivable
vehicles and sandbox tools. Rendering is OpenGL ES 3.0, audio is AAudio, and the app is a pure
NativeActivity. There is no Java/Kotlin code and no web view.

## Features

**Map: "Harbor Heights"** (128 × 32 × 128 m, 1687 voxel chunks)
- Residential street with 5 two-storey houses: rooms, stairs, interior doors, furniture, gable roofs, chimneys, fences and light switches.
- 6-storey apartment tower with a rooftop, switchback stairs, an 8-stop elevator (P, G, 1–5, R) and an **underground parking garage** reached by a ramp.
- Industrial area: a warehouse with a motorised gate, racks, an office and a **vault puzzle**. Put at least 1500 kg on the pressure plate to open it. There is also a container yard, a dump truck and a forklift.
- Construction site: a rotating tower crane with a wrecking ball on a chain, a condemned 3-storey brick block, an unfinished concrete frame with scaffolding, and building materials.
- Park with trees, benches, block towers, a seesaw and street lamps. Roads have sidewalks, curbs, crosswalks and night lighting.

**Voxel destruction** (`src/destruction/`)
- Chunked voxel storage (32³ chunks) with greedy meshing, baked per-vertex AO, a 2× LOD mesh and per-chunk static collision.
- Only dirty chunks are rebuilt, under a per-frame budget.
- 19 materials (concrete, brick, plaster, wood, plank, glass, metal, rust, roof, tile, asphalt, dirt, grass, leaves, bark, fabric, plastic, rubber, bedrock), each with its own hardness, density, colour, roughness/metalness and break sound.
- Sphere damage from tools, projectiles, explosions and high-energy impacts. Wrecking balls, vehicles and thrown objects damage walls.
- Damaged voxels are carved into **rigid voxel fragments**: small Jolt bodies with simplified box/compound collision. Tiny pieces become particles, so the game never simulates millions of bodies.
- **Structural support detection:** after damage, a flood fill searches for ground anchors. Any section without support detaches as one dynamic voxel body (`OBJ_STRUCTURE`) and falls under gravity. Partial collapses and persistent damage work.
- Debris budget with sleeping, distance culling and cleanup of the oldest debris.

**Physics** (`src/physics/`, `src/gameplay/`)
- Jolt Physics with multithreaded job system, fixed timestep (30/50/60 Hz), sleeping and layered broadphase.
- Physical hinged doors that break off when their frame is destroyed, a seesaw, kinematic elevators and gates, a crane, a chain-linked wrecking ball, pressure plates and switches.
- Props have their own mass, friction and bounciness. You can stack them.

**Characters**
- Stylised humanoid "crash dummies" with a skeletal rig, procedural walk animation and balance.
- They switch to a full **Jolt ragdoll** on impacts, explosions or falls, then get back up with a recovery blend.
- Non-graphic effects only: no blood and no injury depiction.

**Vehicles:** sedan, delivery van, dump truck (tipping bed), forklift (motorised fork slider) and wheel loader (raisable bucket); 9 are parked around the map and more can be spawned
- Jolt wheeled-vehicle constraints with suspension, anti-roll bars, steering, engine/gearbox, braking and handbrake.
- Mass, wheel friction, collision damage with engine smoke, enter/exit, flip, headlights and horn.

**Sandbox tools:** Hand (grab / throw / rotate / push-pull / scale / duplicate / delete / freeze), Sledgehammer, Cannon, Bomb, Rocket and Spawn.
- The spawn menu has 6 categories: furniture, construction, physics objects, vehicles, characters and explosives.
- The world panel controls gravity (zero, moon, earth, double, or free slider), time scale, time of day, weather and noclip.

**Visuals**
- Physically based shading (GGX, metallic/roughness) with procedural normal/detail textures.
- Directional sun/moon shadow map (off / 1024 / 2048 / 3072), hemisphere + baked voxel AO, optional SSAO, and up to 8 dynamic point lights (lamps, headlights, explosions).
- Exponential height fog, procedural sky with sun, stars and clouds, a day/night cycle and weather (clear, cloudy, rain, storm with lightning, fog).
- Sky reflections on glass and metal, GPU-instanced props and particles, colour grading and a vignette.

**Audio:** software mixer with 3D spatialisation and distance attenuation. All 36 sounds are synthesised procedurally:
- Material- and intensity-dependent impact and break sounds, footsteps per surface, engines, horn, explosions, collapses, doors, elevator.
- Ambience (wind, birds, city, rain, thunder) with indoor damping, plus UI sounds.

**Touch controls (no keyboard or mouse needed)**
- Floating virtual joystick on the left and look-drag on the right.
- Buttons: Jump, Run, Action (context: Grab / Smash / Fire / Place / Launch), Use (doors, switches, vehicles), a tool bar and Pause.
- Hand tool: Throw, Rotate, Far/Near, Big/Small, Copy, Del, Lock.
- Vehicle: GAS, BRAKE/Reverse, Handbrake, Exit, Light, Horn, Flip, Lift/Lower.
- Android back button closes panels, opens pause, and quits from the main menu.
- Settings: graphics preset LOW/MEDIUM/HIGH, resolution scale, dynamic resolution, FPS limit 30/45/60, shadow quality, SSAO, view distance, debris limit, particle budget, camera sensitivity, invert Y, FOV, joystick position, button size, menu text size, master/SFX/ambient/UI volume, FPS and debug overlay. Settings are saved to internal storage.

**Performance**
- ARM64 (arm64-v8a) build with job-system multithreading and Jolt worker threads.
- World generation and meshing run asynchronously on a loader thread.
- Frustum culling, chunk occlusion skipping, distance LOD, view-distance streaming of chunk draws, instancing, object pooling, sleep states, debris limits and dynamic resolution.

## Project layout

```
CMakeLists.txt          one CMake build for Android (libvoxelsandbox.so) and the desktop test harness
src/core                common types, input, settings, job system
src/engine              renderer (GLES3), procedural textures, particles, audio mixer
src/destruction         voxel storage, greedy mesher, voxel objects/fragments, destruction + collapse
src/physics             Jolt wrapper (layers, queries, contacts)
src/gameplay            player, props, NPC ragdolls, vehicles, interactions (doors/elevators/crane), sandbox tools
src/world               map builder (Harbor Heights), environment (day/night/weather)
src/ui                  touch HUD + ImGui menus
src/platform            android_main.cpp (NativeActivity/EGL/AAudio), desktop_main.cpp (headless test harness)
assets/                 GLSL shaders, UI font
android/                Gradle project (AGP 8.5.2) that builds the APKs via externalNativeBuild
third_party/            Jolt Physics 5.2.0, Dear ImGui 1.91.5, GLM 1.0.1
THIRD_PARTY_LICENSES, licenses/
```

## Building the APKs

Requirements: JDK 17, Android SDK (platform 34, build-tools 34.0.0), NDK **26.3.11579264**, CMake **3.22.1** (from the SDK manager) and Gradle 8.7+.

```bash
cd android
echo "sdk.dir=/path/to/Android/Sdk" > local.properties
gradle assembleDebug assembleRelease
# outputs:
#   android/app/build/outputs/apk/debug/app-debug.apk
#   android/app/build/outputs/apk/release/app-release.apk
adb install -r app/build/outputs/apk/release/app-release.apk
```

You can also open the `android/` folder in Android Studio and press Run.

**Release signing:** the repo includes a sandbox keystore (`android/app/release.keystore`, password `voxelsandbox`), so the release build is signed out of the box. Use your own key before publishing: create `android/keystore.properties` with `storeFile`, `storePassword`, `keyAlias` and `keyPassword`.

Requirements on the device: Android 8.0+ (API 26), ARM64, OpenGL ES 3.0.

## Desktop build and automated tests

The same game code runs in a headless Linux harness using Mesa EGL (surfaceless pbuffer, GLES 3). The harness sends real touch events to the HUD and runs scripted gameplay checks:

```bash
cmake -S . -B build-desktop -G Ninja && ninja -C build-desktop
./build-desktop/voxelsandbox_desktop --soak 30      # run from the project root
# screenshots -> shots/*.ppm, report -> shots/report.txt
# options: --w 1280 --h 720 --quality 0|1|2 --soak SECONDS
```

The checks cover:
- Main-menu PLAY via touch, world loading, finite body positions, joystick movement, ground contact, look drag, jump.
- Sledgehammer and cannon destruction, explosion fragments, structural collapse of an unsupported slab, no debris through the ground.
- NPC ragdoll and recovery.
- Car GAS/BRAKE driving and exit; forklift, loader and truck resting on the ground.
- Elevator to the roof, warehouse gate, crane rotation, wrecking-ball damage, vault weight puzzle, gravity changes.
- A random chaos soak test (explosions, rockets, spawns, vehicles) with body-validity and debris-budget checks, map restart and return to menu.

## How to play

- **Move:** left joystick. **Look:** drag on the right half. **Jump / Run:** buttons.
- **Tools:** pick one in the top bar.
  - Hand: grab and carry objects; Throw, Rotate, push/pull, resize, copy, delete, freeze.
  - Hammer: smash walls up close.
  - Cannon, Bomb, Rocket: ranged destruction.
  - Spawn: place the item chosen in the SPAWN menu.
- **Use:** open doors, press switches and elevator buttons, enter vehicles.
- **Pause (II):** spawn menu, teleport map, world controls (gravity, time, weather), settings, respawn, clear debris, restart.
- **Tips:**
  - Knock out the ground-floor walls or columns and the floors above collapse.
  - Swing the crane's wrecking ball into the condemned brick block.
  - Stack heavy objects on the warehouse plate to open the vault.

## Test status (this build)

- **Desktop harness** (Mesa llvmpipe software GLES 3.2, 2 x86 cores): 43/43 checks pass, including a 30 s chaos soak test. The full log is in `docs/test_report.txt` and screenshots are in `docs/screenshots/`.
- **AddressSanitizer + LeakSanitizer** run of the full harness: no errors. It found and fixed a dangling occlusion-query pointer when the map restarts.
- **Android:** the Debug and Release APKs build with Gradle + NDK r26d. The arm64-v8a `libvoxelsandbox.so` exports `ANativeActivity_onCreate`, uses 16 KB-aligned segments, and the APK passes `apksigner verify` and `zipalign -c -p 4`.
- **Not yet tested on a physical Android device or emulator.** The build machine has no ARM emulation or KVM. The Android layer (`src/platform/android_main.cpp`: EGL, touch, AAudio, lifecycle) compiles and links, but it has not been run. Install it with `adb install` and check `adb logcat -s VoxelSandbox`.
