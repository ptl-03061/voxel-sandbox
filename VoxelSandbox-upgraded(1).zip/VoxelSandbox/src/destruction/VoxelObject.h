// Dynamic destructible voxel bodies: props, furniture, detached building sections and rubble.
#pragma once
#include "destruction/Mesher.h"
#include "engine/Renderer.h"
#include "physics/PhysicsWorld.h"

#include <Jolt/Physics/Constraints/Constraint.h>

struct VoxelModel {
    ivec3 dims{0};
    float vs = VOXEL_SIZE;
    std::vector<uint8_t> v;
    void resize(ivec3 d, float voxelSize = VOXEL_SIZE) { dims = d; vs = voxelSize; v.assign((size_t)d.x * d.y * d.z, 0); }
    inline bool in(int x, int y, int z) const { return x >= 0 && y >= 0 && z >= 0 && x < dims.x && y < dims.y && z < dims.z; }
    inline size_t idx(int x, int y, int z) const { return ((size_t)z * dims.y + y) * dims.x + x; }
    inline uint8_t get(int x, int y, int z) const { return in(x, y, z) ? v[idx(x, y, z)] : M_AIR; }
    inline void set(int x, int y, int z, uint8_t m) { if (in(x, y, z)) v[idx(x, y, z)] = m; }
    void box(ivec3 a, ivec3 b, uint8_t m) {
        for (int z = std::max(0, a.z); z < std::min(dims.z, b.z); ++z)
            for (int y = std::max(0, a.y); y < std::min(dims.y, b.y); ++y)
                for (int x = std::max(0, a.x); x < std::min(dims.x, b.x); ++x) v[idx(x, y, z)] = m;
    }
    int solidCount() const { int n = 0; for (auto c : v) n += c != M_AIR; return n; }
    vec3 sizeMeters() const { return vec3(dims) * vs; }
};

enum ObjFlags : uint32_t {
    OBJ_DEBRIS = 1,      // auto-removed when the debris budget is exceeded
    OBJ_PROP = 2,        // spawned or placed prop
    OBJ_DOOR = 4,
    OBJ_STRUCTURE = 8,   // detached building section
    OBJ_NO_SPLIT = 16,
    OBJ_KINEMATIC = 32,
};

struct VoxelObject {
    int id = 0;
    std::string name;
    VoxelModel model;
    float scale = 1.0f;
    uint32_t flags = 0;
    JPH::BodyID body;
    PhysTag tag;
    GpuMesh mesh;
    bool meshDirty = true;
    bool shapeDirty = false;
    bool alive = true;
    int solid = 0;
    float age = 0;
    float impactCooldown = 0;
    float mass = 0;
    float fade = 1.0f;
    mat4 transform{1.0f};   // body transform * scale (voxel corner origin)
    AABB bounds;
    vec4 tint{1, 1, 1, 0};
    // hinge (doors)
    JPH::Ref<JPH::Constraint> hinge;
    float hingeBreakImpulse = 0;
    ivec3 hingeAnchorVoxel{-1};
    float lastSoundTime = 0;
};

class ObjectManager {
public:
    void init(PhysicsWorld* phys) { mPhys = phys; }
    void clear();

    VoxelObject* create(VoxelModel&& model, const vec3& pos, const quat& rot, uint32_t flags,
                        const vec3& linVel = vec3(0), const vec3& angVel = vec3(0), float scale = 1.0f, const std::string& name = "");
    void destroy(VoxelObject* o);
    // Re-split an object into connected components after voxels were removed.
    void splitAndRebuild(VoxelObject* o, std::vector<VoxelObject*>* newPieces = nullptr);
    void setScale(VoxelObject* o, float s);
    VoxelObject* duplicate(VoxelObject* o, const vec3& offset);

    void update(float dt, int maxObjects);
    void render(Renderer& r, const vec3& camPos, float viewDist);

    vec3 worldToLocal(VoxelObject* o, const vec3& p) const;   // returns voxel-space coords
    vec3 localToWorld(VoxelObject* o, const vec3& vox) const;

    std::vector<std::unique_ptr<VoxelObject>>& objects() { return mObjects; }
    int count() const { return (int)mObjects.size(); }
    int debrisCount() const { int n = 0; for (auto& o : mObjects) n += (o->flags & OBJ_DEBRIS) != 0; return n; }
    std::vector<VoxelObject*> pendingRemoval;

private:
    bool rebuildShape(VoxelObject* o);
    PhysicsWorld* mPhys = nullptr;
    std::vector<std::unique_ptr<VoxelObject>> mObjects;
    int mNextId = 1;
};
