// Voxel material definitions. Every voxel in the world and in dynamic objects is a single byte.
#pragma once
#include "core/Common.h"

constexpr float VOXEL_SIZE = 0.25f;   // world voxel edge length in meters
constexpr int CHUNK = 16;             // chunk edge length in voxels
constexpr int CHUNK_VOL = CHUNK * CHUNK * CHUNK;

enum Mat : uint8_t {
    M_AIR = 0,
    M_BEDROCK,
    M_DIRT,
    M_GRASS,
    M_ASPHALT,
    M_CONCRETE,
    M_BRICK,
    M_PLASTER,
    M_WOOD,
    M_PLANK,
    M_GLASS,
    M_METAL,
    M_RUST,
    M_ROOF,
    M_TILE,
    M_LEAVES,
    M_BARK,
    M_FABRIC,
    M_PLASTIC,
    M_RUBBER,
    M_LIGHT,
    M_PAINT_RED,
    M_PAINT_BLUE,
    M_PAINT_YELLOW,
    M_PAINT_GREEN,
    M_SAND,
    M_ROADLINE,
    M_CURB,
    M_STEEL,      // heavy structural steel (beams, crane)
    M_CONTAINER,  // painted corrugated container metal
    M_CARPET,
    M_DARKWOOD,
    M_ICE,        // slippery, shatters
    M_SNOW,       // soft, muffles sound
    M_CERAMIC,    // brittle, shatters
    M_COUNT
};

enum class SoundClass : uint8_t { None, Wood, Glass, Metal, Concrete, Dirt, Soft };

struct MaterialInfo {
    const char* name;
    vec3 color;        // base albedo (linear-ish)
    float roughness;
    float metallic;
    float emissive;
    float hardness;    // 0..1, resistance to damage; >= 10 indestructible
    float density;     // kg/m^3 (scaled for gameplay)
    SoundClass sound;
    bool transparent;
    int texLayer;      // procedural texture layer index
    float colorJitter; // per-voxel brightness variation
};

const MaterialInfo& MatInfo(uint8_t m);
inline bool IsSolid(uint8_t m) { return m != M_AIR; }
inline bool IsOpaque(uint8_t m) { return m != M_AIR && !MatInfo(m).transparent; }

// Texture layer ids used by the procedural texture generator.
enum TexLayer : int {
    TL_FLAT = 0, TL_CONCRETE, TL_BRICK, TL_WOOD, TL_PLANK, TL_METAL, TL_ASPHALT, TL_GRASS,
    TL_DIRT, TL_TILE, TL_ROOF, TL_FABRIC, TL_LEAVES, TL_BARK, TL_CORRUGATED, TL_PLASTER, TL_COUNT
};
