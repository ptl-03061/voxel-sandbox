// Voxel destruction: sphere damage on world + objects, fragments, explosions, impact damage, structural collapse.
#pragma once
#include "destruction/VoxelObject.h"
#include "destruction/VoxelWorld.h"
#include "engine/Particles.h"

#include <unordered_map>

struct DestructionSettings {
    int maxDebrisObjects = 220;     // dynamic rubble bodies kept alive
    int maxFragmentsPerHit = 16;    // rigid fragments carved per hit
    int supportSearchLimit = 70000; // voxels explored per support check before assuming "supported"
    int particlesPerHit = 90;
    bool impactDamage = true;
    bool stressSystem = true;      // progressive structural weakening
    float weaknessPerHit = 0.35f;  // weakness accumulated by voxels that survive a hit
    float weaknessDamage = 0.6f;   // extra effective damage power per unit of weakness
};

class Destruction {
public:
    void init(VoxelWorld* w, ObjectManager* o, PhysicsWorld* p, Particles* parts);
    DestructionSettings settings;

    // Damages world and all voxel objects overlapping the sphere. Returns voxels removed.
    int damageAt(const vec3& c, float radius, float power, const vec3& push = vec3(0), bool fragments = true, JPH::BodyID ignore = JPH::BodyID());
    int damageWorld(const vec3& c, float radius, float power, const vec3& push, bool fragments);
    int damageObject(VoxelObject* o, const vec3& c, float radius, float power, const vec3& push);
    void explode(const vec3& c, float radius, float power);
    void processContacts(const std::vector<ContactEvent>& events, float time);
    void update(float dt);

    // Structural stress: surviving voxels accumulate weakness until they fail.
    float weaknessAt(const ivec3& v) const;
    void addWeakness(const ivec3& v, float amount);   // spills neighbours + support checks on failure
    void onExternalRemoval(const ivec3& v);           // fire/burning: carve + support check
    std::function<void(const ivec3& v)> onVoxelRemoved;  // save-system edit log

    // material at a world position (world voxels or voxel objects); used for sounds/footsteps
    uint8_t materialNear(const vec3& p, PhysTag* tag);
    void playImpactSound(uint8_t mat, const vec3& p, float intensity, bool breakSound);

    std::function<void(const vec3& c, float radius, float power)> onExplosion;
    std::function<void(const ContactEvent& e, PhysTag* a, PhysTag* b, float energy)> onContact;

    struct Stats { int voxelsDestroyed = 0, collapses = 0, fragments = 0, supportChecks = 0; } stats;

private:
    void spawnVoxelDebris(const vec3& p, uint8_t mat, const vec3& vel, int count);
    void queueSupport(const ivec3& v);
    void runSupportChecks(int budget);
    bool checkComponent(const ivec3& seed);
    void detach(const std::vector<ivec3>& comp);
    inline size_t bit(const ivec3& v) const { return ((size_t)v.z * VoxelWorld::SY + v.y) * VoxelWorld::SX + v.x; }

    VoxelWorld* mWorld = nullptr;
    ObjectManager* mObjs = nullptr;
    PhysicsWorld* mPhys = nullptr;
    Particles* mParts = nullptr;
    std::vector<ivec3> mSeeds;
    std::vector<uint64_t> mVisited;
    std::vector<size_t> mTouched;
    int mSoundsThisFrame = 0;
    float mTime = 0;
    struct StressChunk { uint8_t w[CHUNK_VOL]; };
    std::unordered_map<int64_t, std::unique_ptr<StressChunk>> mStress;
    static int64_t stressKey(const ivec3& v) { return ((int64_t)(v.z >> 4) * VoxelWorld::CY + (v.y >> 4)) * VoxelWorld::CX + (v.x >> 4); }
};
