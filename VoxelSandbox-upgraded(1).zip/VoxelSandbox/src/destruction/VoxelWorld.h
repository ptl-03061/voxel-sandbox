// Chunked static voxel world: sparse 16^3 chunks, async greedy meshing, LOD meshes and per-chunk collision.
#pragma once
#include "destruction/Mesher.h"
#include "engine/Renderer.h"
#include "physics/PhysicsWorld.h"

class JobPool;

struct Chunk {
    ivec3 cpos;
    uint8_t v[CHUNK_VOL];
    int solid = 0;
    GpuMesh mesh, lod;
    OcclusionState occ;
    JPH::BodyID body;
    bool meshDirty = true, colDirty = true;
    PhysTag tag;
    VoxMeshData cpu, cpuLod;   // staging for async meshing
    bool cpuReady = false;
    JPH::RefConst<JPH::Shape> pendingShape;
    AABB bounds() const {
        AABB b; b.mn = vec3(cpos * CHUNK) * VOXEL_SIZE; b.mx = b.mn + vec3(CHUNK * VOXEL_SIZE); return b;
    }
    Chunk() { std::memset(v, 0, sizeof(v)); }
};

class VoxelWorld {
public:
    static constexpr int CX = 32, CY = 8, CZ = 32;
    static constexpr int SX = CX * CHUNK, SY = CY * CHUNK, SZ = CZ * CHUNK;

    void init(PhysicsWorld* phys);
    void clear(Renderer* renderer = nullptr);   // pass the renderer so GL occlusion queries are released

    inline bool inBounds(int x, int y, int z) const { return x >= 0 && y >= 0 && z >= 0 && x < SX && y < SY && z < SZ; }
    inline uint8_t get(int x, int y, int z) const {
        if (!inBounds(x, y, z)) return y < 0 ? M_BEDROCK : M_AIR;
        const Chunk* c = mChunks[chunkIndex(x >> 4, y >> 4, z >> 4)].get();
        return c ? c->v[((z & 15) * CHUNK + (y & 15)) * CHUNK + (x & 15)] : M_AIR;
    }
    inline uint8_t get(const ivec3& p) const { return get(p.x, p.y, p.z); }
    void set(int x, int y, int z, uint8_t m);            // marks chunks dirty
    void setRaw(int x, int y, int z, uint8_t m);         // no dirty tracking (bulk generation)
    void fill(ivec3 a, ivec3 b, uint8_t m, bool raw = true); // inclusive-exclusive box [a,b)

    // Build meshes + collision for every chunk (parallel CPU meshing, main thread GPU upload).
    void buildAll(JobPool& jobs, std::function<void(float)> progress);
    void buildAllCpu(JobPool& jobs, std::function<void(float)> progress);
    void uploadAllGpu();
    // Rebuild dirty chunks; returns number rebuilt
    int updateDirty(int maxPerFrame = 64);
    void render(Renderer& r, const vec3& camPos, float lodDistance, float viewDistance, bool occlusion);

    static ivec3 toVoxel(const vec3& p) { return ivec3(glm::floor(p / VOXEL_SIZE)); }
    static vec3 voxelCenter(const ivec3& v) { return (vec3(v) + 0.5f) * VOXEL_SIZE; }
    // DDA raycast against voxels; returns hit voxel and face normal
    bool raycast(const vec3& from, const vec3& dir, float maxDist, ivec3& hit, ivec3& normal, float& dist) const;

    Chunk* chunkAt(int cx, int cy, int cz) { return (cx < 0 || cy < 0 || cz < 0 || cx >= CX || cy >= CY || cz >= CZ) ? nullptr : mChunks[chunkIndex(cx, cy, cz)].get(); }
    int chunkCount() const { int n = 0; for (auto& c : mChunks) if (c) ++n; return n; }
    int dirtyCount() const { return (int)mDirty.size(); }
    uint32_t revision() const { return mRevision; }
    PhysicsWorld* physics() { return mPhys; }

private:
    static inline int chunkIndex(int cx, int cy, int cz) { return (cz * CY + cy) * CX + cx; }
    Chunk* ensureChunk(int cx, int cy, int cz);
    void markDirty(int cx, int cy, int cz);
    void meshChunkCpu(Chunk& c);
    void uploadChunk(Chunk& c);
    void rebuildCollision(Chunk& c, bool useShape);

    std::vector<std::unique_ptr<Chunk>> mChunks;
    std::vector<Chunk*> mDirty;
    PhysicsWorld* mPhys = nullptr;
    uint32_t mRevision = 0;
};
