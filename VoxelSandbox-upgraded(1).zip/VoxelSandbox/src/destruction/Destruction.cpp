#include "destruction/Destruction.h"
#include "engine/Audio.h"

#include <Jolt/Physics/Body/BodyLock.h>
#include <deque>

using namespace JPH;

void Destruction::init(VoxelWorld* w, ObjectManager* o, PhysicsWorld* p, Particles* parts) {
    mWorld = w; mObjs = o; mPhys = p; mParts = parts;
    size_t bits = (size_t)VoxelWorld::SX * VoxelWorld::SY * VoxelWorld::SZ;
    mVisited.assign((bits + 63) / 64, 0);
    mStress.clear();
}

void Destruction::spawnVoxelDebris(const vec3& p, uint8_t mat, const vec3& vel, int count) {
    const MaterialInfo& mi = MatInfo(mat);
    Rng& r = GRng();
    for (int i = 0; i < count; ++i) {
        vec3 v = vel + r.unitVec() * r.range(0.5f, 3.0f);
        float b = r.range(0.75f, 1.15f);
        if (mi.transparent) {
            mParts->spawn(PType::Shard, p + r.unitVec() * 0.1f, v * 1.3f, vec4(mi.color * 1.2f, 0.85f), r.range(0.04f, 0.1f), r.range(2.0f, 4.0f));
        } else {
            mParts->spawn(PType::Cube, p + r.unitVec() * 0.08f, v, vec4(mi.color * b, 1.0f), r.range(0.04f, 0.11f), r.range(4.0f, 9.0f));
        }
    }
    if (!mi.transparent && mat != M_LEAVES && r.f01() < 0.5f) {
        vec3 dc = glm::mix(mi.color, vec3(0.6f), 0.5f);
        mParts->spawn(PType::Dust, p, vel * 0.1f + vec3(0, 0.3f, 0), vec4(dc, 0.35f), r.range(0.3f, 0.6f), r.range(1.5f, 3.0f));
    }
}

uint8_t Destruction::materialNear(const vec3& p, PhysTag* tag) {
    if (tag && tag->type == TagType::VoxelObject) {
        auto* o = (VoxelObject*)tag->ptr;
        vec3 l = mObjs->worldToLocal(o, p);
        ivec3 li = ivec3(glm::floor(l));
        for (int k = 0; k < 27; ++k) {
            ivec3 q = li + ivec3(k % 3 - 1, (k / 3) % 3 - 1, k / 9 - 1);
            uint8_t m = o->model.get(q.x, q.y, q.z);
            if (m) return m;
        }
        return M_WOOD;
    }
    ivec3 v = VoxelWorld::toVoxel(p);
    if (uint8_t m = mWorld->get(v)) return m;
    for (int k = 0; k < 27; ++k) {
        ivec3 q = v + ivec3(k % 3 - 1, (k / 3) % 3 - 1, k / 9 - 1);
        if (uint8_t m = mWorld->get(q)) return m;
    }
    return M_CONCRETE;
}

void Destruction::playImpactSound(uint8_t mat, const vec3& p, float intensity, bool brk) {
    if (mSoundsThisFrame > 10) return;
    ++mSoundsThisFrame;
    SoundId id = SND_CONCRETE_HIT;
    switch (MatInfo(mat).sound) {
    case SoundClass::Wood: id = brk ? SND_WOOD_BREAK : SND_WOOD_HIT; break;
    case SoundClass::Glass: id = brk ? SND_GLASS_BREAK : SND_GLASS_HIT; break;
    case SoundClass::Metal: id = intensity > 0.6f ? SND_METAL_HEAVY : SND_METAL_HIT; break;
    case SoundClass::Concrete: id = brk ? SND_CONCRETE_BREAK : SND_CONCRETE_HIT; break;
    case SoundClass::Dirt: id = SND_DIRT_HIT; break;
    case SoundClass::Soft: id = SND_SOFT_HIT; break;
    default: break;
    }
    float pitch = GRng().range(0.85f, 1.15f) * (1.15f - std::min(intensity, 1.0f) * 0.3f);
    GAudio().play(id, p, std::min(1.0f, 0.15f + intensity), pitch);
}

int Destruction::damageWorld(const vec3& c, float radius, float power, const vec3& push, bool fragments) {
    ivec3 vc = VoxelWorld::toVoxel(c);
    int r = (int)std::ceil(radius / VOXEL_SIZE * 1.35f) + 1;
    Rng& rng = GRng();
    int removed = 0;
    int matCount[M_COUNT] = {0};
    int particleBudget = settings.particlesPerHit;
    int fragBudget = fragments ? settings.maxFragmentsPerHit : 0;
    if (mObjs->debrisCount() > settings.maxDebrisObjects) fragBudget = std::min(fragBudget, 2);
    std::vector<ivec3> removedList;
    struct Frag { ivec3 v; float d; };
    std::vector<Frag> shell;
    for (int z = -r; z <= r; ++z)
        for (int y = -r; y <= r; ++y)
            for (int x = -r; x <= r; ++x) {
                ivec3 v = vc + ivec3(x, y, z);
                uint8_t m = mWorld->get(v);
                if (!m) continue;
                const MaterialInfo& mi = MatInfo(m);
                if (mi.hardness >= 10.0f) continue;
                float d = glm::distance(VoxelWorld::voxelCenter(v), c);
                if (d > radius * 1.35f) continue;
                float fall = 1.0f - d / radius;
                float weak = settings.stressSystem ? weaknessAt(v) : 0.0f;
                float eff = power * (0.45f + 0.55f * std::max(fall, 0.0f)) * rng.range(0.8f, 1.2f)
                          + weak * settings.weaknessDamage;
                if (d <= radius && eff > mi.hardness) {
                    mWorld->set(v.x, v.y, v.z, M_AIR);
                    removedList.push_back(v);
                    if (onVoxelRemoved) onVoxelRemoved(v);
                    matCount[m]++;
                    ++removed;
                    if (particleBudget > 0 && rng.f01() < 0.6f) {
                        vec3 dir = glm::normalize(VoxelWorld::voxelCenter(v) - c + rng.unitVec() * 0.2f);
                        int n = mi.transparent ? 3 : 2;
                        spawnVoxelDebris(VoxelWorld::voxelCenter(v), m, dir * (2.0f + power * 5.0f) * rng.range(0.4f, 1.0f) + push, n);
                        particleBudget -= n;
                    }
                } else if (settings.stressSystem && d <= radius && mi.hardness < 10.0f) {
                    addWeakness(v, settings.weaknessPerHit * std::max(fall, 0.05f) * power);
                } else if (fragBudget > 0 && d > radius * 0.7f && power * 0.9f > mi.hardness * 0.8f && !mi.transparent) {
                    shell.push_back({v, d});
                }
            }
    // carve rigid fragments out of the crater shell
    if (!shell.empty() && fragBudget > 0) {
        for (int i = 0; i < fragBudget * 3 && fragBudget > 0 && !shell.empty(); ++i) {
            const Frag f = shell[rng.next() % shell.size()];
            if (!mWorld->get(f.v)) continue;
            int bs = power > 1.2f ? 3 : 2;
            VoxelModel mdl;
            mdl.resize(ivec3(bs), VOXEL_SIZE);
            int cnt = 0;
            ivec3 o = f.v - ivec3(rng.irange(0, bs - 1), rng.irange(0, bs - 1), rng.irange(0, bs - 1));
            for (int z = 0; z < bs; ++z)
                for (int y = 0; y < bs; ++y)
                    for (int x = 0; x < bs; ++x) {
                        ivec3 q = o + ivec3(x, y, z);
                        uint8_t m = mWorld->get(q);
                        if (!m || MatInfo(m).hardness >= 10.0f || q.y <= 0) continue;
                        if (glm::distance(VoxelWorld::voxelCenter(q), c) > radius * 1.4f) continue;
                        if (rng.f01() < 0.25f) continue;  // irregular chunk shapes
                        mdl.set(x, y, z, m);
                        mWorld->set(q.x, q.y, q.z, M_AIR);
                        removedList.push_back(q);
                        if (onVoxelRemoved) onVoxelRemoved(q);
                        ++cnt;
                    }
            if (cnt == 0) continue;
            vec3 wp = vec3(o) * VOXEL_SIZE;
            vec3 dir = glm::normalize(wp - c + rng.unitVec() * 0.3f + vec3(0, 0.3f, 0));
            vec3 vel = dir * (1.5f + power * 4.5f) * rng.range(0.5f, 1.0f) + push * 0.5f;
            mObjs->create(std::move(mdl), wp, quat(1, 0, 0, 0), OBJ_DEBRIS, vel, rng.unitVec() * 4.0f);
            stats.fragments++;
            --fragBudget;
        }
    }
    if (removed > 0 || !removedList.empty()) {
        int best = 0;
        for (int m = 1; m < M_COUNT; ++m) if (matCount[m] > matCount[best]) best = m;
        if (best) playImpactSound((uint8_t)best, c, std::min(1.0f, removed / 40.0f + 0.3f), true);
        stats.voxelsDestroyed += removed;
        for (const auto& v : removedList) {
            static const ivec3 N[6] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
            for (const auto& n : N) {
                ivec3 q = v + n;
                if (mWorld->get(q)) queueSupport(q);
            }
        }
    }
    return removed;
}

int Destruction::damageObject(VoxelObject* o, const vec3& c, float radius, float power, const vec3& push) {
    if (!o->alive) return 0;
    vec3 lc = mObjs->worldToLocal(o, c);
    float vsz = o->model.vs * o->scale;
    float rv = radius / vsz;
    // small voxel objects get proportionally stronger hits
    ivec3 mn = glm::max(ivec3(glm::floor(lc - rv)), ivec3(0));
    ivec3 mx = glm::min(ivec3(glm::ceil(lc + rv)), o->model.dims - 1);
    int removed = 0;
    int matCount[M_COUNT] = {0};
    Rng& rng = GRng();
    int particleBudget = settings.particlesPerHit / 2;
    bool glassOnly = true;
    for (auto m : o->model.v) if (m && !MatInfo(m).transparent) { glassOnly = false; break; }
    for (int z = mn.z; z <= mx.z; ++z)
        for (int y = mn.y; y <= mx.y; ++y)
            for (int x = mn.x; x <= mx.x; ++x) {
                uint8_t m = o->model.get(x, y, z);
                if (!m) continue;
                const MaterialInfo& mi = MatInfo(m);
                float d = glm::distance(vec3(x, y, z) + 0.5f, lc);
                if (d > rv && !(glassOnly && power > 0.1f)) continue;
                float fall = 1.0f - d / rv;
                float eff = power * (0.45f + 0.55f * std::max(fall, 0.f)) * rng.range(0.8f, 1.2f);
                if (eff > mi.hardness || (glassOnly && power > 0.1f)) {
                    o->model.set(x, y, z, M_AIR);
                    ++removed; matCount[m]++;
                    if (particleBudget > 0 && rng.f01() < 0.7f) {
                        vec3 wp = mObjs->localToWorld(o, vec3(x, y, z) + 0.5f);
                        spawnVoxelDebris(wp, m, glm::normalize(wp - c + rng.unitVec() * 0.3f) * (1.5f + power * 4) + push, 2);
                        particleBudget -= 2;
                    }
                }
            }
    if (removed) {
        int best = 0;
        for (int m = 1; m < M_COUNT; ++m) if (matCount[m] > matCount[best]) best = m;
        if (best) playImpactSound((uint8_t)best, c, std::min(1.0f, removed / 30.0f + 0.2f), true);
        stats.voxelsDestroyed += removed;
        // detach from hinge if it is a door and got hit hard
        if (o->hinge && removed > 6) { mPhys->sys().RemoveConstraint(o->hinge); o->hinge = nullptr; }
        mObjs->splitAndRebuild(o);
    }
    if (o->alive && glm::length2(push) > 0) mPhys->bi().AddImpulse(o->body, ToJ(push * std::min(o->mass, 400.0f) * 0.3f), RVec3(c.x, c.y, c.z));
    return removed;
}

int Destruction::damageAt(const vec3& c, float radius, float power, const vec3& push, bool fragments, BodyID ignore) {
    int n = damageWorld(c, radius, power, push, fragments);
    std::vector<BodyID> bodies;
    mPhys->bodiesInSphere(c, radius + 0.3f, bodies);
    for (auto id : bodies) {
        if (id == ignore) continue;
        PhysTag* t = mPhys->tagOf(id);
        if (t && t->type == TagType::VoxelObject) n += damageObject((VoxelObject*)t->ptr, c, radius, power, push);
    }
    return n;
}

void Destruction::explode(const vec3& c, float radius, float power) {
    damageAt(c, radius, power, vec3(0), true);
    // radial impulse on dynamic bodies
    std::vector<BodyID> bodies;
    mPhys->bodiesInSphere(c, radius * 3.0f, bodies);
    BodyInterface& bi = mPhys->bi();
    for (auto id : bodies) {
        if (bi.GetMotionType(id) != EMotionType::Dynamic) continue;
        vec3 p = ToG(Vec3(bi.GetCenterOfMassPosition(id)));
        vec3 d = p - c;
        float dist = glm::length(d);
        float fall = 1.0f - Saturate(dist / (radius * 3.0f));
        if (fall <= 0) continue;
        vec3 dir = dist > 0.01f ? d / dist : vec3(0, 1, 0);
        dir = glm::normalize(dir + vec3(0, 0.35f, 0));
        float mass = mPhys->massOf(id);
        float dv = power * 16.0f * fall / std::max(1.0f, std::pow(mass / 80.0f, 0.35f));
        dv = std::min(dv, 28.0f);
        bi.AddImpulse(id, ToJ(dir * dv * mass));
        bi.AddAngularImpulse(id, ToJ(GRng().unitVec() * mass * dv * 0.05f));
    }
    // visuals
    Rng& r = GRng();
    for (int i = 0; i < 26; ++i) mParts->spawn(PType::Fire, c + r.unitVec() * radius * 0.3f, r.unitVec() * r.range(2, 8), vec4(1.0f, r.range(0.45f, 0.7f), 0.15f, 0.9f), r.range(0.5f, 1.2f), r.range(0.3f, 0.7f));
    for (int i = 0; i < 18; ++i) {
        float g = r.range(0.32f, 0.52f);   // varied grey so overlapping puffs keep some depth
        mParts->spawn(PType::Smoke, c + r.unitVec() * radius * 0.5f, r.unitVec() * r.range(1, 4) + vec3(0, 2, 0), vec4(g, g * 0.97f, g * 0.94f, 0.32f), r.range(0.7f, 1.4f), r.range(2.5f, 5.0f));
    }
    for (int i = 0; i < 40; ++i) mParts->spawn(PType::Spark, c, r.unitVec() * r.range(6, 18), vec4(1.0f, 0.8f, 0.4f, 1.0f), 0.05f, r.range(0.4f, 1.2f));
    mParts->spawn(PType::Flash, c, vec3(0), vec4(1.0f, 0.85f, 0.6f, 1.0f), radius * 2.2f, 0.18f);
    GAudio().play(SND_EXPLOSION, c, 1.0f, r.range(0.9f, 1.1f));
    if (onExplosion) onExplosion(c, radius, power);
}

void Destruction::processContacts(const std::vector<ContactEvent>& events, float time) {
    mTime = time;
    int damageOps = 0;
    for (const auto& e : events) {
        PhysTag* ta = mPhys->tagOf(e.a);
        PhysTag* tb = mPhys->tagOf(e.b);
        float ma = mPhys->massOf(e.a), mb = mPhys->massOf(e.b);
        float mu = (ma >= 1e8f) ? mb : (mb >= 1e8f ? ma : ma * mb / (ma + mb));
        if (mu >= 1e8f) continue;
        float energy = 0.5f * mu * e.speed * e.speed;
        if (onContact) onContact(e, ta, tb, energy);
        // sounds
        float intensity = Saturate(std::log10(1.0f + energy) / 4.5f);
        if (energy > 30.0f) {
            PhysTag* soundTag = (ta && ta->type == TagType::VoxelObject) ? ta : tb;
            VoxelObject* so = (soundTag && soundTag->type == TagType::VoxelObject) ? (VoxelObject*)soundTag->ptr : nullptr;
            if (!so || time - so->lastSoundTime > 0.12f) {
                if (so) so->lastSoundTime = time;
                playImpactSound(materialNear(e.point, soundTag), e.point, intensity, false);
            }
        }
        // impact damage: heavy fast impacts break voxels on both sides
        if (!settings.impactDamage || energy < 2500.0f || e.speed < 2.5f || damageOps > 6) continue;
        VoxelObject* oa = (ta && ta->type == TagType::VoxelObject) ? (VoxelObject*)ta->ptr : nullptr;
        VoxelObject* ob = (tb && tb->type == TagType::VoxelObject) ? (VoxelObject*)tb->ptr : nullptr;
        if ((oa && oa->impactCooldown > 0) || (ob && ob->impactCooldown > 0)) continue;
        if (oa) oa->impactCooldown = 0.25f;
        if (ob) ob->impactCooldown = 0.25f;
        float radius = glm::clamp(0.2f + std::cbrt(energy) * 0.012f, 0.25f, 1.6f);
        float power = glm::clamp(energy / 30000.0f, 0.12f, 1.1f);
        damageAt(e.point, radius, power, vec3(0), energy > 20000.0f);
        ++damageOps;
    }
}

void Destruction::queueSupport(const ivec3& v) {
    if (mSeeds.size() < 20000) mSeeds.push_back(v);
}

bool Destruction::checkComponent(const ivec3& seed) {
    // Search downwards-first for an anchor (bedrock / ground layer). Unsupported components are detached.
    std::deque<ivec3> q;
    std::vector<ivec3> comp;
    q.push_back(seed);
    size_t b0 = bit(seed);
    mVisited[b0 >> 6] |= 1ull << (b0 & 63);
    mTouched.push_back(b0);
    bool anchored = false;
    static const ivec3 N[5] = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, 0, 1}, {0, 0, -1}};
    while (!q.empty()) {
        ivec3 v = q.front(); q.pop_front();
        comp.push_back(v);
        uint8_t m = mWorld->get(v);
        if (v.y <= 0 || m == M_BEDROCK) { anchored = true; break; }
        if ((int)comp.size() > settings.supportSearchLimit) { anchored = true; break; }
        auto visit = [&](const ivec3& n, bool front) {
            if (!mWorld->inBounds(n.x, n.y, n.z)) return;
            if (!mWorld->get(n)) return;
            size_t b = bit(n);
            uint64_t& w = mVisited[b >> 6];
            uint64_t mask = 1ull << (b & 63);
            if (w & mask) return;
            w |= mask;
            mTouched.push_back(b);
            if (front) q.push_front(n); else q.push_back(n);
        };
        visit(v + ivec3(0, -1, 0), true);
        for (const auto& n : N) visit(v + n, false);
    }
    stats.supportChecks++;
    if (!anchored) detach(comp);
    return anchored;
}

void Destruction::detach(const std::vector<ivec3>& comp) {
    if (comp.empty()) return;
    ivec3 mn(1 << 30), mx(-1);
    for (const auto& v : comp) { mn = glm::min(mn, v); mx = glm::max(mx, v); }
    if (comp.size() <= 2) {
        for (const auto& v : comp) {
            uint8_t m = mWorld->get(v);
            mWorld->set(v.x, v.y, v.z, M_AIR);
            if (onVoxelRemoved) onVoxelRemoved(v);
            spawnVoxelDebris(VoxelWorld::voxelCenter(v), m, vec3(0), 2);
        }
        return;
    }
    VoxelModel mdl;
    mdl.resize(mx - mn + 1, VOXEL_SIZE);
    for (const auto& v : comp) {
        uint8_t m = mWorld->get(v);
        mdl.set(v.x - mn.x, v.y - mn.y, v.z - mn.z, m);
    }
    for (const auto& v : comp) {
        mWorld->set(v.x, v.y, v.z, M_AIR);
        if (onVoxelRemoved) onVoxelRemoved(v);
    }
    for (int z = mn.z >> 4; z <= (mx.z >> 4); ++z)
        for (int y = mn.y >> 4; y <= (mx.y >> 4); ++y)
            for (int x = mn.x >> 4; x <= (mx.x >> 4); ++x)
                mStress.erase(((int64_t)z * VoxelWorld::CY + y) * VoxelWorld::CX + x);
    uint32_t flags = comp.size() > 400 ? OBJ_STRUCTURE : (OBJ_STRUCTURE | OBJ_DEBRIS);
    VoxelObject* o = mObjs->create(std::move(mdl), vec3(mn) * VOXEL_SIZE, quat(1, 0, 0, 0), flags, vec3(0), vec3(0), 1.0f, "Structure");
    if (o) {
        stats.collapses++;
        vec3 c = (vec3(mn + mx) * 0.5f + 0.5f) * VOXEL_SIZE;
        if (comp.size() > 150) GAudio().play(SND_COLLAPSE, c, std::min(1.0f, 0.4f + comp.size() / 4000.0f), GRng().range(0.8f, 1.1f));
        else GAudio().play(SND_CONCRETE_BREAK, c, 0.6f);
        // dust cloud along the break line
        for (int i = 0; i < std::min<int>(30, (int)comp.size() / 20 + 4); ++i) {
            const ivec3& v = comp[GRng().next() % comp.size()];
            mParts->spawn(PType::Dust, VoxelWorld::voxelCenter(v), GRng().unitVec() * 0.6f, vec4(0.6f, 0.58f, 0.54f, 0.4f), GRng().range(0.5f, 1.2f), GRng().range(2.0f, 4.0f));
        }
    }
}

void Destruction::runSupportChecks(int budget) {
    if (mSeeds.empty()) return;
    std::vector<ivec3> seeds;
    seeds.swap(mSeeds);
    int checks = 0;
    for (const auto& s : seeds) {
        if (!mWorld->get(s)) continue;
        size_t b = bit(s);
        if (mVisited[b >> 6] & (1ull << (b & 63))) continue;
        checkComponent(s);
        if (++checks >= budget) break;
    }
    for (size_t b : mTouched) mVisited[b >> 6] &= ~(1ull << (b & 63));
    mTouched.clear();
}

void Destruction::update(float dt) {
    (void)dt;
    mSoundsThisFrame = 0;
    runSupportChecks(256);
}

// ---------------------------------------------------------------- structural stress
float Destruction::weaknessAt(const ivec3& v) const {
    if (!mWorld->inBounds(v.x, v.y, v.z)) return 0;
    auto it = mStress.find(stressKey(v));
    if (it == mStress.end()) return 0;
    return it->second->w[((v.z & 15) * CHUNK + (v.y & 15)) * CHUNK + (v.x & 15)] / 255.0f;
}

void Destruction::addWeakness(const ivec3& v, float amount) {
    if (!mWorld->inBounds(v.x, v.y, v.z) || !mWorld->get(v)) return;
    if (MatInfo(mWorld->get(v)).hardness >= 10.0f) return;
    auto& sc = mStress[stressKey(v)];
    if (!sc) { sc = std::make_unique<StressChunk>(); std::memset(sc->w, 0, sizeof(sc->w)); }
    uint8_t& cell = sc->w[((v.z & 15) * CHUNK + (v.y & 15)) * CHUNK + (v.x & 15)];
    cell = (uint8_t)std::min(255, (int)cell + (int)(amount * 255));
    if (cell >= 250) {
        uint8_t m = mWorld->get(v);
        mWorld->set(v.x, v.y, v.z, M_AIR);
        spawnVoxelDebris(VoxelWorld::voxelCenter(v), m, vec3(0), 3);
        stats.voxelsDestroyed++;
        if (onVoxelRemoved) onVoxelRemoved(v);
        static const ivec3 N6[6] = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
        for (auto& n : N6) queueSupport(v + n);   // cascading failure
    }
}

void Destruction::onExternalRemoval(const ivec3& v) {
    if (!mWorld->get(v)) return;
    uint8_t m = mWorld->get(v);
    mWorld->set(v.x, v.y, v.z, M_AIR);
    spawnVoxelDebris(VoxelWorld::voxelCenter(v), m, vec3(0), 2);
    stats.voxelsDestroyed++;
    if (onVoxelRemoved) onVoxelRemoved(v);
    static const ivec3 N6[6] = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
    for (auto& n : N6) queueSupport(v + n);
}
