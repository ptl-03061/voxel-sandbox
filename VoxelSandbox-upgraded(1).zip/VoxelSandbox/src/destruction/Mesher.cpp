#include "destruction/Mesher.h"

static inline bool OpaqueAt(const PaddedVolume& v, const ivec3& p) {
    return IsOpaque(v.at(p.x, p.y, p.z));
}

void GreedyMesh(const PaddedVolume& vol, VoxMeshData& out, int scale) {
    out.clear();
    const ivec3 dims = vol.dims;
    std::vector<uint32_t> mask;
    for (int d = 0; d < 3; ++d) {
        const int u = (d + 1) % 3, v = (d + 2) % 3;
        const int su = dims[u], sv = dims[v], sd = dims[d];
        mask.assign((size_t)su * sv, 0);
        for (int s = -1; s <= 1; s += 2) {
            const int nIdx = d * 2 + (s > 0 ? 0 : 1);
            for (int i = 0; i < sd; ++i) {
                // Build mask for this slice
                for (int b = 0; b < sv; ++b) {
                    for (int a = 0; a < su; ++a) {
                        ivec3 p; p[d] = i; p[u] = a; p[v] = b;
                        uint8_t c = vol.at(p.x, p.y, p.z);
                        uint32_t key = 0;
                        if (c != M_AIR) {
                            ivec3 n = p; n[d] += s;
                            uint8_t nb = vol.at(n.x, n.y, n.z);
                            bool transp = MatInfo(c).transparent;
                            bool visible = transp ? (nb == M_AIR) : !IsOpaque(nb);
                            if (visible) {
                                uint32_t ao4 = 0xFF;
                                if (!transp) {
                                    ao4 = 0;
                                    static const int cu[4] = {-1, 1, 1, -1};
                                    static const int cv[4] = {-1, -1, 1, 1};
                                    for (int k = 0; k < 4; ++k) {
                                        ivec3 e1 = n; e1[u] += cu[k];
                                        ivec3 e2 = n; e2[v] += cv[k];
                                        ivec3 e3 = n; e3[u] += cu[k]; e3[v] += cv[k];
                                        int s1 = OpaqueAt(vol, e1), s2 = OpaqueAt(vol, e2), s3 = OpaqueAt(vol, e3);
                                        int ao = (s1 && s2) ? 0 : 3 - (s1 + s2 + s3);
                                        ao4 |= (uint32_t)ao << (k * 2);
                                    }
                                }
                                key = (uint32_t)c | (ao4 << 8) | (1u << 16) | (transp ? (1u << 17) : 0);
                            }
                        }
                        mask[(size_t)b * su + a] = key;
                    }
                }
                // Greedy merge
                for (int b = 0; b < sv; ++b) {
                    for (int a = 0; a < su;) {
                        uint32_t key = mask[(size_t)b * su + a];
                        if (!key) { ++a; continue; }
                        int w = 1;
                        while (a + w < su && mask[(size_t)b * su + a + w] == key) ++w;
                        int h = 1;
                        bool ok = true;
                        while (b + h < sv && ok) {
                            for (int k = 0; k < w; ++k)
                                if (mask[(size_t)(b + h) * su + a + k] != key) { ok = false; break; }
                            if (ok) ++h;
                        }
                        for (int hh = 0; hh < h; ++hh)
                            for (int k = 0; k < w; ++k) mask[(size_t)(b + hh) * su + a + k] = 0;

                        uint8_t mat = key & 0xFF;
                        uint32_t ao4 = (key >> 8) & 0xFF;
                        bool transp = (key >> 17) & 1;
                        ivec3 base; base[d] = i + (s > 0 ? 1 : 0); base[u] = a; base[v] = b;
                        ivec3 du(0), dv(0); du[u] = w; dv[v] = h;
                        ivec3 c[4] = {base, base + du, base + du + dv, base + dv};
                        uint32_t start = (uint32_t)out.verts.size();
                        int aoc[4];
                        for (int k = 0; k < 4; ++k) {
                            aoc[k] = transp ? 3 : (int)((ao4 >> (k * 2)) & 3);
                            VoxVertex vx;
                            vx.x = (int16_t)(c[k].x * scale); vx.y = (int16_t)(c[k].y * scale); vx.z = (int16_t)(c[k].z * scale); vx.w = 0;
                            vx.normal = (uint8_t)nIdx; vx.mat = mat; vx.ao = (uint8_t)aoc[k]; vx.flags = 0;
                            out.verts.push_back(vx);
                        }
                        auto& idx = transp ? out.glass : out.opaque;
                        bool flip = (aoc[0] + aoc[2]) < (aoc[1] + aoc[3]);
                        uint32_t q[6];
                        if (!flip) { q[0] = 0; q[1] = 1; q[2] = 2; q[3] = 0; q[4] = 2; q[5] = 3; }
                        else       { q[0] = 1; q[1] = 2; q[2] = 3; q[3] = 1; q[4] = 3; q[5] = 0; }
                        if (s < 0) { std::swap(q[1], q[2]); std::swap(q[4], q[5]); }
                        for (int k = 0; k < 6; ++k) idx.push_back(start + q[k]);
                        a += w;
                    }
                }
            }
        }
    }
}

void GreedyBoxes(const uint8_t* vox, ivec3 dims, std::vector<VoxBox>& out, int maxBoxes) {
    out.clear();
    const size_t n = (size_t)dims.x * dims.y * dims.z;
    std::vector<uint8_t> used(n, 0);
    auto idx = [&](int x, int y, int z) { return ((size_t)z * dims.y + y) * dims.x + x; };
    auto freeSolid = [&](int x, int y, int z) { size_t i = idx(x, y, z); return vox[i] != M_AIR && !used[i]; };
    for (int y = 0; y < dims.y; ++y)
        for (int z = 0; z < dims.z; ++z)
            for (int x = 0; x < dims.x; ++x) {
                if (!freeSolid(x, y, z)) continue;
                int x1 = x + 1;
                while (x1 < dims.x && freeSolid(x1, y, z)) ++x1;
                int z1 = z + 1;
                for (;;) {
                    if (z1 >= dims.z) break;
                    bool ok = true;
                    for (int xx = x; xx < x1; ++xx) if (!freeSolid(xx, y, z1)) { ok = false; break; }
                    if (!ok) break;
                    ++z1;
                }
                int y1 = y + 1;
                for (;;) {
                    if (y1 >= dims.y) break;
                    bool ok = true;
                    for (int zz = z; zz < z1 && ok; ++zz)
                        for (int xx = x; xx < x1; ++xx) if (!freeSolid(xx, y1, zz)) { ok = false; break; }
                    if (!ok) break;
                    ++y1;
                }
                double dens = 0; int cnt = 0; int matCount[M_COUNT] = {0};
                for (int yy = y; yy < y1; ++yy)
                    for (int zz = z; zz < z1; ++zz)
                        for (int xx = x; xx < x1; ++xx) {
                            size_t i = idx(xx, yy, zz);
                            used[i] = 1;
                            dens += MatInfo(vox[i]).density; ++cnt;
                            matCount[vox[i]]++;
                        }
                int best = 1;
                for (int m = 1; m < M_COUNT; ++m) if (matCount[m] > matCount[best]) best = m;
                out.push_back({ivec3(x, y, z), ivec3(x1, y1, z1), (float)(dens / cnt), (uint8_t)best});
                if ((int)out.size() >= maxBoxes) return;
            }
}
