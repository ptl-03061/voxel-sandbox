// Builds Jolt collision shapes from voxel volumes (greedy box decomposition -> static compound).
#pragma once
#include "destruction/Mesher.h"
#include <Jolt/Jolt.h>
#include <Jolt/Physics/Collision/Shape/Shape.h>

// vox: dense array (z*dy+y)*dx+x. Returns null if empty. Origin of the shape is voxel (0,0,0) corner.
JPH::RefConst<JPH::Shape> BuildVoxelShape(const uint8_t* vox, ivec3 dims, float voxelSize, int maxBoxes = 4000, int* outBoxes = nullptr);
