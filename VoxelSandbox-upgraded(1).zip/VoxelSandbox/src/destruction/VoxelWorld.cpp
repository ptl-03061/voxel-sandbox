#include "destruction/VoxelWorld.h"
#include "destruction/VoxelShape.h"
#include "core/Jobs.h"

#include <Jolt/Physics/Body/BodyCreationSettings.h>

void VoxelWorld::init(PhysicsWorld* phys) {
    mPhys = phys;
    mChunks.clear();
    mChunks.resize((size_t)CX * CY * CZ);
}

void VoxelWorld::clear(Renderer* renderer) {
    for (auto& c : mChunks) {
        if (!c) continue;
        if (renderer) renderer->forgetOcclusion(&c->occ);
        if (!c->body.IsInvalid()) { mPhys->bi().RemoveBody(c->body); mPhys->bi().DestroyBody(c->body); }
        c->mesh.release(); c->lod.release();
    }
    mChunks.clear();
    mChunks.resize((size_t)CX * CY * CZ);
    mDirty.clear();
}

Chunk* VoxelWorld::ensureChunk(int cx, int cy, int cz) {
    auto& p = mChunks[chunkIndex(cx, cy, cz)];
    if (!p) {
        p = std::make_unique<Chunk>();
        p->cpos = ivec3(cx, cy, cz);
        p->tag.type = TagType::WorldChunk;
        p->tag.ptr = p.get();
    }
    return p.get();
}

void VoxelWorld::setRaw(int x, int y, int z, uint8_t m) {
    if (!inBounds(x, y, z)) return;
    int cx = x >> 4, cy = y >> 4, cz = z >> 4;
    Chunk* c = mChunks[chunkIndex(cx, cy, cz)].get();
    if (!c) { if (m == M_AIR) return; c = ensureChunk(cx, cy, cz); }
    uint8_t& v = c->v[((z & 15) * CHUNK + (y & 15)) * CHUNK + (x & 15)];
    if (v == M_AIR && m != M_AIR) c->solid++;
    else if (v != M_AIR && m == M_AIR) c->solid--;
    v = m;
}

void VoxelWorld::markDirty(int cx, int cy, int cz) {
    Chunk* c = chunkAt(cx, cy, cz);
    if (!c) return;
    if (!c->meshDirty) { c->meshDirty = true; }
    if (!c->colDirty) { c->colDirty = true; }
    if (std::find(mDirty.begin(), mDirty.end(), c) == mDirty.end()) mDirty.push_back(c);
}

void VoxelWorld::set(int x, int y, int z, uint8_t m) {
    if (!inBounds(x, y, z)) return;
    if (get(x, y, z) == m) return;
    setRaw(x, y, z, m);
    ++mRevision;
    int cx = x >> 4, cy = y >> 4, cz = z >> 4;
    markDirty(cx, cy, cz);
    int lx = x & 15, ly = y & 15, lz = z & 15;
    // neighbors need remeshing for face visibility and AO
    if (lx == 0) markDirty(cx - 1, cy, cz);
    if (lx == 15) markDirty(cx + 1, cy, cz);
    if (ly == 0) markDirty(cx, cy - 1, cz);
    if (ly == 15) markDirty(cx, cy + 1, cz);
    if (lz == 0) markDirty(cx, cy, cz - 1);
    if (lz == 15) markDirty(cx, cy, cz + 1);
}

void VoxelWorld::fill(ivec3 a, ivec3 b, uint8_t m, bool raw) {
    ivec3 mn = glm::max(glm::min(a, b), ivec3(0)), mx = glm::min(glm::max(a, b), ivec3(SX, SY, SZ));
    for (int z = mn.z; z < mx.z; ++z)
        for (int y = mn.y; y < mx.y; ++y)
            for (int x = mn.x; x < mx.x; ++x) {
                if (raw) setRaw(x, y, z, m); else set(x, y, z, m);
            }
}

void VoxelWorld::meshChunkCpu(Chunk& c) {
    c.cpu.clear(); c.cpuLod.clear();
    if (c.solid <= 0) { c.cpuReady = true; c.pendingShape = nullptr; return; }
    ivec3 o = c.cpos * CHUNK;
    PaddedVolume vol;
    vol.resize(ivec3(CHUNK));
    for (int z = -1; z <= CHUNK; ++z)
        for (int y = -1; y <= CHUNK; ++y)
            for (int x = -1; x <= CHUNK; ++x) {
                uint8_t m;
                if (x >= 0 && y >= 0 && z >= 0 && x < CHUNK && y < CHUNK && z < CHUNK) m = c.v[(z * CHUNK + y) * CHUNK + x];
                else m = get(o.x + x, o.y + y, o.z + z);
                vol.data[vol.index(x, y, z)] = m;
            }
    GreedyMesh(vol, c.cpu, 1);
    // LOD: 2x downsample, cell is solid when at least 4 of 8 voxels are solid
    const int L = CHUNK / 2;
    PaddedVolume lv;
    lv.resize(ivec3(L));
    auto sample = [&](int lx, int ly, int lz) -> uint8_t {
        int cnt[M_COUNT] = {0}; int solid = 0;
        for (int k = 0; k < 8; ++k) {
            uint8_t m = get(o.x + lx * 2 + (k & 1), o.y + ly * 2 + ((k >> 1) & 1), o.z + lz * 2 + ((k >> 2) & 1));
            if (m) { ++solid; ++cnt[m]; }
        }
        if (solid < 4) return M_AIR;
        int best = 1;
        for (int m = 1; m < M_COUNT; ++m) if (cnt[m] > cnt[best]) best = m;
        return (uint8_t)best;
    };
    for (int z = -1; z <= L; ++z)
        for (int y = -1; y <= L; ++y)
            for (int x = -1; x <= L; ++x) lv.data[lv.index(x, y, z)] = sample(x, y, z);
    GreedyMesh(lv, c.cpuLod, 2);
    c.pendingShape = BuildVoxelShape(c.v, ivec3(CHUNK), VOXEL_SIZE, 4096);
    c.cpuReady = true;
}

void VoxelWorld::uploadChunk(Chunk& c) {
    c.mesh.upload(c.cpu);
    c.lod.upload(c.cpuLod);
    c.cpu = VoxMeshData(); c.cpuLod = VoxMeshData();
    c.meshDirty = false;
    c.cpuReady = false;
}

void VoxelWorld::rebuildCollision(Chunk& c, bool useShape) {
    auto& bi = mPhys->bi();
    if (!c.body.IsInvalid()) { bi.RemoveBody(c.body); bi.DestroyBody(c.body); c.body = JPH::BodyID(); }
    JPH::RefConst<JPH::Shape> shape = useShape ? c.pendingShape : BuildVoxelShape(c.v, ivec3(CHUNK), VOXEL_SIZE, 4096);
    c.pendingShape = nullptr;
    c.colDirty = false;
    if (!shape) return;
    vec3 o = vec3(c.cpos * CHUNK) * VOXEL_SIZE;
    JPH::BodyCreationSettings bs(shape, JPH::RVec3(o.x, o.y, o.z), JPH::Quat::sIdentity(), JPH::EMotionType::Static, Layers::STATIC);
    bs.mFriction = 0.8f;
    bs.mRestitution = 0.05f;
    bs.mUserData = (uint64_t)(uintptr_t)&c.tag;
    c.body = bi.CreateAndAddBody(bs, JPH::EActivation::DontActivate);
}

void VoxelWorld::buildAllCpu(JobPool& jobs, std::function<void(float)> progress) {
    std::vector<Chunk*> list;
    for (auto& c : mChunks) if (c) list.push_back(c.get());
    std::atomic<int> done{0};
    int n = (int)list.size();
    jobs.parallelFor(n, [&](int i) {
        meshChunkCpu(*list[i]);
        int d = done.fetch_add(1) + 1;
        if (progress && (d % 32 == 0)) progress((float)d / n);
    });
    if (progress) progress(1.0f);
}

void VoxelWorld::uploadAllGpu() {
    for (auto& c : mChunks) {
        if (!c) continue;
        if (!c->cpuReady) meshChunkCpu(*c);
        uploadChunk(*c);
        rebuildCollision(*c, true);
    }
    mPhys->sys().OptimizeBroadPhase();
    mDirty.clear();
}

void VoxelWorld::buildAll(JobPool& jobs, std::function<void(float)> progress) {
    buildAllCpu(jobs, progress);
    uploadAllGpu();
}

int VoxelWorld::updateDirty(int maxPerFrame) {
    int n = 0;
    while (!mDirty.empty() && n < maxPerFrame) {
        Chunk* c = mDirty.back();
        mDirty.pop_back();
        meshChunkCpu(*c);
        uploadChunk(*c);
        rebuildCollision(*c, true);
        ++n;
    }
    return n;
}

void VoxelWorld::render(Renderer& r, const vec3& camPos, float lodDistance, float viewDistance, bool occlusion) {
    for (auto& cp : mChunks) {
        if (!cp || cp->solid <= 0) continue;
        Chunk& c = *cp;
        AABB b = c.bounds();
        vec3 cc = b.center();
        float d = glm::distance(vec2(cc.x, cc.z), vec2(camPos.x, camPos.z));
        if (d > viewDistance + 4.0f) continue;
        bool useLod = d > lodDistance;
        const GpuMesh* m = useLod ? &c.lod : &c.mesh;
        if (m->empty()) m = &c.mesh;
        r.drawVoxel(m, mat4(1.0f), VOXEL_SIZE, vec3(c.cpos * CHUNK), b, occlusion ? &c.occ : nullptr);
    }
}

bool VoxelWorld::raycast(const vec3& from, const vec3& dir, float maxDist, ivec3& hit, ivec3& normal, float& dist) const {
    vec3 p = from / VOXEL_SIZE;
    ivec3 v = ivec3(glm::floor(p));
    ivec3 step(dir.x > 0 ? 1 : -1, dir.y > 0 ? 1 : -1, dir.z > 0 ? 1 : -1);
    vec3 tDelta(std::fabs(1.0f / (dir.x == 0 ? 1e-9f : dir.x)), std::fabs(1.0f / (dir.y == 0 ? 1e-9f : dir.y)), std::fabs(1.0f / (dir.z == 0 ? 1e-9f : dir.z)));
    vec3 tMax;
    for (int i = 0; i < 3; ++i) {
        float frac = p[i] - std::floor(p[i]);
        tMax[i] = (step[i] > 0 ? (1.0f - frac) : frac) * tDelta[i];
    }
    float maxT = maxDist / VOXEL_SIZE;
    float t = 0;
    normal = ivec3(0);
    while (t <= maxT) {
        uint8_t m = get(v);
        if (m != M_AIR) { hit = v; dist = t * VOXEL_SIZE; return true; }
        int axis = (tMax.x < tMax.y) ? (tMax.x < tMax.z ? 0 : 2) : (tMax.y < tMax.z ? 1 : 2);
        t = tMax[axis];
        tMax[axis] += tDelta[axis];
        v[axis] += step[axis];
        normal = ivec3(0); normal[axis] = -step[axis];
        if (v.y < -1 || v.y > SY + 1) break;
    }
    return false;
}
