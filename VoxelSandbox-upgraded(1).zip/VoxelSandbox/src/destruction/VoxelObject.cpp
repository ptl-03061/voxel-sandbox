#include "destruction/VoxelObject.h"
#include "destruction/VoxelShape.h"

#include <Jolt/Physics/Body/BodyCreationSettings.h>
#include <Jolt/Physics/Body/BodyLock.h>
#include <Jolt/Physics/Collision/Shape/ScaledShape.h>
#include <Jolt/Physics/PhysicsSystem.h>

using namespace JPH;

void ObjectManager::clear() {
    for (auto& o : mObjects) {
        if (o->hinge) { mPhys->sys().RemoveConstraint(o->hinge); o->hinge = nullptr; }
        if (!o->body.IsInvalid()) { mPhys->bi().RemoveBody(o->body); mPhys->bi().DestroyBody(o->body); }
        o->mesh.release();
    }
    mObjects.clear();
    pendingRemoval.clear();
}

static RefConst<Shape> MakeShape(const VoxelModel& m, float scale, int maxBoxes) {
    RefConst<Shape> s = BuildVoxelShape(m.v.data(), m.dims, m.vs, maxBoxes);
    if (!s) return nullptr;
    if (std::fabs(scale - 1.0f) > 1e-3f) s = new ScaledShape(s, Vec3::sReplicate(scale));
    return s;
}

VoxelObject* ObjectManager::create(VoxelModel&& model, const vec3& pos, const quat& rot, uint32_t flags,
                                   const vec3& linVel, const vec3& angVel, float scale, const std::string& name) {
    int solid = model.solidCount();
    if (solid == 0) return nullptr;
    auto o = std::make_unique<VoxelObject>();
    o->id = mNextId++;
    o->name = name;
    o->model = std::move(model);
    o->flags = flags;
    o->scale = scale;
    o->solid = solid;
    o->tag.type = TagType::VoxelObject;
    o->tag.ptr = o.get();
    int maxBoxes = (flags & OBJ_DEBRIS) ? 64 : 3000;
    RefConst<Shape> shape = MakeShape(o->model, scale, maxBoxes);
    if (!shape) return nullptr;
    bool kin = (flags & OBJ_KINEMATIC) != 0;
    ObjectLayer layer = (solid <= 12 && (flags & OBJ_DEBRIS)) ? Layers::DEBRIS : Layers::MOVING;
    BodyCreationSettings bs(shape, RVec3(pos.x, pos.y, pos.z), ToJ(rot), kin ? EMotionType::Kinematic : EMotionType::Dynamic, layer);
    bs.mFriction = 0.7f;
    bs.mRestitution = 0.08f;
    bs.mLinearDamping = 0.05f;
    bs.mAngularDamping = 0.1f;
    bs.mLinearVelocity = ToJ(linVel);
    bs.mAngularVelocity = ToJ(angVel);
    bs.mAllowDynamicOrKinematic = true;
    bs.mMotionQuality = (solid < 64) ? EMotionQuality::LinearCast : EMotionQuality::Discrete;
    bs.mUserData = (uint64_t)(uintptr_t)&o->tag;
    o->body = mPhys->bi().CreateAndAddBody(bs, EActivation::Activate);
    if (o->body.IsInvalid()) { LOGE("Out of bodies"); return nullptr; }
    o->mass = mPhys->massOf(o->body);
    VoxelObject* raw = o.get();
    mObjects.push_back(std::move(o));
    return raw;
}

void ObjectManager::destroy(VoxelObject* o) {
    if (!o || !o->alive) return;
    o->alive = false;
    pendingRemoval.push_back(o);
}

bool ObjectManager::rebuildShape(VoxelObject* o) {
    o->solid = o->model.solidCount();
    if (o->solid == 0) { destroy(o); return false; }
    RefConst<Shape> shape = MakeShape(o->model, o->scale, (o->flags & OBJ_DEBRIS) ? 64 : 3000);
    if (!shape) { destroy(o); return false; }
    mPhys->bi().SetShape(o->body, shape, true, EActivation::Activate);
    o->mass = mPhys->massOf(o->body);
    o->meshDirty = true;
    return true;
}

void ObjectManager::setScale(VoxelObject* o, float s) {
    s = glm::clamp(s, 0.25f, 4.0f);
    if (std::fabs(s - o->scale) < 1e-3f) return;
    o->scale = s;
    rebuildShape(o);
}

VoxelObject* ObjectManager::duplicate(VoxelObject* o, const vec3& offset) {
    VoxelModel copy = o->model;
    RMat44 t = mPhys->bi().GetWorldTransform(o->body);
    vec3 p = ToG(Vec3(t.GetTranslation())) + offset;
    quat q = ToG(t.GetQuaternion());
    return create(std::move(copy), p, q, (o->flags & ~(OBJ_DOOR | OBJ_KINEMATIC)) | OBJ_PROP, vec3(0), vec3(0), o->scale, o->name);
}

vec3 ObjectManager::worldToLocal(VoxelObject* o, const vec3& p) const {
    vec4 l = glm::inverse(o->transform) * vec4(p, 1.0f);
    return vec3(l) / o->model.vs;
}
vec3 ObjectManager::localToWorld(VoxelObject* o, const vec3& vox) const {
    return vec3(o->transform * vec4(vox * o->model.vs, 1.0f));
}

void ObjectManager::splitAndRebuild(VoxelObject* o, std::vector<VoxelObject*>* newPieces) {
    if (!o->alive) return;
    VoxelModel& m = o->model;
    const size_t n = m.v.size();
    std::vector<int> label(n, -1);
    std::vector<int> sizes;
    std::vector<ivec3> mins, maxs;
    std::vector<int> stack;
    int comps = 0;
    for (size_t i = 0; i < n; ++i) {
        if (m.v[i] == M_AIR || label[i] >= 0) continue;
        int id = comps++;
        sizes.push_back(0);
        mins.push_back(ivec3(1 << 30)); maxs.push_back(ivec3(-1));
        stack.clear(); stack.push_back((int)i); label[i] = id;
        while (!stack.empty()) {
            int c = stack.back(); stack.pop_back();
            int x = c % m.dims.x, y = (c / m.dims.x) % m.dims.y, z = c / (m.dims.x * m.dims.y);
            sizes[id]++;
            mins[id] = glm::min(mins[id], ivec3(x, y, z)); maxs[id] = glm::max(maxs[id], ivec3(x, y, z));
            const int dx[6] = {1, -1, 0, 0, 0, 0}, dy[6] = {0, 0, 1, -1, 0, 0}, dz[6] = {0, 0, 0, 0, 1, -1};
            for (int k = 0; k < 6; ++k) {
                int nx = x + dx[k], ny = y + dy[k], nz = z + dz[k];
                if (!m.in(nx, ny, nz)) continue;
                size_t ni = m.idx(nx, ny, nz);
                if (m.v[ni] != M_AIR && label[ni] < 0) { label[ni] = id; stack.push_back((int)ni); }
            }
        }
    }
    if (comps == 0) { destroy(o); return; }
    if (comps == 1 || (o->flags & OBJ_NO_SPLIT)) { rebuildShape(o); return; }

    int largest = 0;
    for (int i = 1; i < comps; ++i) if (sizes[i] > sizes[largest]) largest = i;

    BodyInterface& bi = mPhys->bi();
    RMat44 bt = bi.GetWorldTransform(o->body);
    quat rot = ToG(bt.GetQuaternion());
    Vec3 angVel = bi.GetAngularVelocity(o->body);
    for (int c = 0; c < comps; ++c) {
        if (c == largest) continue;
        ivec3 mn = mins[c], mx = maxs[c] + 1;
        VoxelModel piece;
        piece.resize(mx - mn, m.vs);
        for (int z = mn.z; z < mx.z; ++z)
            for (int y = mn.y; y < mx.y; ++y)
                for (int x = mn.x; x < mx.x; ++x) {
                    size_t i = m.idx(x, y, z);
                    if (label[i] == c) { piece.set(x - mn.x, y - mn.y, z - mn.z, m.v[i]); m.v[i] = M_AIR; }
                }
        vec3 worldOrigin = localToWorld(o, vec3(mn));
        vec3 centerW = localToWorld(o, (vec3(mn) + vec3(mx)) * 0.5f);
        vec3 vel = ToG(bi.GetPointVelocity(o->body, RVec3(centerW.x, centerW.y, centerW.z)));
        uint32_t fl = (o->flags & ~(OBJ_DOOR | OBJ_KINEMATIC)) | OBJ_DEBRIS;
        VoxelObject* p = create(std::move(piece), worldOrigin, rot, fl, vel, ToG(angVel), o->scale, o->name);
        if (p && newPieces) newPieces->push_back(p);
    }
    // a door that lost pieces may have lost its hinge side; keep it simple and let the hinge check handle it
    rebuildShape(o);
}

void ObjectManager::update(float dt, int maxObjects) {
    BodyInterface& bi = mPhys->bi();
    // enforce debris budget: remove the oldest, smallest debris first
    int debris = 0;
    for (auto& o : mObjects) if (o->alive && (o->flags & OBJ_DEBRIS)) ++debris;
    if (debris > maxObjects) {
        std::vector<VoxelObject*> cand;
        for (auto& o : mObjects) if (o->alive && (o->flags & OBJ_DEBRIS) && o->fade >= 1.0f) cand.push_back(o.get());
        std::sort(cand.begin(), cand.end(), [](VoxelObject* a, VoxelObject* b) { return a->solid * 4.0f - a->age < b->solid * 4.0f - b->age; });
        int excess = debris - maxObjects;
        for (int i = 0; i < excess && i < (int)cand.size(); ++i) cand[i]->fade = 0.999f;  // start fading
    }
    for (auto& o : mObjects) {
        if (!o->alive) continue;
        o->age += dt;
        o->impactCooldown = std::max(0.0f, o->impactCooldown - dt);
        if (o->fade < 1.0f) { o->fade -= dt * 1.5f; if (o->fade <= 0) { destroy(o.get()); continue; } }
        RMat44 t = bi.GetWorldTransform(o->body);
        o->transform = ToG(t) * glm::scale(mat4(1.0f), vec3(o->scale));
        vec3 p = vec3(o->transform[3]);
        if (p.y < -30.0f) { destroy(o.get()); continue; }
        // conservative world bounds
        vec3 half = vec3(o->model.dims) * o->model.vs * o->scale * 0.5f;
        vec3 c = vec3(o->transform * vec4(vec3(o->model.dims) * o->model.vs * 0.5f, 1.0f));
        float r = glm::length(half);
        o->bounds.mn = c - vec3(r); o->bounds.mx = c + vec3(r);
        if (o->meshDirty) {
            PaddedVolume vol;
            vol.resize(o->model.dims);
            for (int z = 0; z < o->model.dims.z; ++z)
                for (int y = 0; y < o->model.dims.y; ++y)
                    for (int x = 0; x < o->model.dims.x; ++x) vol.set(x, y, z, o->model.v[o->model.idx(x, y, z)]);
            VoxMeshData md;
            GreedyMesh(vol, md, 1);
            o->mesh.upload(md);
            o->meshDirty = false;
        }
    }
    // deferred removal
    if (!pendingRemoval.empty()) {
        for (auto* o : pendingRemoval) {
            if (o->hinge) { mPhys->sys().RemoveConstraint(o->hinge); o->hinge = nullptr; }
            if (!o->body.IsInvalid()) { bi.RemoveBody(o->body); bi.DestroyBody(o->body); o->body = BodyID(); }
            o->mesh.release();
        }
        pendingRemoval.clear();
        mObjects.erase(std::remove_if(mObjects.begin(), mObjects.end(), [](const std::unique_ptr<VoxelObject>& o) { return !o->alive; }), mObjects.end());
    }
}

void ObjectManager::render(Renderer& r, const vec3& camPos, float viewDist) {
    for (auto& o : mObjects) {
        if (!o->alive || o->mesh.empty()) continue;
        if (glm::distance(o->bounds.center(), camPos) > viewDist + glm::length(o->bounds.extent())) continue;
        mat4 m = o->transform;
        if (o->fade < 1.0f) {
            vec3 c = vec3(o->model.dims) * o->model.vs * 0.5f;
            m = m * glm::translate(mat4(1), c) * glm::scale(mat4(1), vec3(std::max(0.05f, o->fade))) * glm::translate(mat4(1), -c);
        }
        r.drawVoxel(&o->mesh, m, o->model.vs, vec3(0), o->bounds, nullptr, o->tint);
    }
}
