// Greedy voxel mesher with per-vertex ambient occlusion, and greedy box decomposition for collision.
#pragma once
#include "destruction/Voxel.h"

struct VoxVertex {
    int16_t x, y, z, w;
    uint8_t normal, mat, ao, flags;
};
static_assert(sizeof(VoxVertex) == 12, "VoxVertex must be 12 bytes");

struct VoxMeshData {
    std::vector<VoxVertex> verts;
    std::vector<uint32_t> opaque;
    std::vector<uint32_t> glass;
    void clear() { verts.clear(); opaque.clear(); glass.clear(); }
};

// Padded volume: dims are the interior size; the data array has (dims+2) per axis and
// interior voxel (x,y,z) is stored at index ((z+1)*(py)+(y+1))*(px)+(x+1).
struct PaddedVolume {
    ivec3 dims;
    std::vector<uint8_t> data;
    void resize(ivec3 d) { dims = d; data.assign((size_t)(d.x + 2) * (d.y + 2) * (d.z + 2), 0); }
    inline int index(int x, int y, int z) const { return ((z + 1) * (dims.y + 2) + (y + 1)) * (dims.x + 2) + (x + 1); }
    inline uint8_t at(int x, int y, int z) const { return data[index(x, y, z)]; }
    inline void set(int x, int y, int z, uint8_t v) { data[index(x, y, z)] = v; }
};

// scale multiplies output coordinates (used for LOD meshes built from downsampled volumes)
void GreedyMesh(const PaddedVolume& vol, VoxMeshData& out, int scale = 1);

struct VoxBox {
    ivec3 mn, mx;  // voxel coordinates, mx exclusive
    float density;
    uint8_t mat;
};
// Decompose solid voxels (dims, dense array index (z*dy+y)*dx+x) into boxes.
void GreedyBoxes(const uint8_t* vox, ivec3 dims, std::vector<VoxBox>& out, int maxBoxes = 100000);
