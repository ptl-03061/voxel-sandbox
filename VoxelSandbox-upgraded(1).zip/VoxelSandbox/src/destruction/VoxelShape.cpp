#include "destruction/VoxelShape.h"
#include <Jolt/Physics/Collision/Shape/BoxShape.h>
#include <Jolt/Physics/Collision/Shape/StaticCompoundShape.h>

JPH::RefConst<JPH::Shape> BuildVoxelShape(const uint8_t* vox, ivec3 dims, float vs, int maxBoxes, int* outBoxes) {
    std::vector<VoxBox> boxes;
    GreedyBoxes(vox, dims, boxes, maxBoxes);
    if (outBoxes) *outBoxes = (int)boxes.size();
    if (boxes.empty()) return nullptr;
    JPH::StaticCompoundShapeSettings cs;
    for (const auto& b : boxes) {
        vec3 half = vec3(b.mx - b.mn) * vs * 0.5f;
        vec3 c = vec3(b.mn) * vs + half;
        float cr = std::min(0.04f, std::min(half.x, std::min(half.y, half.z)) * 0.5f);
        auto* bs = new JPH::BoxShapeSettings(JPH::Vec3(half.x, half.y, half.z), cr);
        bs->SetDensity(std::max(50.0f, b.density));
        cs.AddShape(JPH::Vec3(c.x, c.y, c.z), JPH::Quat::sIdentity(), bs);
    }
    auto res = cs.Create();
    if (res.HasError()) { LOGE("Voxel shape error: %s", res.GetError().c_str()); return nullptr; }
    return res.Get();
}
