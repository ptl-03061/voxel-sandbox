#include "physics/Constraints.h"
#include "engine/Renderer.h"

#include <Jolt/Physics/Body/BodyCreationSettings.h>
#include <Jolt/Physics/Collision/Shape/SphereShape.h>
#include <Jolt/Physics/Constraints/DistanceConstraint.h>
#include <Jolt/Physics/Constraints/FixedConstraint.h>
#include <Jolt/Physics/Constraints/HingeConstraint.h>
#include <Jolt/Physics/Constraints/SwingTwistConstraint.h>

using namespace JPH;

void ConstraintManager::init(PhysicsWorld* phys, ObjectManager* objs) {
    mPhys = phys; mObjs = objs;
}

void ConstraintManager::clear() { mRopes.clear(); }

JPH::BodyID ConstraintManager::createLinkBody(const vec3& p, float radius) {
    BodyCreationSettings bcs(new SphereShape(std::max(0.02f, radius)), RVec3(p.x, p.y, p.z),
                             Quat::sIdentity(), EMotionType::Dynamic, Layers::MOVING);
    bcs.mLinearDamping = 0.05f;
    bcs.mAngularDamping = 0.2f;
    bcs.mFriction = 0.8f;
    return mPhys->bi().CreateAndAddBody(bcs, EActivation::Activate);
}

Rope* ConstraintManager::createRope(const vec3& a, const vec3& b, LinkStyle style,
                                    BodyID attachA, BodyID attachB, float linkRadius, float breakForce) {
    float len = glm::distance(a, b);
    if (len < 0.3f) return nullptr;
    float segLen = style == LinkStyle::Rope ? 0.55f : 0.38f;
    int n = (int)glm::clamp(len / segLen, 3.0f, 48.0f);

    auto r = std::make_unique<Rope>();
    r->id = mNextId++;
    r->style = style;
    r->linkRadius = linkRadius;
    r->breakForce = breakForce;
    r->anchorA = attachA; r->anchorB = attachB;
    r->pointA = a; r->pointB = b;

    BodyInterface& bi = mPhys->bi();
    vec3 dir = (b - a) / len;

    auto anchorBody = [&](const vec3& p) {
        BodyCreationSettings bcs(new SphereShape(0.02f), RVec3(p.x, p.y, p.z),
                                 Quat::sIdentity(), EMotionType::Static, Layers::KINEMATIC);
        return bi.CreateAndAddBody(bcs, EActivation::DontActivate);
    };

    BodyID endA = attachA.IsInvalid() ? anchorBody(a) : attachA;
    BodyID endB = attachB.IsInvalid() ? anchorBody(b) : attachB;

    BodyID prev = endA;
    for (int i = 1; i < n; ++i) {
        vec3 p = a + dir * (len * i / (float)n);
        BodyID link = createLinkBody(p, linkRadius * (style == LinkStyle::Chain ? 1.3f : 1.0f));
        if (link.IsInvalid()) break;
        Ref<Constraint> j;
        if (style == LinkStyle::Rope || style == LinkStyle::Spring) {
            DistanceConstraintSettings d;
            d.mPoint1 = bi.GetPosition(prev);
            d.mPoint2 = RVec3(0, 0, 0);
            j = d.Create(prev, link);
        } else {
            SwingTwistConstraintSettings s;
            s.mPoint1 = bi.GetPosition(prev);
            s.mPoint2 = bi.GetPosition(link);
            s.mTwistAxis1 = s.mTwistAxis2 = Vec3(dir.x, dir.y, dir.z);
            s.mNormalTwist1 = s.mNormalTwist2 = Vec3(0, 1, 0);
            j = s.Create(prev, link);
        }
        if (breakForce > 0) j->SetUserData((uint64_t)(breakForce * 100.0f));
        bi.AddConstraint(j);
        r->links.push_back(link);
        r->joints.push_back(j);
        prev = link;
    }
    if (!r->links.empty()) {
        Ref<Constraint> j;
        if (style == LinkStyle::Rope || style == LinkStyle::Spring) {
            DistanceConstraintSettings d;
            d.mPoint1 = RVec3(0, 0, 0);
            d.mPoint2 = RVec3(0, 0, 0);
            j = d.Create(prev, endB);
        } else {
            SwingTwistConstraintSettings s;
            s.mPoint1 = bi.GetPosition(prev); s.mPoint2 = bi.GetPosition(endB);
            s.mTwistAxis1 = s.mTwistAxis2 = Vec3(dir.x, dir.y, dir.z);
            s.mNormalTwist1 = s.mNormalTwist2 = Vec3(0, 1, 0);
            j = s.Create(prev, endB);
        }
        if (breakForce > 0) j->SetUserData((uint64_t)(breakForce * 100.0f));
        bi.AddConstraint(j);
        r->joints.push_back(j);
    }
    mRopes.push_back(std::move(r));
    return mRopes.back().get();
}

Ref<Constraint> ConstraintManager::createJoint(BodyID a, BodyID b, const vec3& worldAnchor,
                                               bool hinge, const vec3& axis, float breakForce) {
    BodyInterface& bi = mPhys->bi();
    Ref<Constraint> j;
    if (hinge) {
        HingeConstraintSettings h;
        h.mPoint1 = h.mPoint2 = RVec3(worldAnchor.x, worldAnchor.y, worldAnchor.z);
        h.mHingeAxis1 = h.mHingeAxis2 = Vec3(axis.x, axis.y, axis.z).Normalized();
        h.mNormalAxis1 = Vec3(0, 1, 0);
        j = h.Create(a, b);
    } else {
        FixedConstraintSettings f;
        f.mPoint1 = f.mPoint2 = RVec3(worldAnchor.x, worldAnchor.y, worldAnchor.z);
        j = f.Create(a, b);
    }
    if (breakForce > 0) j->SetUserData((uint64_t)(breakForce * 100.0f));
    bi.AddConstraint(j);
    return j;
}

void ConstraintManager::removeRope(Rope* r) {
    if (!r) return;
    BodyInterface& bi = mPhys->bi();
    for (auto& j : r->joints) bi.RemoveConstraint(j);
    for (auto id : r->links) bi.RemoveBody(id);
    for (auto id : r->links) bi.DestroyBody(id);
    r->alive = false;
}

void ConstraintManager::breakRopesNear(const vec3& c, float radius) {
    for (auto& r : mRopes) {
        if (!r->alive) continue;
        for (auto id : r->links) {
            vec3 p = ToG(mPhys->bi().GetPosition(id));
            if (glm::distance2(p, c) < radius * radius) { removeRope(r.get()); break; }
        }
    }
}

void ConstraintManager::applySpringForces(Rope& r) {
    if (r.links.empty()) return;
    BodyInterface& bi = mPhys->bi();
    BodyID idA = r.anchorA.IsInvalid() ? r.links.front() : r.anchorA;
    BodyID idB = r.anchorB.IsInvalid() ? r.links.back() : r.anchorB;
    vec3 pa = ToG(bi.GetPosition(idA));
    vec3 pb = ToG(bi.GetPosition(idB));
    float rest = glm::distance(r.pointA, r.pointB) * 0.55f;
    vec3 d = pb - pa;
    float len = glm::length(d);
    if (len < 0.01f || len <= rest) return;
    vec3 f = d / len * (len - rest) * 900.0f;
    if (bi.GetMotionType(idB) == EMotionType::Dynamic) bi.AddForce(idB, ToJ(f));
    if (bi.GetMotionType(idA) == EMotionType::Dynamic) bi.AddForce(idA, ToJ(-f));
}

void ConstraintManager::update(float dt) {
    BodyInterface& bi = mPhys->bi();
    for (auto it = mRopes.begin(); it != mRopes.end();) {
        Rope& r = **it;
        if (!r.alive) { it = mRopes.erase(it); continue; }
        if (r.style == LinkStyle::Spring) applySpringForces(r);
        if (r.breakForce > 0 && r.links.size() > 1) {
            float rest = glm::distance(r.pointA, r.pointB) / (float)(r.links.size() + 1);
            for (size_t i = 0; i + 1 < r.links.size(); ++i) {
                vec3 p0 = ToG(bi.GetPosition(r.links[i]));
                vec3 p1 = ToG(bi.GetPosition(r.links[i + 1]));
                if (glm::distance(p0, p1) > rest * 2.6f) { removeRope(&r); break; }
            }
        }
        ++it;
    }
    (void)dt;
}

void ConstraintManager::render(Renderer& r, const vec3& camPos, float viewDist) {
    BodyInterface& bi = mPhys->bi();
    for (auto& rp : mRopes) {
        Rope& rope = *rp;
        if (!rope.alive) continue;
        vec4 col = rope.style == LinkStyle::Chain ? vec4(0.25f, 0.26f, 0.3f, 1)
                 : rope.style == LinkStyle::Cable ? vec4(0.1f, 0.1f, 0.12f, 1)
                 : rope.style == LinkStyle::Spring ? vec4(0.8f, 0.3f, 0.2f, 1)
                 : vec4(0.55f, 0.42f, 0.25f, 1);
        vec3 prev = rope.anchorA.IsInvalid() ? rope.pointA : ToG(bi.GetPosition(rope.anchorA));
        if (glm::distance2(prev, camPos) > viewDist * viewDist) continue;
        float rad = rope.linkRadius * (rope.style == LinkStyle::Chain ? 1.2f : 0.9f);
        auto seg = [&](const vec3& a, const vec3& b) { r.drawCapsule(a, b, rad, col, vec4(0.6f, 0, 0, 0)); };
        for (auto id : rope.links) {
            vec3 p = ToG(bi.GetPosition(id));
            seg(prev, p);
            if (rope.style == LinkStyle::Spring) {
                vec3 mid = (prev + p) * 0.5f;
                seg(mid + vec3(0.04f, 0, 0.04f), mid - vec3(0.04f, 0, 0.04f));
            }
            prev = p;
        }
        vec3 last = rope.anchorB.IsInvalid() ? rope.pointB : ToG(bi.GetPosition(rope.anchorB));
        seg(prev, last);
    }
}
