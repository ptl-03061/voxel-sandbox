// Constraint factory: ropes, chains, cables, springs, fixed joints and hinges between physics bodies.
// Ropes/chains are built from small dynamic link bodies joined by swing constraints, so they drape,
// swing, constrain vehicles and can be torn by excessive force. All constraints are breakable.
#pragma once
#include "core/Common.h"
#include "physics/PhysicsWorld.h"

enum class LinkStyle : uint8_t { Rope, Chain, Cable, Spring };

struct Link {
    JPH::BodyID body;
};

struct Rope {
    int id = 0;
    std::string name;
    LinkStyle style = LinkStyle::Rope;
    std::vector<JPH::BodyID> links;          // link bodies, world-anchored first/last when anchorBody invalid
    std::vector<JPH::Ref<JPH::Constraint>> joints;
    JPH::BodyID anchorA, anchorB;            // optional bodies the ends attach to (invalid = world anchor)
    vec3 pointA{0}, pointB{0};               // world anchor points (used when anchor invalid or as fallback)
    float linkRadius = 0.05f;
    float breakForce = 0;                    // 0 = unbreakable
    bool alive = true;
};

class ObjectManager;
class Renderer;

class ConstraintManager {
public:
    void init(PhysicsWorld* phys, ObjectManager* objs);
    void clear();

    // Create a rope/chain/cable/spring between two points, optionally attaching to bodies.
    // If a body is given, that end follows the body (e.g. crane jib, vehicle tow point).
    Rope* createRope(const vec3& a, const vec3& b, LinkStyle style,
                     JPH::BodyID attachA = JPH::BodyID(), JPH::BodyID attachB = JPH::BodyID(),
                     float linkRadius = 0.05f, float breakForce = 0);

    // Rigid fixed joint or hinge between two existing bodies (welding, doors, mechanisms).
    JPH::Ref<JPH::Constraint> createJoint(JPH::BodyID a, JPH::BodyID b, const vec3& worldAnchor,
                                          bool hinge, const vec3& hingeAxis = vec3(0, 0, 1), float breakForce = 0);

    void removeRope(Rope* r);
    void breakRopesNear(const vec3& c, float radius);

    void update(float dt);
    void render(Renderer& r, const vec3& camPos, float viewDist);
    int ropeCount() const { return (int)mRopes.size(); }

    std::vector<std::unique_ptr<Rope>>& ropes() { return mRopes; }

private:
    JPH::BodyID createLinkBody(const vec3& p, float radius);
    void applySpringForces(Rope& r);

    PhysicsWorld* mPhys = nullptr;
    ObjectManager* mObjs = nullptr;
    int mNextId = 1;
    std::vector<std::unique_ptr<Rope>> mRopes;
};
