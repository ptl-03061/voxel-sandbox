#include "physics/PhysicsWorld.h"

#include <Jolt/Core/Factory.h>
#include <Jolt/RegisterTypes.h>
#include <Jolt/Physics/Body/BodyLock.h>
#include <Jolt/Physics/Collision/CastResult.h>
#include <Jolt/Physics/Collision/CollisionCollectorImpl.h>
#include <Jolt/Physics/Collision/RayCast.h>
#include <Jolt/Physics/Collision/BroadPhase/BroadPhaseQuery.h>

#include <cstdarg>
#include <thread>

using namespace JPH;

namespace BPL {
static constexpr BroadPhaseLayer NON_MOVING(0);
static constexpr BroadPhaseLayer MOVING(1);
static constexpr uint NUM = 2;
}

class BPLayerInterfaceImpl final : public BroadPhaseLayerInterface {
public:
    uint GetNumBroadPhaseLayers() const override { return BPL::NUM; }
    BroadPhaseLayer GetBroadPhaseLayer(ObjectLayer l) const override {
        return (l == Layers::STATIC) ? BPL::NON_MOVING : BPL::MOVING;
    }
#if defined(JPH_EXTERNAL_PROFILE) || defined(JPH_PROFILE_ENABLED)
    const char* GetBroadPhaseLayerName(BroadPhaseLayer l) const override { return l == BPL::NON_MOVING ? "NON_MOVING" : "MOVING"; }
#endif
};

class ObjVsBPFilter final : public ObjectVsBroadPhaseLayerFilter {
public:
    bool ShouldCollide(ObjectLayer l, BroadPhaseLayer bp) const override {
        if (l == Layers::STATIC) return bp == BPL::MOVING;
        return true;
    }
};

class ObjPairFilter final : public ObjectLayerPairFilter {
public:
    bool ShouldCollide(ObjectLayer a, ObjectLayer b) const override {
        if (a == Layers::STATIC) return b != Layers::STATIC && b != Layers::KINEMATIC;
        if (b == Layers::STATIC) return a != Layers::KINEMATIC;
        if (a == Layers::DEBRIS && b == Layers::DEBRIS) return false;
        if (a == Layers::KINEMATIC && b == Layers::KINEMATIC) return false;
        return true;
    }
};

struct PhysicsWorld::Impl : public ContactListener {
    BPLayerInterfaceImpl bpInterface;
    ObjVsBPFilter objVsBp;
    ObjPairFilter pairFilter;
    std::mutex mutex;
    std::vector<ContactEvent> events;

    void OnContactAdded(const Body& b1, const Body& b2, const ContactManifold& m, ContactSettings&) override {
        if (m.mRelativeContactPointsOn1.empty()) return;
        RVec3 p = m.GetWorldSpaceContactPointOn1(0);
        Vec3 rel = b1.GetPointVelocity(p) - b2.GetPointVelocity(p);
        float sp = std::fabs(rel.Dot(m.mWorldSpaceNormal));
        if (sp < 0.8f) return;
        std::lock_guard<std::mutex> l(mutex);
        if (events.size() > 2048) return;
        events.push_back({b1.GetID(), b2.GetID(), ToG(Vec3(p)), ToG(m.mWorldSpaceNormal), sp});
    }
};

static void TraceImpl(const char* fmt, ...) {
    va_list list; va_start(list, fmt); char buf[1024]; vsnprintf(buf, sizeof(buf), fmt, list); va_end(list);
    LOGI("Jolt: %s", buf);
}

bool PhysicsWorld::init(int workerThreads) {
    RegisterDefaultAllocator();
    Trace = TraceImpl;
    Factory::sInstance = new Factory();
    RegisterTypes();
    mImpl = new Impl();
    mTemp = std::make_unique<TempAllocatorImpl>(24 * 1024 * 1024);
    mJobs = std::make_unique<JobSystemThreadPool>(cMaxPhysicsJobs, cMaxPhysicsBarriers, std::max(1, workerThreads));
    mSystem = std::make_unique<PhysicsSystem>();
    mSystem->Init(8192, 0, 16384, 16384, mImpl->bpInterface, mImpl->objVsBp, mImpl->pairFilter);
    mSystem->SetContactListener(mImpl);
    mSystem->SetGravity(ToJ(mGravity));
    PhysicsSettings ps = mSystem->GetPhysicsSettings();
    ps.mNumVelocitySteps = 8;
    ps.mNumPositionSteps = 2;
    ps.mTimeBeforeSleep = 0.6f;
    mSystem->SetPhysicsSettings(ps);
    LOGI("Physics initialized with %d worker threads", workerThreads);
    return true;
}

void PhysicsWorld::shutdown() {
    mSystem.reset();
    mJobs.reset();
    mTemp.reset();
    delete mImpl; mImpl = nullptr;
    UnregisterTypes();
    delete Factory::sInstance; Factory::sInstance = nullptr;
}

void PhysicsWorld::setGravity(const vec3& g) { mGravity = g; mSystem->SetGravity(ToJ(g)); }

void PhysicsWorld::step(float dt, int collisionSteps) {
    mSystem->Update(dt, collisionSteps, mTemp.get(), mJobs.get());
}

void PhysicsWorld::takeContacts(std::vector<ContactEvent>& out) {
    std::lock_guard<std::mutex> l(mImpl->mutex);
    out.swap(mImpl->events);
    mImpl->events.clear();
}

PhysTag* PhysicsWorld::tagOf(BodyID id) {
    if (id.IsInvalid()) return nullptr;
    return reinterpret_cast<PhysTag*>(bi().GetUserData(id));
}

float PhysicsWorld::massOf(BodyID id) {
    BodyLockRead lock(mSystem->GetBodyLockInterface(), id);
    if (!lock.Succeeded()) return 0;
    const Body& b = lock.GetBody();
    if (!b.IsDynamic()) return 1e9f;
    float inv = b.GetMotionProperties()->GetInverseMass();
    return inv > 0 ? 1.0f / inv : 1e9f;
}

bool PhysicsWorld::raycast(const vec3& from, const vec3& dir, float maxDist, RayHit& hit, BodyID ignore, bool includeAll) {
    RRayCast ray{RVec3(from.x, from.y, from.z), ToJ(dir * maxDist)};
    RayCastResult res;
    IgnoreSingleBodyFilter bodyFilter(ignore);
    class LayerFilter : public ObjectLayerFilter {
    public:
        bool all;
        bool ShouldCollide(ObjectLayer l) const override { return all || (l != Layers::RAGDOLL); }
    } lf;
    lf.all = includeAll;
    if (!mSystem->GetNarrowPhaseQuery().CastRay(ray, res, {}, lf, bodyFilter)) return false;
    hit.body = res.mBodyID;
    hit.dist = res.mFraction * maxDist;
    hit.point = from + dir * hit.dist;
    BodyLockRead lock(mSystem->GetBodyLockInterface(), res.mBodyID);
    if (lock.Succeeded()) {
        hit.normal = ToG(lock.GetBody().GetWorldSpaceSurfaceNormal(res.mSubShapeID2, RVec3(hit.point.x, hit.point.y, hit.point.z)));
        hit.tag = reinterpret_cast<PhysTag*>(lock.GetBody().GetUserData());
    } else {
        hit.normal = -dir;
        hit.tag = nullptr;
    }
    return true;
}

void PhysicsWorld::bodiesInSphere(const vec3& c, float r, std::vector<BodyID>& out) {
    out.clear();
    AllHitCollisionCollector<CollideShapeBodyCollector> col;
    mSystem->GetBroadPhaseQuery().CollideSphere(ToJ(c), r, col);
    for (auto& h : col.mHits) out.push_back(h);
}

void PhysicsWorld::bodiesInBox(const vec3& mn, const vec3& mx, std::vector<BodyID>& out) {
    out.clear();
    AllHitCollisionCollector<CollideShapeBodyCollector> col;
    mSystem->GetBroadPhaseQuery().CollideAABox(AABox(ToJ(mn), ToJ(mx)), col);
    for (auto& h : col.mHits) out.push_back(h);
}
