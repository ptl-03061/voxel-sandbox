// Jolt Physics integration: system setup, layers, contact event collection and query helpers.
#pragma once
#include "core/Common.h"

#include <Jolt/Jolt.h>
#include <Jolt/Core/JobSystemThreadPool.h>
#include <Jolt/Core/TempAllocator.h>
#include <Jolt/Physics/Body/BodyActivationListener.h>
#include <Jolt/Physics/Body/BodyCreationSettings.h>
#include <Jolt/Physics/Collision/BroadPhase/BroadPhaseLayer.h>
#include <Jolt/Physics/Collision/ContactListener.h>
#include <Jolt/Physics/Collision/ObjectLayer.h>
#include <Jolt/Physics/PhysicsSystem.h>

#include <mutex>

namespace Layers {
constexpr JPH::ObjectLayer STATIC = 0;
constexpr JPH::ObjectLayer MOVING = 1;
constexpr JPH::ObjectLayer DEBRIS = 2;   // small fragments: collide with world + moving, not with each other
constexpr JPH::ObjectLayer RAGDOLL = 3;
constexpr JPH::ObjectLayer VEHICLE = 4;
constexpr JPH::ObjectLayer KINEMATIC = 5; // moving platforms, doors frames etc.
constexpr JPH::ObjectLayer NUM = 6;
}

enum class TagType : uint8_t { None, WorldChunk, VoxelObject, RagdollPart, Vehicle, Projectile, Platform, Prop };
struct PhysTag {
    TagType type = TagType::None;
    void* ptr = nullptr;
    int index = 0;
};

struct ContactEvent {
    JPH::BodyID a, b;
    vec3 point, normal;
    float speed;      // relative normal speed at contact (m/s)
};

inline JPH::Vec3 ToJ(const vec3& v) { return JPH::Vec3(v.x, v.y, v.z); }
inline vec3 ToG(const JPH::Vec3& v) { return vec3(v.GetX(), v.GetY(), v.GetZ()); }
inline JPH::Quat ToJ(const quat& q) { return JPH::Quat(q.x, q.y, q.z, q.w); }
inline quat ToG(const JPH::Quat& q) { return quat(q.GetW(), q.GetX(), q.GetY(), q.GetZ()); }
inline mat4 ToG(const JPH::RMat44& m) {
    mat4 r;
    for (int c = 0; c < 4; ++c) {
        JPH::Vec4 col = c < 3 ? m.GetColumn4(c) : JPH::Vec4(m.GetTranslation(), 1.0f);
        r[c] = vec4(col.GetX(), col.GetY(), col.GetZ(), col.GetW());
    }
    return r;
}

struct RayHit {
    JPH::BodyID body;
    vec3 point, normal;
    float dist = 0;
    PhysTag* tag = nullptr;
};

class PhysicsWorld {
public:
    bool init(int workerThreads);
    void shutdown();
    void step(float dt, int collisionSteps);

    JPH::PhysicsSystem& sys() { return *mSystem; }
    JPH::BodyInterface& bi() { return mSystem->GetBodyInterface(); }
    JPH::TempAllocator& temp() { return *mTemp; }

    void takeContacts(std::vector<ContactEvent>& out);
    bool raycast(const vec3& from, const vec3& dir, float maxDist, RayHit& hit, JPH::BodyID ignore = JPH::BodyID(), bool includeSensorsAndRagdolls = true);
    void bodiesInSphere(const vec3& c, float r, std::vector<JPH::BodyID>& out);
    void bodiesInBox(const vec3& mn, const vec3& mx, std::vector<JPH::BodyID>& out);
    PhysTag* tagOf(JPH::BodyID id);
    float massOf(JPH::BodyID id);

    vec3 gravity() const { return mGravity; }
    void setGravity(const vec3& g);

private:
    vec3 mGravity{0, -9.81f, 0};
    std::unique_ptr<JPH::PhysicsSystem> mSystem;
    std::unique_ptr<JPH::TempAllocatorImpl> mTemp;
    std::unique_ptr<JPH::JobSystemThreadPool> mJobs;
    struct Impl;
    Impl* mImpl = nullptr;
};
