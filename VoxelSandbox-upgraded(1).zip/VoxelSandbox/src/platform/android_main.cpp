// Android entry point: NativeActivity + native_app_glue, EGL / OpenGL ES 3 context, multi-touch input,
// AAudio low-latency output, AAssetManager asset access and app lifecycle handling.
#include "Game.h"

#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <aaudio/AAudio.h>
#include <android/asset_manager.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <jni.h>
#include <sys/stat.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstdarg>
#include <thread>

#define TAG "VoxelSandbox"

static android_app* gApp = nullptr;
static std::string gDataDir;

void LogInfo(const char* fmt, ...) { va_list a; va_start(a, fmt); __android_log_vprint(ANDROID_LOG_INFO, TAG, fmt, a); va_end(a); }
void LogError(const char* fmt, ...) { va_list a; va_start(a, fmt); __android_log_vprint(ANDROID_LOG_ERROR, TAG, fmt, a); va_end(a); }

namespace Platform {
bool ReadAsset(const std::string& path, std::vector<uint8_t>& out) {
    if (!gApp) return false;
    AAsset* a = AAssetManager_open(gApp->activity->assetManager, path.c_str(), AASSET_MODE_BUFFER);
    if (!a) return false;
    size_t n = (size_t)AAsset_getLength(a);
    out.resize(n);
    int r = n ? AAsset_read(a, out.data(), n) : 0;
    AAsset_close(a);
    return r == (int)n;
}
std::string ReadAssetText(const std::string& path) {
    std::vector<uint8_t> d;
    if (!ReadAsset(path, d)) return "";
    return std::string(d.begin(), d.end());
}
std::string WritableDir() { return gDataDir; }
double TimeSeconds() {
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}
void RequestQuit() { if (gApp) ANativeActivity_finish(gApp->activity); }
}

// ------------------------------------------------------------------------------------------- audio
static AAudioStream* gStream = nullptr;
static std::atomic<bool> gAudioRunning{false};
static std::atomic<bool> gGameReady{false};   // mixer is usable only after Game::init

static aaudio_data_callback_result_t AudioCallback(AAudioStream*, void*, void* data, int32_t frames) {
    float* out = (float*)data;
    if (gAudioRunning && gGameReady) GAudio().mix(out, frames);
    else std::fill(out, out + frames * 2, 0.0f);
    return AAUDIO_CALLBACK_RESULT_CONTINUE;
}
static void StartAudio();
static void AudioError(AAudioStream*, void*, aaudio_result_t err) {
    LogError("AAudio error %d, restarting stream", (int)err);
    // must not reopen inside the callback thread
    std::thread([] {
        if (gStream) { AAudioStream_requestStop(gStream); AAudioStream_close(gStream); gStream = nullptr; }
        StartAudio();
    }).detach();
}
static void StartAudio() {
    if (gStream) return;
    AAudioStreamBuilder* b = nullptr;
    if (AAudio_createStreamBuilder(&b) != AAUDIO_OK) { LogError("AAudio builder failed"); return; }
    AAudioStreamBuilder_setFormat(b, AAUDIO_FORMAT_PCM_FLOAT);
    AAudioStreamBuilder_setChannelCount(b, 2);
    AAudioStreamBuilder_setSampleRate(b, Audio::RATE);
    AAudioStreamBuilder_setPerformanceMode(b, AAUDIO_PERFORMANCE_MODE_LOW_LATENCY);
    AAudioStreamBuilder_setSharingMode(b, AAUDIO_SHARING_MODE_SHARED);
    AAudioStreamBuilder_setDataCallback(b, AudioCallback, nullptr);
    AAudioStreamBuilder_setErrorCallback(b, AudioError, nullptr);
    aaudio_result_t r = AAudioStreamBuilder_openStream(b, &gStream);
    AAudioStreamBuilder_delete(b);
    if (r != AAUDIO_OK) { LogError("AAudio open failed: %s", AAudio_convertResultToText(r)); gStream = nullptr; return; }
    if (AAudioStream_getSampleRate(gStream) != Audio::RATE || AAudioStream_getFormat(gStream) != AAUDIO_FORMAT_PCM_FLOAT) {
        // the mixer only produces 48 kHz float; the shared-mode resampler normally guarantees this
        LogError("AAudio stream format mismatch (%d Hz)", AAudioStream_getSampleRate(gStream));
    }
    gAudioRunning = true;
    AAudioStream_requestStart(gStream);
    LogInfo("AAudio started: %d Hz, burst %d", AAudioStream_getSampleRate(gStream), AAudioStream_getFramesPerBurst(gStream));
}
static void StopAudio() {
    gAudioRunning = false;
    if (!gStream) return;
    AAudioStream_requestStop(gStream);
    AAudioStream_close(gStream);
    gStream = nullptr;
}

// ------------------------------------------------------------------------------------------- EGL
struct Engine {
    Game game;
    EGLDisplay display = EGL_NO_DISPLAY;
    EGLSurface surface = EGL_NO_SURFACE;
    EGLContext context = EGL_NO_CONTEXT;
    EGLConfig config = nullptr;
    int width = 0, height = 0;
    bool gameReady = false;
    bool resumed = false;
    bool focused = false;
    double lastTime = 0;
};

static bool InitDisplay(Engine& e) {
    if (e.display == EGL_NO_DISPLAY) {
        e.display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
        eglInitialize(e.display, nullptr, nullptr);
        const EGLint attribs[] = {EGL_RENDERABLE_TYPE, 0x0040 /*EGL_OPENGL_ES3_BIT*/, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                                  EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
        EGLint n = 0;
        if (!eglChooseConfig(e.display, attribs, &e.config, 1, &n) || n == 0) {
            const EGLint fallback[] = {EGL_RENDERABLE_TYPE, 0x0040, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                                       EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_DEPTH_SIZE, 16, EGL_NONE};
            if (!eglChooseConfig(e.display, fallback, &e.config, 1, &n) || n == 0) { LogError("no EGL config"); return false; }
        }
    }
    if (e.context == EGL_NO_CONTEXT) {
        const EGLint ctx[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
        e.context = eglCreateContext(e.display, e.config, EGL_NO_CONTEXT, ctx);
        if (e.context == EGL_NO_CONTEXT) { LogError("eglCreateContext failed 0x%x", eglGetError()); return false; }
    }
    EGLint fmt;
    eglGetConfigAttrib(e.display, e.config, EGL_NATIVE_VISUAL_ID, &fmt);
    ANativeWindow_setBuffersGeometry(gApp->window, 0, 0, fmt);
    e.surface = eglCreateWindowSurface(e.display, e.config, gApp->window, nullptr);
    if (e.surface == EGL_NO_SURFACE) { LogError("eglCreateWindowSurface failed 0x%x", eglGetError()); return false; }
    if (!eglMakeCurrent(e.display, e.surface, e.surface, e.context)) {
        EGLint err = eglGetError();
        LogError("eglMakeCurrent failed 0x%x", err);
        if (err == EGL_CONTEXT_LOST) {
            // context lost: everything must be recreated
            eglDestroyContext(e.display, e.context);
            e.context = EGL_NO_CONTEXT;
            e.gameReady = false;
            eglDestroySurface(e.display, e.surface);
            e.surface = EGL_NO_SURFACE;
            return InitDisplay(e);
        }
        return false;
    }
    eglSwapInterval(e.display, 1);
    eglQuerySurface(e.display, e.surface, EGL_WIDTH, &e.width);
    eglQuerySurface(e.display, e.surface, EGL_HEIGHT, &e.height);
    LogInfo("EGL surface %dx%d  GL %s / %s", e.width, e.height, glGetString(GL_VERSION), glGetString(GL_RENDERER));
    if (!e.gameReady) {
        if (!e.game.init(e.width, e.height)) { LogError("game init failed"); return false; }
        e.gameReady = true;
        gGameReady = true;
    } else {
        e.game.resize(e.width, e.height);
    }
    e.lastTime = Platform::TimeSeconds();
    return true;
}

static void TermSurface(Engine& e) {
    // keep the context (and all GL objects) alive across window loss; only the surface goes away
    if (e.display != EGL_NO_DISPLAY) {
        eglMakeCurrent(e.display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (e.surface != EGL_NO_SURFACE) eglDestroySurface(e.display, e.surface);
    }
    e.surface = EGL_NO_SURFACE;
}

static void TermAll(Engine& e) {
    gGameReady = false;
    if (e.gameReady && e.surface != EGL_NO_SURFACE) {
        e.game.shutdown();
        e.gameReady = false;
    }
    TermSurface(e);
    if (e.display != EGL_NO_DISPLAY) {
        if (e.context != EGL_NO_CONTEXT) eglDestroyContext(e.display, e.context);
        eglTerminate(e.display);
    }
    e.context = EGL_NO_CONTEXT;
    e.display = EGL_NO_DISPLAY;
}

// ------------------------------------------------------------------------------------------- immersive mode
static void SetImmersive(android_app* app) {
    JNIEnv* env = nullptr;
    JavaVM* vm = app->activity->vm;
    if (vm->AttachCurrentThread(&env, nullptr) != JNI_OK || !env) return;
    jobject activity = app->activity->clazz;
    jclass actCls = env->GetObjectClass(activity);
    jmethodID getWindow = env->GetMethodID(actCls, "getWindow", "()Landroid/view/Window;");
    jobject window = env->CallObjectMethod(activity, getWindow);
    if (window) {
        jclass winCls = env->GetObjectClass(window);
        jmethodID getDecor = env->GetMethodID(winCls, "getDecorView", "()Landroid/view/View;");
        jobject decor = env->CallObjectMethod(window, getDecor);
        if (decor) {
            jclass viewCls = env->GetObjectClass(decor);
            jmethodID setVis = env->GetMethodID(viewCls, "setSystemUiVisibility", "(I)V");
            // LAYOUT_STABLE|LAYOUT_HIDE_NAV|LAYOUT_FULLSCREEN|HIDE_NAV|FULLSCREEN|IMMERSIVE_STICKY
            const int flags = 0x00000100 | 0x00000200 | 0x00000400 | 0x00000002 | 0x00000004 | 0x00001000;
            if (setVis) env->CallVoidMethod(decor, setVis, flags);
            env->DeleteLocalRef(viewCls);
            env->DeleteLocalRef(decor);
        }
        // keep the screen on while playing (FLAG_KEEP_SCREEN_ON = 0x80)
        jmethodID addFlags = env->GetMethodID(winCls, "addFlags", "(I)V");
        if (addFlags) env->CallVoidMethod(window, addFlags, 0x80);
        env->DeleteLocalRef(winCls);
        env->DeleteLocalRef(window);
    }
    env->DeleteLocalRef(actCls);
    if (env->ExceptionCheck()) env->ExceptionClear();
    vm->DetachCurrentThread();
}

// ------------------------------------------------------------------------------------------- callbacks
static void HandleCmd(android_app* app, int32_t cmd) {
    Engine& e = *(Engine*)app->userData;
    switch (cmd) {
    case APP_CMD_INIT_WINDOW:
        if (app->window) {
            InitDisplay(e);
            SetImmersive(app);
        }
        break;
    case APP_CMD_TERM_WINDOW:
        TermSurface(e);
        break;
    case APP_CMD_WINDOW_RESIZED:
    case APP_CMD_CONFIG_CHANGED:
    case APP_CMD_CONTENT_RECT_CHANGED:
        if (e.surface != EGL_NO_SURFACE) {
            int w = 0, h = 0;
            eglQuerySurface(e.display, e.surface, EGL_WIDTH, &w);
            eglQuerySurface(e.display, e.surface, EGL_HEIGHT, &h);
            if ((w != e.width || h != e.height) && w > 0 && h > 0) { e.width = w; e.height = h; e.game.resize(w, h); }
        }
        break;
    case APP_CMD_GAINED_FOCUS:
        e.focused = true;
        SetImmersive(app);
        break;
    case APP_CMD_LOST_FOCUS:
        e.focused = false;
        break;
    case APP_CMD_RESUME:
        e.resumed = true;
        if (e.gameReady) e.game.onResume();
        StartAudio();
        e.lastTime = Platform::TimeSeconds();
        break;
    case APP_CMD_PAUSE:
        e.resumed = false;
        if (e.gameReady) e.game.onPause();
        StopAudio();
        break;
    case APP_CMD_SAVE_STATE:
        if (e.gameReady) e.game.saveSettings();
        break;
    case APP_CMD_LOW_MEMORY:
        LogInfo("low memory warning");
        break;
    case APP_CMD_DESTROY:
        break;
    default: break;
    }
}

static int32_t HandleInput(android_app* app, AInputEvent* ev) {
    Engine& e = *(Engine*)app->userData;
    int32_t type = AInputEvent_getType(ev);
    if (type == AINPUT_EVENT_TYPE_KEY) {
        int32_t key = AKeyEvent_getKeyCode(ev);
        if (key == AKEYCODE_BACK) {
            if (AKeyEvent_getAction(ev) == AKEY_EVENT_ACTION_UP) e.game.input.backPressed = true;
            return 1;   // consumed: the game decides (close panel / pause / quit from main menu)
        }
        return 0;
    }
    if (type != AINPUT_EVENT_TYPE_MOTION) return 0;
    int32_t action = AMotionEvent_getAction(ev);
    int32_t act = action & AMOTION_EVENT_ACTION_MASK;
    size_t idx = (size_t)((action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT);
    size_t count = AMotionEvent_getPointerCount(ev);
    Input& in = e.game.input;
    switch (act) {
    case AMOTION_EVENT_ACTION_DOWN:
    case AMOTION_EVENT_ACTION_POINTER_DOWN:
        in.touchDown(AMotionEvent_getPointerId(ev, idx), AMotionEvent_getX(ev, idx), AMotionEvent_getY(ev, idx));
        break;
    case AMOTION_EVENT_ACTION_MOVE:
        for (size_t i = 0; i < count; ++i)
            in.touchMove(AMotionEvent_getPointerId(ev, i), AMotionEvent_getX(ev, i), AMotionEvent_getY(ev, i));
        break;
    case AMOTION_EVENT_ACTION_UP:
    case AMOTION_EVENT_ACTION_POINTER_UP:
        in.touchUp(AMotionEvent_getPointerId(ev, idx), AMotionEvent_getX(ev, idx), AMotionEvent_getY(ev, idx));
        break;
    case AMOTION_EVENT_ACTION_CANCEL:
        for (size_t i = 0; i < count; ++i)
            in.touchUp(AMotionEvent_getPointerId(ev, i), AMotionEvent_getX(ev, i), AMotionEvent_getY(ev, i));
        break;
    default: break;
    }
    return 1;
}

void android_main(android_app* app) {
    gApp = app;
    gDataDir = app->activity->internalDataPath ? app->activity->internalDataPath : "/data/local/tmp";
    mkdir(gDataDir.c_str(), 0755);
    LogInfo("VoxelSandbox starting, data dir %s", gDataDir.c_str());

    static Engine engine;   // static: survives activity recreation in the same process
    Engine& e = engine;
    app->userData = &e;
    app->onAppCmd = HandleCmd;
    app->onInputEvent = HandleInput;

    while (true) {
        int events;
        android_poll_source* source;
        bool active = e.resumed && e.surface != EGL_NO_SURFACE && e.gameReady;
        // block while in the background, poll while rendering
        while (ALooper_pollOnce(active ? 0 : -1, nullptr, &events, (void**)&source) >= 0) {
            if (source) source->process(app, source);
            if (app->destroyRequested) {
                StopAudio();
                if (e.gameReady) e.game.saveSettings();
                TermAll(e);
                LogInfo("VoxelSandbox exiting");
                return;
            }
            active = e.resumed && e.surface != EGL_NO_SURFACE && e.gameReady;
            if (active) break;
        }
        if (!active) continue;

        double frameStart = Platform::TimeSeconds();
        float dt = (float)(frameStart - e.lastTime);
        e.lastTime = frameStart;
        dt = glm::clamp(dt, 0.001f, 0.1f);
        e.game.frame(dt);
        if (!eglSwapBuffers(e.display, e.surface)) {
            EGLint err = eglGetError();
            if (err == EGL_BAD_SURFACE || err == EGL_BAD_NATIVE_WINDOW) TermSurface(e);
            else if (err == EGL_CONTEXT_LOST) { LogError("GL context lost"); TermAll(e); }
        }
        // FPS limiter (vsync already caps at the display rate)
        int limit = std::max(20, e.game.settings.fpsLimit);
        double target = 1.0 / limit;
        double spent = Platform::TimeSeconds() - frameStart;
        if (spent < target - 0.002) std::this_thread::sleep_for(std::chrono::duration<double>(target - spent - 0.001));
    }
}
