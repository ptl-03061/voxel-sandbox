// Headless desktop test harness. Creates an offscreen OpenGL ES 3 context (Mesa EGL pbuffer), runs the real
// game code with scripted touch input and writes screenshots + a test report. Used to verify rendering,
// physics, destruction, ragdolls, vehicles and long-run stability without an Android device.
#include "Game.h"
#include "ui/UI.h"

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <chrono>
#include <cstdarg>
#include <cstdio>
#include <fstream>
#include <sys/stat.h>
#include <execinfo.h>
#include <exception>

static std::string gAssetDir = "assets";
static bool gQuit = false;
static double gSimTime = 0;   // harness uses simulated time so tests are deterministic in pacing
static bool gRealTime = false;

void LogInfo(const char* fmt, ...) { va_list a; va_start(a, fmt); printf("[I] "); vprintf(fmt, a); printf("\n"); va_end(a); fflush(stdout); }
void LogError(const char* fmt, ...) { va_list a; va_start(a, fmt); printf("[E] "); vprintf(fmt, a); printf("\n"); va_end(a); fflush(stdout); }

namespace Platform {
bool ReadAsset(const std::string& path, std::vector<uint8_t>& out) {
    std::ifstream f(gAssetDir + "/" + path, std::ios::binary);
    if (!f) return false;
    out.assign(std::istreambuf_iterator<char>(f), std::istreambuf_iterator<char>());
    return true;
}
std::string ReadAssetText(const std::string& path) {
    std::vector<uint8_t> d;
    if (!ReadAsset(path, d)) return "";
    return std::string(d.begin(), d.end());
}
std::string WritableDir() { mkdir("desktop_data", 0755); return "desktop_data"; }
double TimeSeconds() {
    if (!gRealTime) return gSimTime;  // deterministic test pacing
    using namespace std::chrono;
    return duration<double>(steady_clock::now().time_since_epoch()).count();
}
void RequestQuit() { gQuit = true; }
}

static double WallMs() {
    using namespace std::chrono;
    return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

struct Harness {
    Game game;
    int W = 1280, H = 720;
    std::string shotDir = "shots";
    int frameNo = 0;
    int failures = 0;
    std::vector<std::string> report;
    float dt = 1.0f / 30.0f;
    std::vector<float> frameTimes;

    void frame() {
        double t0 = WallMs();
        gSimTime += dt;
        game.frame(dt);
        // run the audio mixer like the audio thread would
        static std::vector<float> buf;
        int n = (int)(Audio::RATE * dt);
        buf.resize(n * 2);
        GAudio().mix(buf.data(), n);
        for (float v : buf) if (!std::isfinite(v)) { fail("audio produced NaN"); break; }
        frameTimes.push_back((float)(WallMs() - t0));
        ++frameNo;
    }
    void run(float seconds) { int n = (int)(seconds / dt + 0.5f); for (int i = 0; i < n; ++i) frame(); }
    void check(bool ok, const std::string& what) {
        report.push_back(std::string(ok ? "PASS  " : "FAIL  ") + what);
        LogInfo("%s %s", ok ? "PASS" : "FAIL", what.c_str());
        if (!ok) ++failures;
    }
    void fail(const std::string& w) { check(false, w); }
    void shot(const std::string& name) {
        std::vector<uint8_t> px((size_t)W * H * 4);
        glReadPixels(0, 0, W, H, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
        std::string path = shotDir + "/" + name + ".ppm";
        FILE* f = fopen(path.c_str(), "wb");
        if (!f) return;
        fprintf(f, "P6\n%d %d\n255\n", W, H);
        std::vector<uint8_t> row((size_t)W * 3);
        double lum = 0;
        for (int y = H - 1; y >= 0; --y) {
            for (int x = 0; x < W; ++x) {
                const uint8_t* p = &px[((size_t)y * W + x) * 4];
                row[x * 3] = p[0]; row[x * 3 + 1] = p[1]; row[x * 3 + 2] = p[2];
                lum += p[0] + p[1] + p[2];
            }
            fwrite(row.data(), 1, row.size(), f);
        }
        fclose(f);
        LogInfo("screenshot %s (mean %.1f)", path.c_str(), lum / ((double)W * H * 3));
    }
    // touch helpers (pointer ids 0..9)
    void tap(vec2 p, int id = 5) {
        game.input.touchDown(id, p.x, p.y); frame();
        game.input.touchUp(id, p.x, p.y); frame();
    }
    void holdButton(const std::string& label, float seconds, int pid = 6) {
        const UI::Btn* b = nullptr;
        for (auto& x : game.ui->buttons()) if (x.label == label) b = &x;
        if (!b) { fail("button " + label + " not present"); return; }
        vec2 p = b->c;
        game.input.touchDown(pid, p.x, p.y);
        run(seconds);
        game.input.touchUp(pid, p.x, p.y);
        frame();
    }
    bool tapButton(const std::string& label) {
        for (auto& b : game.ui->buttons())
            if (b.label == label) { tap(b.c); return true; }
        fail("HUD button '" + label + "' not found");
        return false;
    }
    void lookAt(const vec3& target) {
        vec3 d = glm::normalize(target - game.player.eye());
        game.player.yaw = std::atan2(d.x, d.z);
        game.player.pitch = std::asin(glm::clamp(d.y, -1.0f, 1.0f));
    }
    void place(const vec3& feet, const vec3& target) {
        game.player.teleport(feet);
        run(0.2f);
        lookAt(target);
        frame();
    }
    bool sane() {
        BodyIDVector_t ids;
        return true;
    }
    using BodyIDVector_t = JPH::BodyIDVector;
    int countInvalidBodies() {
        JPH::BodyIDVector ids;
        game.phys.sys().GetBodies(ids);
        int bad = 0;
        auto& bi = game.phys.bi();
        for (auto id : ids) {
            vec3 p = ToG(JPH::Vec3(bi.GetPosition(id)));
            if (!std::isfinite(p.x) || !std::isfinite(p.y) || !std::isfinite(p.z) || std::abs(p.x) > 1e5f || std::abs(p.y) > 1e5f) ++bad;
        }
        return bad;
    }
    int objectsBelowWorld() {
        int n = 0;
        for (auto& o : game.objs.objects())
            if (o->alive && o->bounds.mx.y < -5.0f) ++n;
        return n;
    }
};

static std::string Arg(int argc, char** argv, const char* key, const char* def) {
    for (int i = 1; i + 1 < argc; ++i) if (!strcmp(argv[i], key)) return argv[i + 1];
    return def;
}

static void PrintTrace() {
    void* bt[64];
    int n = backtrace(bt, 64);
    backtrace_symbols_fd(bt, n, 2);
}

int main(int argc, char** argv) {
    std::set_terminate([] { fprintf(stderr, "terminate called; backtrace:\n"); PrintTrace(); abort(); });
    Harness h;
    h.W = atoi(Arg(argc, argv, "--w", "1280").c_str());
    h.H = atoi(Arg(argc, argv, "--h", "720").c_str());
    std::string test = Arg(argc, argv, "--test", "full");
    gAssetDir = Arg(argc, argv, "--assets", "assets");
    h.shotDir = Arg(argc, argv, "--shots", "shots");
    std::string quality = Arg(argc, argv, "--quality", "medium");
    float soak = (float)atof(Arg(argc, argv, "--soak", "120").c_str());
    mkdir(h.shotDir.c_str(), 0755);

    auto gpd = (PFNEGLGETPLATFORMDISPLAYEXTPROC)eglGetProcAddress("eglGetPlatformDisplayEXT");
    EGLDisplay dpy = gpd ? gpd(EGL_PLATFORM_SURFACELESS_MESA, EGL_DEFAULT_DISPLAY, nullptr) : eglGetDisplay(EGL_DEFAULT_DISPLAY);
    EGLint ma, mi;
    if (!eglInitialize(dpy, &ma, &mi)) { LogError("eglInitialize failed"); return 2; }
    EGLint ca[] = {EGL_SURFACE_TYPE, EGL_PBUFFER_BIT, EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8,
                   EGL_ALPHA_SIZE, 8, EGL_DEPTH_SIZE, 24, EGL_NONE};
    EGLConfig cfg; EGLint n = 0;
    eglChooseConfig(dpy, ca, &cfg, 1, &n);
    if (n < 1) { LogError("no EGL config"); return 2; }
    eglBindAPI(EGL_OPENGL_ES_API);
    EGLint xa[] = {EGL_CONTEXT_MAJOR_VERSION, 3, EGL_CONTEXT_MINOR_VERSION, 0, EGL_NONE};
    EGLContext ctx = eglCreateContext(dpy, cfg, EGL_NO_CONTEXT, xa);
    EGLint pa[] = {EGL_WIDTH, h.W, EGL_HEIGHT, h.H, EGL_NONE};
    EGLSurface surf = eglCreatePbufferSurface(dpy, cfg, pa);
    if (!ctx || !surf || !eglMakeCurrent(dpy, surf, surf, ctx)) { LogError("EGL context failed"); return 2; }
    LogInfo("GL: %s | %s", glGetString(GL_RENDERER), glGetString(GL_VERSION));

    Game& g = h.game;
    if (!g.init(h.W, h.H)) { LogError("game init failed"); return 3; }
    g.settings.applyPreset(quality == "low" ? Q_LOW : quality == "high" ? Q_HIGH : Q_MEDIUM);
    g.settings.dynamicResolution = false;
    g.settings.showDebug = true;
    g.applySettings();

    // ---- main menu, start the game through a real touch on the PLAY button
    h.run(0.3f);
    h.shot("00_main_menu");
    {
        // PLAY is the first button of the centered menu window (window center at 0.62 H, height 420*s)
        float s = std::max(0.6f, std::min(h.H / 720.0f, h.W / 1280.0f * 1.25f));
        vec2 play(h.W * 0.5f, h.H * 0.62f - 210 * s + 14 * s + 26 * s * 1.0f);
        h.tap(play);
        h.run(0.1f);
        h.check(g.state == GameState::Loading, "main menu PLAY button starts loading via touch");
        if (g.state != GameState::Loading) g.startLoading();
    }
    double tl = WallMs();
    h.frame();
    h.shot("01_loading");
    while (g.state == GameState::Loading && WallMs() - tl < 240000) h.frame();
    h.check(g.state == GameState::Playing, "world generated and loaded");
    LogInfo("load time %.1f s; chunks %d, objects %d", (WallMs() - tl) / 1000.0, g.world.chunkCount(), g.objs.count());
    if (g.state != GameState::Playing) return 4;
    h.run(1.0f);
    h.check(h.countInvalidBodies() == 0, "all bodies have finite positions after load");
    h.shot("02_spawn_view");

    // ---- movement through the virtual joystick
    {
        vec3 p0 = g.player.feet();
        vec2 jc = g.ui->joystickCenter();
        float jr = g.ui->joystickRadius();
        g.input.touchDown(1, jc.x, jc.y); h.frame();
        g.input.touchMove(1, jc.x, jc.y - jr); 
        h.run(1.5f);
        g.input.touchUp(1, jc.x, jc.y - jr); h.frame();
        float moved = glm::distance(vec2(p0.x, p0.z), vec2(g.player.feet().x, g.player.feet().z));
        h.check(moved > 3.0f, "joystick moves player (" + std::to_string(moved) + " m)");
        h.check(g.player.feet().y > 2.5f && g.player.feet().y < 4.0f, "player stays on the ground (y=" + std::to_string(g.player.feet().y) + ")");
        // look drag
        float y0 = g.player.yaw;
        g.input.touchDown(2, h.W * 0.75f, h.H * 0.5f); h.frame();
        for (int i = 0; i < 10; ++i) { g.input.touchMove(2, h.W * 0.75f + i * 12.0f, h.H * 0.5f); h.frame(); }
        g.input.touchUp(2, h.W * 0.75f + 120, h.H * 0.5f); h.frame();
        h.check(std::abs(g.player.yaw - y0) > 0.2f, "look drag rotates camera");
        // jump
        float fy = g.player.feet().y;
        float maxY = fy;
        g.input.touchDown(3, h.W - 100.0f * std::max(0.6f, h.H / 720.0f), h.H - 100.0f * std::max(0.6f, h.H / 720.0f));
        for (int i = 0; i < 12; ++i) { h.frame(); maxY = std::max(maxY, g.player.feet().y); }
        g.input.touchUp(3, 0, 0);
        h.run(1.0f);
        h.check(maxY > fy + 0.4f, "jump button makes the player jump");
    }

    // ---- scenic screenshots
    auto L = [&](const char* name) -> vec3 {
        for (auto& l : g.map.landmarks) if (l.second == name) return l.first;
        return g.map.spawn;
    };
    h.place(vec3(60, 3.05f, 68), vec3(85, 8, 30)); h.shot("03_street_tower");
    h.place(vec3(25, 3.05f, 60), vec3(20, 4, 46)); h.shot("04_houses");
    h.place(L("Apartment Roof"), vec3(20, 2, 80)); h.shot("05_rooftop_view");
    h.place(L("Underground Parking") + vec3(0, 0, -1), vec3(80, 1.5f, 30)); h.shot("06_parking");
    h.place(vec3(46, 3.05f, 88), vec3(25, 4, 88)); h.shot("07_warehouse_gate");
    h.place(vec3(108, 3.05f, 118), vec3(106, 14, 100)); h.shot("08_crane");
    h.place(vec3(80, 3.05f, 80), vec3(92, 3, 80)); h.shot("09_park");
    // interior
    h.place(vec3(17.5f, 3.3f, 46.0f), vec3(14, 3.8f, 44)); h.shot("10_house_interior");

    // ---- destruction: hammer + cannon on a house wall, check voxels removed and a collapse
    {
        int v0 = g.destr.stats.voxelsDestroyed;
        // house at frame (40,60) r0: front wall at z=15 m. stand in front of it
        h.place(vec3(18, 3.05f, 13.2f), vec3(18, 4.5f, 15.0f));
        g.sandbox.tool = TOOL_HAMMER;
        h.run(0.1f);
        for (int i = 0; i < 6; ++i) { h.tapButton("Smash"); h.run(0.5f); }
        h.check(g.destr.stats.voxelsDestroyed > v0, "sledgehammer removes voxels (" + std::to_string(g.destr.stats.voxelsDestroyed - v0) + ")");
        h.shot("11_hammer_damage");
        g.sandbox.tool = TOOL_CANNON;
        h.place(vec3(18, 3.05f, 6.0f), vec3(16, 4.0f, 15.0f));
        h.run(0.1f);
        for (int i = 0; i < 8; ++i) { h.tapButton("Fire"); h.run(0.4f); }
        h.run(1.0f);
        h.shot("12_cannon_damage");
        h.check(g.destr.stats.voxelsDestroyed > v0 + 50, "cannon breaks walls (" + std::to_string(g.destr.stats.voxelsDestroyed - v0) + " voxels total)");
    }
    {
        // bombs at the base of the condemned brick building -> structural collapse
        int f0 = g.destr.stats.fragments;
        g.sandbox.tool = TOOL_BOMB;
        vec3 b = vec3(340 * VOXEL_SIZE, 3.05f, 420 * VOXEL_SIZE);
        // ring of bombs along the west and south walls at ground level
        int bombIdx = -1;
        for (int i = 0; i < (int)g.sandbox.catalog.size(); ++i) if (g.sandbox.catalog[i].kind == SpawnKind::Bomb) bombIdx = i;
        h.check(bombIdx >= 0, "bomb present in spawn catalog");
        for (int k = 0; k < 4; ++k) {
            g.sandbox.spawnItem(bombIdx, vec3(84.6f, 3.1f, 101.5f + k * 2.0f), 0);
            g.sandbox.spawnItem(bombIdx, vec3(85.5f + k * 2.0f, 3.1f, 109.3f), 0);
        }
        h.place(vec3(78, 3.05f, 95), vec3(89, 5, 105));
        h.run(4.0f);
        h.shot("13_explosions");
        h.run(4.0f);
        h.shot("13b_after_explosions");
        h.check(g.destr.stats.fragments > f0, "explosions carve rigid debris fragments (" + std::to_string(g.destr.stats.fragments - f0) + ")");
        h.run(6.0f);
        h.check(h.countInvalidBodies() == 0, "no invalid bodies after explosions");
        h.check(h.objectsBelowWorld() == 0, "no debris fell through the ground");
    }
    {
        // structural collapse: cut every top-storey column of the concrete frame -> the top slab loses support
        int c0 = g.destr.stats.collapses;
        h.place(vec3(104, 3.05f, 92), vec3(114, 12, 80));
        h.run(0.5f);
        for (float x : {110.25f, 114.0f, 117.75f})
            for (float z : {74.25f, 78.0f, 81.75f, 85.5f})
                g.destr.damageAt(vec3(x, 13.4f, z), 0.45f, 1.0f, vec3(0), true);
        h.run(0.3f);
        h.shot("14_collapse");
        h.check(g.destr.stats.collapses > c0, "unsupported top slab collapses (" + std::to_string(g.destr.stats.collapses - c0) + " collapses)");
        h.run(5.0f);
        h.shot("14b_collapsed");
        h.check(h.countInvalidBodies() == 0, "collapse keeps simulation valid");
        h.check(h.objectsBelowWorld() == 0, "collapsed slab stays above the ground");
    }

    // ---- ragdolls: cannon at an NPC
    {
        Npc* target = nullptr;
        for (auto& n : g.npcs.npcs()) if (n->state != NpcState::Ragdoll) { target = n.get(); break; }
        h.check(target != nullptr, "NPCs exist");
        if (target) {
            vec3 c = target->center();
            vec3 feet = c + vec3(4.0f, 0, 0);
            feet.y = 3.05f;
            // move NPC to open ground first for a clean test
            h.place(vec3(60, 3.05f, 70), vec3(64, 3.9f, 70));
            for (auto& n : g.npcs.npcs()) if (n.get() == target) { }
            g.sandbox.tool = TOOL_CANNON;
            g.sandbox.spawnItem([&] { for (int i = 0; i < (int)g.sandbox.catalog.size(); ++i) if (g.sandbox.catalog[i].kind == SpawnKind::Npc) return i; return 0; }(), vec3(64, 3.05f, 70), 0);
            h.run(1.0f);
            Npc* dummy = g.npcs.npcs().back().get();
            h.lookAt(dummy->center());
            h.frame();
            h.tapButton("Fire");
            h.run(0.6f);
            h.shot("15_ragdoll");
            h.check(g.npcs.ragdollCount() > 0, "cannon ball knocks a crash dummy into ragdoll");
            h.run(8.0f);
            h.check(dummy->state != NpcState::Ragdoll, "crash dummy recovers and stands up");
            h.shot("16_recovered");
        }
    }

    // ---- vehicles: enter the nearest car and drive with the GAS button
    {
        Vehicle* car = nullptr;
        for (auto& v : g.vehicles.vehicles()) if (v->type == VEH_CAR) { car = v.get(); break; }
        h.check(car != nullptr, "car exists");
        if (car) {
            vec3 p = car->position();
            vec3 side = car->rotation() * vec3(1, 0, 0);
            h.place(vec3(p.x, 3.05f, p.z) + side * 2.0f, p);
            h.frame();
            g.enterOrExitVehicle();
            h.frame();
            h.check(g.driving == car, "player enters the car");
            vec3 start = car->position();
            h.holdButton("GAS", 3.0f);
            float sp = std::abs(car->speedKmh());
            float dist = glm::distance(start, car->position());
            h.shot("17_driving");
            h.check(dist > 4.0f, "GAS button accelerates the car (" + std::to_string(dist) + " m, " + std::to_string(sp) + " km/h)");
            h.holdButton("BRAKE", 2.0f);
            h.check(std::abs(car->speedKmh()) < sp + 1.0f, "brake slows the car");
            h.check(car->position().y > 2.0f, "car stays above the road");
            g.enterOrExitVehicle();
            h.frame();
            h.check(!g.driving, "player exits the car");
        }
        // forklift + loader exist and can be driven
        for (int t : {VEH_FORKLIFT, VEH_LOADER, VEH_TRUCK}) {
            Vehicle* v = nullptr;
            for (auto& x : g.vehicles.vehicles()) if (x->type == t) v = x.get();
            h.check(v != nullptr, std::string(VehicleName(t)) + " present on the map");
            if (!v) continue;
            vec3 p = v->position();
            h.check(p.y > 1.0f && p.y < 8.0f, std::string(VehicleName(t)) + " rests on the ground (y=" + std::to_string(p.y) + ")");
        }
    }

    // ---- interactions: elevator, gate, crane
    {
        auto& els = g.inter.elevators();
        h.check(!els.empty(), "elevator exists");
        if (!els.empty()) {
            int top = (int)els[0].floors.size() - 1;
            int sw = -1;
            for (int i = 0; i < (int)g.inter.switches().size(); ++i) {
                auto& s = g.inter.switches()[i];
                if (s.action == SW_ELEVATOR && s.param == top) sw = i;
            }
            g.inter.activate(sw);
            h.run(16.0f);
            h.check(std::abs(els[0].y - els[0].floors[top]) < 0.05f, "elevator travels to the roof");
        }
        auto& gates = g.inter.gates();
        h.check(gates.size() >= 2, "warehouse + vault gates exist");
        for (int i = 0; i < (int)g.inter.switches().size(); ++i)
            if (g.inter.switches()[i].action == SW_GATE) { g.inter.activate(i); break; }
        h.run(5.0f);
        h.check(!gates.empty() && gates[0].t > 0.9f, "warehouse gate opens");
        // crane start + drop
        int cs = -1;
        for (int i = 0; i < (int)g.inter.switches().size(); ++i) if (g.inter.switches()[i].action == SW_CRANE) cs = i;
        if (cs >= 0) g.inter.activate(cs);
        h.place(vec3(80, 3.05f, 118), vec3(90, 8, 106));
        int v0 = g.destr.stats.voxelsDestroyed;
        h.run(20.0f);
        h.shot("18_crane_swing");
        h.check(!g.inter.cranes().empty() && g.inter.cranes()[0].running, "crane rotates");
        h.check(g.destr.stats.voxelsDestroyed > v0, "wrecking ball damages the condemned building (" + std::to_string(g.destr.stats.voxelsDestroyed - v0) + ")");
    }

    // ---- vault puzzle: drop crates/blocks on the plate
    {
        int blockIdx = -1;
        for (int i = 0; i < (int)g.sandbox.catalog.size(); ++i) if (g.sandbox.catalog[i].name == GetPropDef(PROP_CONCRETE_BLOCK).name) blockIdx = i;
        if (blockIdx >= 0) g.sandbox.spawnItem(blockIdx, vec3(28.0f, 3.2f, 92.0f), 0);
        h.run(4.0f);
        h.check(g.inter.puzzlesSolved() >= 1, "weight plate puzzle opens the vault");
        h.place(vec3(19, 3.05f, 84), vec3(19, 3.5f, 92));
        h.shot("19_vault");
    }

    // ---- spawn menu via touch UI
    {
        g.ui->openPanel(UI::P_SPAWN);
        h.run(0.3f);
        h.shot("20_spawn_menu");
        g.ui->openPanel(UI::P_PAUSE);
        h.run(0.2f);
        h.shot("21_pause_menu");
        g.ui->openPanel(UI::P_SETTINGS);
        h.run(0.2f);
        h.shot("22_settings");
        g.ui->openPanel(UI::P_NONE);
        h.run(0.2f);
    }

    // ---- time of day / weather
    {
        h.place(vec3(60, 3.05f, 68), vec3(85, 8, 30));
        g.env.cyclePaused = true;
        g.env.timeOfDay = 18.6f; h.run(1.0f); h.shot("23_sunset");
        g.env.timeOfDay = 22.5f; h.run(1.0f); h.shot("24_night");
        g.env.timeOfDay = 13.0f; g.env.setWeather(Weather::Rain); h.run(6.0f); h.shot("25_rain");
        g.env.setWeather(Weather::Fog); h.run(6.0f); h.shot("26_fog");
        g.env.setWeather(Weather::Clear); g.env.cyclePaused = false;
        g.setGravityScale(0.0f);
        h.run(1.0f);
        g.setGravityScale(1.0f);
        h.check(h.countInvalidBodies() == 0, "gravity changes keep the simulation valid");
    }

    // ---- soak test: random chaos for N seconds of game time
    {
        Rng r(1234);
        double t0 = WallMs();
        int steps = (int)(soak / h.dt);
        size_t ft0 = h.frameTimes.size();
        for (int i = 0; i < steps; ++i) {
            if (i % 45 == 0) {
                int a = r.irange(0, 5);
                vec3 p(r.range(15, 115), 3.05f, r.range(15, 115));
                if (a == 0) { g.player.teleport(p); }
                else if (a == 1) { int idx = r.irange(0, (int)g.sandbox.catalog.size() - 1); if (g.sandbox.catalog[idx].kind != SpawnKind::Vehicle || g.vehicles.vehicles().size() < 14) g.sandbox.spawnItem(idx, p + vec3(0, 1.0f, 0), r.range(0, 6)); }
                else if (a == 2) { g.sandbox.tool = TOOL_CANNON; g.sandbox.useTool(g.player.eye(), g.player.forward()); }
                else if (a == 3) { g.destr.explode(p + vec3(0, 1.0f, 0), 2.0f, 1.0f); }
                else if (a == 4) { g.sandbox.tool = TOOL_ROCKET; g.sandbox.useTool(g.player.eye(), g.player.forward()); }
                else { g.player.look(r.range(-1, 1), 0); }
            }
            h.frame();
        }
        double ms = WallMs() - t0;
        h.check(h.countInvalidBodies() == 0, "soak test: no invalid bodies after " + std::to_string((int)soak) + " s of chaos");
        h.check(g.objs.debrisCount() <= g.settings.maxDebris + 40, "soak test: debris budget respected (" + std::to_string(g.objs.debrisCount()) + ")");
        float avg = 0; for (size_t i = ft0; i < h.frameTimes.size(); ++i) avg += h.frameTimes[i];
        avg /= std::max<size_t>(1, h.frameTimes.size() - ft0);
        LogInfo("soak: %d frames in %.1f s, avg frame %.1f ms (software renderer on 2 x86 cores)", steps, ms / 1000.0, avg);
        h.shot("27_after_soak");
    }

    // ---- restart map and return to menu (lifecycle)
    g.startLoading();
    while (g.state == GameState::Loading) h.frame();
    h.run(1.0f);
    h.check(g.state == GameState::Playing && h.countInvalidBodies() == 0, "restart map works");
    g.returnToMenu();
    h.run(0.2f);
    h.check(g.state == GameState::MainMenu, "return to main menu");

    g.shutdown();
    eglMakeCurrent(dpy, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
    eglDestroySurface(dpy, surf);
    eglDestroyContext(dpy, ctx);
    eglTerminate(dpy);

    FILE* f = fopen((h.shotDir + "/report.txt").c_str(), "w");
    for (auto& l : h.report) { if (f) fprintf(f, "%s\n", l.c_str()); }
    if (f) { fprintf(f, "\n%d failures\n", h.failures); fclose(f); }
    LogInfo("==== %d checks, %d failures ====", (int)h.report.size(), h.failures);
    (void)test;
    return h.failures ? 1 : 0;
}
