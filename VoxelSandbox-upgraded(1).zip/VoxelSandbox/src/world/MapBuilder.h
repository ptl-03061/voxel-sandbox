// Procedural construction of the playable map "Harbor Heights": residential block, apartment tower with
// underground parking, industrial warehouse, construction site with a crane, park, roads and street lamps.
#pragma once
#include "destruction/VoxelWorld.h"
#include "gameplay/Interactions.h"

struct PropPlace { int type; vec3 pos; float yaw; };   // pos = bottom center in meters
struct DoorPlace { vec3 hinge; float yaw; int w, h; uint8_t mat; bool window; float breakImpulse; };
struct VehPlace { int type; vec3 pos; float yaw; };
struct NpcPlace { vec3 pos; float yaw; float wander; };
struct ElevPlace { vec3 base, half; std::vector<float> floors; };
struct GatePlace { vec3 center, half; float openHeight; vec4 color; };
struct CranePlace { vec3 pivot; float jib, angle, chain; };
struct SeesawPlace { vec3 pivot; float yaw; };

struct MapData {
    vec3 spawn{0};
    float spawnYaw = 0;
    std::vector<PropPlace> props;
    std::vector<DoorPlace> doors;
    std::vector<VehPlace> vehicles;
    std::vector<NpcPlace> npcs;
    std::vector<ElevPlace> elevators;
    std::vector<GatePlace> gates;
    std::vector<CranePlace> cranes;
    std::vector<SeesawPlace> seesaws;
    std::vector<LightGroup> lights;
    std::vector<Switch> switches;
    std::vector<PressurePlate> plates;
    std::vector<std::pair<vec3, std::string>> landmarks;   // for the map / teleport menu
};

namespace MapBuilder {
constexpr int G = 12;          // first air layer above the ground (ground surface at 3m)
constexpr int FLOOR_H = 12;    // storey height in voxels (3m)
// Fills the voxel world (worker thread safe: only raw voxel writes) and records dynamic placements.
void BuildVoxels(VoxelWorld& w, MapData& data, std::function<void(float)> progress);
}
