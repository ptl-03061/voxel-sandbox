// Day/night cycle, sky colors, weather (clear / cloudy / rain / storm / fog), lightning, ambience loops.
#pragma once
#include "engine/Renderer.h"
#include "engine/Particles.h"

enum class Weather : int { Clear = 0, Cloudy, Rain, Storm, Fog, COUNT };
const char* WeatherName(Weather w);

class Environment {
public:
    float timeOfDay = 9.5f;      // hours 0..24
    float daySpeed = 1.0f / 60;  // in-game hours per real second (1 h per minute)
    bool cyclePaused = false;
    Weather weather = Weather::Clear;
    bool autoWeather = true;

    void update(float dt, const vec3& camPos, Particles& particles, const VoxelWorld& world);
    void fill(FrameParams& fp) const;
    void setWeather(Weather w) { weather = w; mWeatherTimer = 0; }
    float night() const { return mNight; }
    float rainAmount() const { return mRain; }
    vec3 wind() const { return mWind; }
    bool lightsOn() const { return mNight > 0.35f || mCloud > 0.8f; }
    void stopAmbience();
    bool flashActive() const { return mFlash > 0.05f; }

private:
    float mNight = 0, mCloud = 0.2f, mRain = 0, mFog = 0, mWet = 0, mFlash = 0;
    float mLightningTimer = 6, mThunderDelay = -1;
    float mWeatherTimer = 0;
    float mTime = 0;
    vec3 mWind{1.5f, 0, 0.6f};
    vec3 mSunDir{0.3f, 0.8f, 0.2f};
    vec3 mSunColor{1}, mSky{0.4f, 0.6f, 0.9f}, mHorizon{0.7f}, mFogColor{0.7f};
    uint32_t mAmbWind = 0, mAmbBirds = 0, mAmbNight = 0, mAmbRain = 0;
    vec3 mFlashPos{0};
};
