#include "world/MapBuilder.h"
#include "gameplay/Props.h"
#include "gameplay/Vehicle.h"

namespace MapBuilder {
namespace {

constexpr float VS = VOXEL_SIZE;
constexpr float PI = 3.14159265f;
VoxelWorld* gW = nullptr;
MapData* gD = nullptr;

void Box(int x0, int y0, int z0, int x1, int y1, int z1, uint8_t m) { gW->fill({x0, y0, z0}, {x1, y1, z1}, m, true); }
void Set(int x, int y, int z, uint8_t m) { gW->setRaw(x, y, z, m); }
uint8_t Get(int x, int y, int z) { return gW->get(x, y, z); }
vec3 Mv(float x, float y, float z) { return vec3(x, y, z) * VS; }   // voxel coords -> meters

void Prop(int type, vec3 pos, float yaw) { gD->props.push_back({type, pos, yaw}); }
void Npc(vec3 pos, float yaw, float wander) { gD->npcs.push_back({pos, yaw, wander}); }

// Local building frame rotated in 90 degree steps.
struct Frame {
    int x0, z0, r, W, D;
    ivec2 v(int lx, int lz) const {
        switch (r & 3) {
        case 0: return {x0 + lx, z0 + lz};
        case 1: return {x0 + lz, z0 + (W - 1 - lx)};
        case 2: return {x0 + (W - 1 - lx), z0 + (D - 1 - lz)};
        default: return {x0 + (D - 1 - lz), z0 + lx};
        }
    }
    void box(int lx0, int y0, int lz0, int lx1, int y1, int lz1, uint8_t m) const {
        if (lx1 <= lx0 || lz1 <= lz0 || y1 <= y0) return;
        ivec2 a = v(lx0, lz0), b = v(lx1 - 1, lz1 - 1);
        Box(std::min(a.x, b.x), y0, std::min(a.y, b.y), std::max(a.x, b.x) + 1, y1, std::max(a.y, b.y) + 1, m);
    }
    void set(int lx, int y, int lz, uint8_t m) const { ivec2 p = v(lx, lz); Set(p.x, y, p.y, m); }
    ivec3 vox(int lx, int y, int lz) const { ivec2 p = v(lx, lz); return {p.x, y, p.y}; }
    // local meters -> world meters
    vec3 m(float mx, float my, float mz) const {
        float X0 = x0 * VS, Z0 = z0 * VS, Wm = W * VS, Dm = D * VS;
        switch (r & 3) {
        case 0: return {X0 + mx, my, Z0 + mz};
        case 1: return {X0 + mz, my, Z0 + Wm - mx};
        case 2: return {X0 + Wm - mx, my, Z0 + Dm - mz};
        default: return {X0 + Dm - mz, my, Z0 + mx};
        }
    }
    vec3 dir(float dx, float dz) const {
        switch (r & 3) {
        case 0: return {dx, 0, dz};
        case 1: return {dz, 0, -dx};
        case 2: return {-dx, 0, -dz};
        default: return {-dz, 0, dx};
        }
    }
    float yaw(float ly) const { return ly + (r & 3) * PI * 0.5f; }
};

void Tree(int x, int z, int h, int rad, uint32_t seed) {
    for (int y = G; y < G + h; ++y) Box(x, y, z, x + 2, y + 1, z + 2, M_BARK);
    int cy = G + h;
    for (int dz = -rad; dz <= rad; ++dz)
        for (int dy = -rad; dy <= rad + 2; ++dy)
            for (int dx = -rad; dx <= rad; ++dx) {
                float d = std::sqrt((float)(dx * dx + dz * dz) + (dy - 1) * (dy - 1) * 1.3f);
                float n = Hash01(Hash3i(x + dx, cy + dy, z + dz) ^ seed) * 1.6f;
                if (d + n > rad + 0.6f) continue;
                int X = x + dx, Y = cy + dy, Z = z + dz;
                if (Y < G || !gW->inBounds(X, Y, Z) || Get(X, Y, Z) != M_AIR) continue;
                Set(X, Y, Z, M_LEAVES);
            }
    // a couple of branches
    Box(x - 2, cy - 3, z, x, cy - 2, z + 1, M_BARK);
    Box(x + 2, cy - 2, z + 1, x + 4, cy - 1, z + 2, M_BARK);
}

void StreetLamp(int x, int z, int dx, int dz, LightGroup& g) {
    Box(x, G, z, x + 1, G + 20, z + 1, M_METAL);
    for (int i = 1; i <= 3; ++i) Set(x + dx * i, G + 19, z + dz * i, M_METAL);
    Set(x + dx * 3, G + 18, z + dz * 3, M_LIGHT);
    g.lampVoxels.push_back({x + dx * 3, G + 18, z + dz * 3});
}

void Container(int x, int y, int z, uint8_t mat, bool alongX) {
    int lx = alongX ? 24 : 10, lz = alongX ? 10 : 24;
    Box(x, y, z, x + lx, y + 10, z + lz, mat);
    Box(x + 1, y + 1, z + 1, x + lx - 1, y + 9, z + lz - 1, M_AIR);
    if (alongX) Box(x + lx - 1, y + 1, z + 1, x + lx, y + 9, z + lz - 1, M_AIR);   // open end
    else Box(x + 1, y + 1, z + lz - 1, x + lx - 1, y + 9, z + lz, M_AIR);
    // corner posts in darker metal
    for (int cx : {x, x + lx - 1}) for (int cz : {z, z + lz - 1}) Box(cx, y, cz, cx + 1, y + 10, cz + 1, M_RUST);
}

// straight stair flight inside a building: lane [xa,xb) along z, from walking surface s (voxel y), rising 'rise' steps
void Stairs(int xa, int xb, int zStart, int dirZ, int s, int rise, uint8_t mat) {
    for (int k = 0; k < rise; ++k) {
        int z = zStart + dirZ * k;
        Box(xa, s, z, xb, s + 1 + k, z + 1, mat);
    }
    // cut the slab above for headroom (all but the top step)
    int zA = zStart, zB = zStart + dirZ * (rise - 2);
    Box(xa, s + rise - 1, std::min(zA, zB), xb, s + rise, std::max(zA, zB) + 1, M_AIR);
    for (int k = 0; k < rise - 1; ++k) {
        int z = zStart + dirZ * k;
        Box(xa, s + 1 + k, z, xb, s + rise + 1, z + 1, M_AIR);   // clear above step
    }
}

// ------------------------------------------------------------------ residential house
void House(const Frame& F, int floors, uint8_t wall, uint8_t roof, int variant) {
    const int W = F.W, D = F.D;
    LightGroup lights;
    lights.radius = 6.5f;
    lights.color = variant % 2 ? vec3(1.0f, 0.86f, 0.62f) : vec3(1.0f, 0.92f, 0.78f);
    for (int f = 0; f < floors; ++f) {
        int yb = G + f * FLOOR_H;
        F.box(0, yb, 0, W, yb + 1, D, M_CONCRETE);
        F.box(1, yb, 1, W - 1, yb + 1, D - 1, M_PLANK);
        if (f == 0) F.box(1, yb, 17, 21, yb + 1, D - 1, M_TILE);
        if (f == 1) F.box(1, yb, 17, W - 1, yb + 1, D - 1, M_CARPET);
        // exterior walls
        F.box(0, yb + 1, 0, W, yb + FLOOR_H, 1, wall);
        F.box(0, yb + 1, D - 1, W, yb + FLOOR_H, D, wall);
        F.box(0, yb + 1, 0, 1, yb + FLOOR_H, D, wall);
        F.box(W - 1, yb + 1, 0, W, yb + FLOOR_H, D, wall);
        // windows
        for (int p = 4; p + 4 <= W - 4; p += 10) {
            if (!(f == 0 && p < 13 && p + 4 > 7)) F.box(p, yb + 4, 0, p + 4, yb + 9, 1, M_GLASS);
            F.box(p, yb + 4, D - 1, p + 4, yb + 9, D, M_GLASS);
        }
        for (int p = 4; p + 4 <= D - 4; p += 10) {
            F.box(0, yb + 4, p, 1, yb + 9, p + 4, M_GLASS);
            F.box(W - 1, yb + 4, p, W, yb + 9, p + 4, M_GLASS);
        }
        // partition wall with doorway
        F.box(1, yb + 1, 16, W - 1, yb + FLOOR_H, 17, M_PLASTER);
        F.box(22, yb + 1, 16, 26, yb + 10, 17, M_AIR);
        gD->doors.push_back({F.m(22 * VS + 0.06f, (yb + 1) * VS + 0.03f, 16.5f * VS), F.yaw(0), 7, 17, M_WOOD, false, 900.0f});
        // ceiling lamps
        for (int lz : {8, 24}) {
            int lx = lz == 8 ? W / 2 - 6 : W / 2 - 4;
            F.set(lx, yb + FLOOR_H - 1, lz, M_LIGHT);
            lights.lampVoxels.push_back(F.vox(lx, yb + FLOOR_H - 1, lz));
        }
        // furniture
        float fy = (yb + 1) * VS + 0.02f;
        if (f == 0) {
            Prop(PROP_SOFA, F.m(3.2f, fy, 3.2f), F.yaw(0));
            Prop(PROP_TV, F.m(3.2f, fy, 0.6f), F.yaw(PI));
            Prop(PROP_LAMP, F.m(1.0f, fy, 3.4f), F.yaw(0));
            Prop(PROP_BOOKCASE, F.m(0.6f, fy, 1.8f), F.yaw(PI * 0.5f));
            Prop(PROP_TABLE, F.m(6.6f, fy, 5.9f), F.yaw(0));
            Prop(PROP_CHAIR, F.m(6.0f, fy, 5.1f), F.yaw(0));
            Prop(PROP_CHAIR, F.m(7.2f, fy, 6.7f), F.yaw(PI));
            Prop(PROP_FRIDGE, F.m(4.65f, fy, 7.3f), F.yaw(PI));
            // kitchen counter
            F.box(2, yb + 1, D - 4, 16, yb + 4, D - 1, M_DARKWOOD);
            F.box(2, yb + 4, D - 4, 16, yb + 5, D - 1, M_TILE);
        } else {
            Prop(PROP_BED, F.m(3.0f, fy, 5.6f), F.yaw(0));
            Prop(PROP_DESK, F.m(7.6f, fy, 7.2f), F.yaw(PI));
            Prop(PROP_CHAIR, F.m(7.6f, fy, 6.5f), F.yaw(0));
            Prop(PROP_CRATE, F.m(1.2f, fy, 1.4f), F.yaw(0.2f));
            Prop(PROP_CRATE, F.m(1.3f, fy, 2.5f), F.yaw(-0.1f));
            Prop(variant % 2 ? PROP_BOOKCASE : PROP_SHELF, F.m(4.5f, fy, 0.5f), F.yaw(PI));
        }
        // stairs to next floor (inside, along the right wall)
        if (f + 1 < floors) {
            for (int k = 0; k < 12; ++k) F.box(W - 6, yb + 1, 2 + k, W - 2, yb + 2 + k, 3 + k, M_DARKWOOD);
            F.box(W - 6, yb + FLOOR_H, 2, W - 2, yb + FLOOR_H + 1, 13, M_AIR);
            F.box(W - 7, yb + FLOOR_H + 1, 2, W - 6, yb + FLOOR_H + 4, 13, M_DARKWOOD);
        }
    }
    int yt = G + floors * FLOOR_H;
    F.box(0, yt, 0, W, yt + 1, D, M_CONCRETE);
    // front door
    F.box(8, G + 1, 0, 12, G + 10, 1, M_AIR);
    gD->doors.push_back({F.m(8 * VS + 0.06f, (G + 1) * VS + 0.03f, 0.5f * VS), F.yaw(0), 7, 17, M_DARKWOOD, true, 1400.0f});
    // door step
    F.box(7, G, -3, 13, G + 1, 0, M_CONCRETE);
    // light switch beside the front door (inside)
    Switch sw;
    sw.pos = F.m(13.5f * VS + 0.1f, (G + 5.5f) * VS, 1.0f * VS + 0.03f);
    sw.normal = F.dir(0, 1);
    sw.label = "Lights";
    sw.action = SW_LIGHTS;
    sw.target = (int)gD->lights.size();
    sw.state = true;
    gD->switches.push_back(sw);
    gD->lights.push_back(lights);
    // gable roof with overhang
    for (int k = 0;; ++k) {
        int zLo = -1 + 2 * k, zHi = D + 1 - 2 * k;
        int y = yt + 1 + k;
        if (zHi - zLo <= 4) { F.box(-1, y, zLo, W + 1, y + 1, zHi, roof); break; }
        F.box(-1, y, zLo, W + 1, y + 1, zLo + 2, roof);
        F.box(-1, y, zHi - 2, W + 1, y + 1, zHi, roof);
        F.box(0, y, zLo + 2, 1, y + 1, zHi - 2, wall);
        F.box(W - 1, y, zLo + 2, W, y + 1, zHi - 2, wall);
    }
    // chimney
    F.box(W - 10, yt + 1, 20, W - 7, yt + 12, 23, M_BRICK);
    // garden fence (front open for the path)
    for (int lx = -6; lx < W + 6; ++lx) {
        bool post = ((lx + 6) % 6) == 0;
        for (int lz : {D + 8}) F.box(lx, G, lz, lx + 1, G + (post ? 5 : 1), lz + 1, M_PLANK), F.box(lx, G + 3, lz, lx + 1, G + 4, lz + 1, M_PLANK);
    }
    for (int lz = -10; lz < D + 9; ++lz) {
        bool post = ((lz + 10) % 6) == 0;
        for (int lx : {-6, W + 5}) {
            F.box(lx, G, lz, lx + 1, G + (post ? 5 : 1), lz + 1, M_PLANK);
            F.box(lx, G + 3, lz, lx + 1, G + 4, lz + 1, M_PLANK);
        }
    }
    // path to the door
    F.box(8, G - 1, -16, 12, G, -3, M_CONCRETE);
    // backyard tree and garden props
    ivec2 t = F.v(W / 2, D + 4);
    Tree(t.x, t.y, 18 + variant * 2, 6, 77u + variant);
    Prop(PROP_BENCH, F.m(3.0f, G * VS + 0.02f, D * VS + 1.0f), F.yaw(PI));
    Prop(PROP_TRASHCAN, F.m(W * VS - 0.6f, G * VS + 0.02f, -0.6f), F.yaw(0));
    Npc(F.m(5.0f, G * VS + 0.02f, -2.0f), F.yaw(0), 6.0f);
}

// ------------------------------------------------------------------ apartment tower + parking
void ApartmentTower() {
    const int X0 = 320, X1 = 384, Z0 = 120, Z1 = 184, FLOORS = 6;
    const int PX0 = 304, PX1 = 400, PZ0 = 104, PZ1 = 200;
    // underground parking: floor surface y=2, ceiling slab y=11
    Box(PX0 - 1, 1, PZ0 - 1, PX1 + 1, 12, PZ1 + 1, M_CONCRETE);
    Box(PX0, 2, PZ0, PX1, 11, PZ1, M_AIR);
    for (int x = PX0 + 8; x < PX1; x += 16)
        for (int z = PZ0 + 8; z < PZ1; z += 16) {
            if (x > 332 && x < 368 && z > 180) continue;   // keep the ramp entrance clear
            if (x >= 344 && x < 360 && z >= 144 && z < 160) continue;   // elevator shaft
            if (x >= 364 && x < 377 && z >= 148 && z < 164) continue;   // stairwell
            Box(x, 2, z, x + 2, 11, z + 2, M_CONCRETE);
        }
    for (int x = PX0 + 4; x < PX1 - 4; x += 12) Box(x, 1, PZ0 + 2, x + 1, 2, PZ1 - 2, M_ROADLINE);   // bay lines
    LightGroup park;
    park.radius = 10.0f; park.color = vec3(0.85f, 0.95f, 1.0f);
    for (int x = PX0 + 16; x < PX1; x += 32)
        for (int z = PZ0 + 16; z < PZ1; z += 32) { Set(x, 10, z, M_LIGHT); park.lampVoxels.push_back({x, 10, z}); }
    gD->lights.push_back(park);
    // ramp from the street down into the parking
    for (int z = PZ1; z < 228; ++z) {
        int h = 2 + (int)std::round(10.0f * (z - PZ1) / (228 - PZ1));
        Box(340, 1, z, 364, h, z + 1, M_CONCRETE);
        Box(340, h, z, 364, G + 3, z + 1, M_AIR);
        Box(339, 1, z, 340, G + 2, z + 1, M_CONCRETE);
        Box(364, 1, z, 365, G + 2, z + 1, M_CONCRETE);
        if ((z / 4) % 2 == 0) Box(351, h - 1, z, 353, h, z + 1, M_PAINT_YELLOW);
    }
    Box(340, 11, PZ1, 364, 12, PZ1 + 1, M_AIR);
    // plaza above the parking
    Box(PX0 - 1, 11, PZ0 - 1, PX1 + 1, 12, PZ1 + 1, M_CONCRETE);
    Box(340, 2, PZ1, 364, 12, PZ1 + 1, M_AIR);
    for (int z = PZ1; z < 228; ++z) {
        int h = 2 + (int)std::round(10.0f * (z - PZ1) / (228 - PZ1));
        Box(340, h, z, 364, G + 3, z + 1, M_AIR);
    }
    gD->vehicles.push_back({VEH_CAR, Mv(316, 2, 130) + vec3(0, 1.0f, 0), 0});
    gD->vehicles.push_back({VEH_VAN, Mv(388, 2, 128) + vec3(0, 1.2f, 0), PI});
    Prop(PROP_CONE, Mv(350, 2, 190), 0); Prop(PROP_CONE, Mv(356, 2, 190), 0);
    Prop(PROP_BARREL, Mv(310, 2, 110), 0); Prop(PROP_BARREL, Mv(312, 2, 112), 0);
    Npc(Mv(330, 2, 175), 0, 8.0f);

    // tower
    LightGroup apt;
    apt.radius = 7.5f; apt.color = vec3(1.0f, 0.9f, 0.72f);
    auto isCol = [](int v, int a, int b) { return v == a || v == b - 2 || ((v - a) % 16 == 0); };
    for (int f = 0; f < FLOORS; ++f) {
        int yb = G + f * FLOOR_H;
        Box(X0, yb, Z0, X1, yb + 1, Z1, M_CONCRETE);
        Box(X0 + 1, yb, Z0 + 1, X1 - 1, yb + 1, Z1 - 1, f == 0 ? M_TILE : M_PLANK);
        // facade: concrete wall + glass band
        Box(X0, yb + 1, Z0, X1, yb + FLOOR_H, Z0 + 1, M_CONCRETE);
        Box(X0, yb + 1, Z1 - 1, X1, yb + FLOOR_H, Z1, M_CONCRETE);
        Box(X0, yb + 1, Z0, X0 + 1, yb + FLOOR_H, Z1, M_CONCRETE);
        Box(X1 - 1, yb + 1, Z0, X1, yb + FLOOR_H, Z1, M_CONCRETE);
        int gy0 = yb + 3, gy1 = yb + 10;
        if (f == 0) { gy0 = yb + 1; gy1 = yb + 11; }
        for (int x = X0 + 2; x < X1 - 2; x += 16) {
            Box(x, gy0, Z0, std::min(x + 14, X1 - 2), gy1, Z0 + 1, M_GLASS);
            Box(x, gy0, Z1 - 1, std::min(x + 14, X1 - 2), gy1, Z1, M_GLASS);
        }
        for (int z = Z0 + 2; z < Z1 - 2; z += 16) {
            Box(X0, gy0, z, X0 + 1, gy1, std::min(z + 14, Z1 - 2), M_GLASS);
            Box(X1 - 1, gy0, z, X1, gy1, std::min(z + 14, Z1 - 2), M_GLASS);
        }
        for (int x = X0; x < X1; ++x)
            for (int z = Z0; z < Z1; ++z) {
                bool edge = x == X0 || x == X1 - 2 || z == Z0 || z == Z1 - 2;
                if (edge && isCol(x, X0, X1) && isCol(z, Z0, Z1)) Box(x, yb + 1, z, x + 2, yb + FLOOR_H, z + 2, M_CONCRETE);
            }
        // interior partitions (plaster, with doorways)
        if (f > 0) {
            Box(X0 + 1, yb + 1, 140, 345, yb + FLOOR_H, 141, M_PLASTER);
            Box(330, yb + 1, 140, 334, yb + 10, 141, M_AIR);
            Box(X0 + 1, yb + 1, 166, 345, yb + FLOOR_H, 167, M_PLASTER);
            Box(330, yb + 1, 166, 334, yb + 10, 167, M_AIR);
            Box(377, yb + 1, Z0 + 1, 378, yb + FLOOR_H, 145, M_PLASTER);
            Box(377, yb + 1, 166, 378, yb + FLOOR_H, Z1 - 1, M_PLASTER);
            Box(377, yb + 1, 172, 378, yb + 10, 176, M_AIR);
            Box(377, yb + 1, 128, 378, yb + 10, 132, M_AIR);
            if (f % 2 == 1) gD->doors.push_back({Mv(330, yb + 1, 140.5f) + vec3(0.06f, 0.03f, 0), 0, 7, 17, M_WOOD, false, 900.0f});
        }
        // lamps
        for (int lx : {332, 372})
            for (int lz : {130, 176}) { Set(lx, yb + FLOOR_H - 1, lz, M_LIGHT); apt.lampVoxels.push_back({lx, yb + FLOOR_H - 1, lz}); }
        // furniture
        float fy = (yb + 1) * VS + 0.02f;
        if (f == 0) {
            Prop(PROP_SOFA, Mv(326, 0, 170) + vec3(0, fy, 0), PI * 0.5f);
            Prop(PROP_TABLE, Mv(334, 0, 172) + vec3(0, fy, 0), 0);
            Prop(PROP_LAMP, Mv(324, 0, 178) + vec3(0, fy, 0), 0);
            Prop(PROP_DESK, Mv(372, 0, 176) + vec3(0, fy, 0), PI);
            Prop(PROP_CHAIR, Mv(372, 0, 172) + vec3(0, fy, 0), 0);
            Npc(Mv(350, 0, 170) + vec3(0, fy, 0), PI, 4.0f);
        } else {
            int v = f % 3;
            Prop(v == 0 ? PROP_BED : PROP_SOFA, Mv(328, 0, 126) + vec3(0, fy, 0), 0);
            Prop(PROP_TV, Mv(328, 0, 136) + vec3(0, fy, 0), PI);
            Prop(PROP_TABLE, Mv(332, 0, 176) + vec3(0, fy, 0), 0.3f * f);
            Prop(PROP_CHAIR, Mv(330, 0, 173) + vec3(0, fy, 0), 0);
            Prop(v == 1 ? PROP_BED : PROP_BOOKCASE, Mv(380, 0, 178) + vec3(0, fy, 0), -PI * 0.5f);
            Prop(PROP_FRIDGE, Mv(380, 0, 126) + vec3(0, fy, 0), -PI * 0.5f);
            Prop(v == 2 ? PROP_GLASS_PANE : PROP_CRATE, Mv(360, 0, 130) + vec3(0, fy, 0), 0.4f);
        }
    }
    int roofY = G + FLOORS * FLOOR_H;
    Box(X0, roofY, Z0, X1, roofY + 1, Z1, M_CONCRETE);
    Box(X0, roofY + 1, Z0, X1, roofY + 4, Z0 + 1, M_CONCRETE);
    Box(X0, roofY + 1, Z1 - 1, X1, roofY + 4, Z1, M_CONCRETE);
    Box(X0, roofY + 1, Z0, X0 + 1, roofY + 4, Z1, M_CONCRETE);
    Box(X1 - 1, roofY + 1, Z0, X1, roofY + 4, Z1, M_CONCRETE);
    Box(326, roofY + 1, 126, 338, roofY + 10, 138, M_METAL);   // water tank housing
    Box(327, roofY + 1, 127, 337, roofY + 9, 137, M_AIR);
    Prop(PROP_FRIDGE, Mv(372, roofY + 1, 128), 0);   // AC units
    Prop(PROP_FRIDGE, Mv(376, roofY + 1, 128), 0);
    Prop(PROP_BARREL, Mv(360, roofY + 1, 176), 0);
    Prop(PROP_PLANK, Mv(340, roofY + 1, 176), 0.5f);
    gD->lights.push_back(apt);
    // entrance doors (double) and lobby opening
    Box(348, G + 1, Z1 - 1, 356, G + 10, Z1, M_AIR);
    gD->doors.push_back({Mv(348, G + 1, Z1 - 0.5f) + vec3(0.06f, 0.03f, 0), 0, 7, 17, M_GLASS, false, 700.0f});
    gD->doors.push_back({Mv(356, G + 1, Z1 - 0.5f) + vec3(-0.06f, 0.03f, 0), PI, 7, 17, M_GLASS, false, 700.0f});
    Box(344, G, Z1, 360, G + 1, Z1 + 6, M_CONCRETE);   // entrance step
    // elevator shaft: interior x[346,358) z[146,158)
    int top = roofY + 1;
    Box(345, 2, 145, 359, top, 146, M_CONCRETE);
    Box(345, 2, 158, 359, top, 159, M_CONCRETE);
    Box(345, 2, 145, 346, top, 159, M_CONCRETE);
    Box(358, 2, 145, 359, top, 159, M_CONCRETE);
    Box(346, 2, 146, 358, top + 1, 158, M_AIR);
    std::vector<int> stops = {2};
    for (int f = 0; f < FLOORS; ++f) stops.push_back(G + f * FLOOR_H + 1);
    stops.push_back(roofY + 1);
    ElevPlace ep;
    ep.base = Mv(352, 0, 152);
    ep.half = vec3(1.42f, 0.1f, 1.42f);
    int elevIndex = (int)gD->elevators.size();
    for (int s : stops) {
        ep.floors.push_back(s * VS - 0.1f);
        Box(348, s, 158, 356, s + 9, 159, M_AIR);
    }
    gD->elevators.push_back(ep);
    static const char* names[] = {"P", "G", "1", "2", "3", "4", "5", "R"};
    for (size_t i = 0; i < stops.size(); ++i) {
        int s = stops[i];
        Switch up, dn, call;
        up.action = dn.action = call.action = SW_ELEVATOR;
        up.target = dn.target = call.target = elevIndex;
        up.normal = dn.normal = call.normal = vec3(0, 0, 1);
        up.pos = Mv(357.4f, s + 5.2f, 159) + vec3(0, 0, 0.03f); up.param = -1; up.label = "Elevator UP";
        dn.pos = Mv(357.4f, s + 3.6f, 159) + vec3(0, 0, 0.03f); dn.param = -2; dn.label = "Elevator DOWN";
        call.pos = Mv(346.6f, s + 4.4f, 159) + vec3(0, 0, 0.03f); call.param = (int)i; call.label = std::string("Call elevator to ") + names[i < 8 ? i : 7];
        gD->switches.push_back(up); gD->switches.push_back(dn); gD->switches.push_back(call);
    }
    // stairwell (switchback, lanes A/B) from parking to the roof
    Stairs(371, 375, 161, -1, 2, 11, M_CONCRETE);   // parking -> ground floor
    Box(371, 11, 151, 375, 13, 162, M_AIR);
    for (int f = 0; f < FLOORS; ++f) {
        int s = G + f * FLOOR_H + 1;
        bool laneA = (f % 2) == 0;
        if (laneA) Stairs(366, 370, 150, 1, s, 12, M_CONCRETE);
        else Stairs(371, 375, 161, -1, s, 12, M_CONCRETE);
        Box(370, s, 151, 371, s + 4, 160, M_METAL);   // railing between lanes
    }
    gD->landmarks.push_back({Mv(352, G + 1, 190) + vec3(0, 0.1f, 0), "Apartment Lobby"});
    gD->landmarks.push_back({Mv(340, roofY + 1, 170) + vec3(0, 0.1f, 0), "Apartment Roof"});
    gD->landmarks.push_back({Mv(330, 2, 190) + vec3(0, 0.1f, 0), "Underground Parking"});
}

// ------------------------------------------------------------------ warehouse + industrial yard
void Warehouse() {
    const int X0 = 60, X1 = 156, Z0 = 320, Z1 = 384, H = 32;
    Box(X0, G - 1, Z0, X1, G, Z1, M_CONCRETE);
    // walls: concrete plinth + corrugated cladding
    Box(X0, G, Z0, X1, G + H, Z0 + 1, M_CONTAINER);
    Box(X0, G, Z1 - 1, X1, G + H, Z1, M_CONTAINER);
    Box(X0, G, Z0, X0 + 1, G + H, Z1, M_CONTAINER);
    Box(X1 - 1, G, Z0, X1, G + H, Z1, M_CONTAINER);
    Box(X0, G, Z0, X1, G + 4, Z0 + 1, M_CONCRETE);
    Box(X0, G, Z1 - 1, X1, G + 4, Z1, M_CONCRETE);
    Box(X0, G, Z0, X0 + 1, G + 4, Z1, M_CONCRETE);
    Box(X1 - 1, G, Z0, X1, G + 4, Z1, M_CONCRETE);
    for (int x = X0; x < X1; x += 16) {
        Box(x, G, Z0 + 1, x + 2, G + H, Z0 + 3, M_STEEL);
        Box(x, G, Z1 - 3, x + 2, G + H, Z1 - 1, M_STEEL);
        Box(x + 5, G + 20, Z0, x + 11, G + 24, Z0 + 1, M_GLASS);
        Box(x + 5, G + 20, Z1 - 1, x + 11, G + 24, Z1, M_GLASS);
    }
    Box(X0, G + H, Z0, X1, G + H + 1, Z1, M_METAL);
    for (int x = X0 + 8; x < X1 - 6; x += 16) Box(x, G + H, Z0 + 4, x + 4, G + H + 1, Z1 - 4, M_GLASS);
    LightGroup wl;
    wl.radius = 13.0f; wl.color = vec3(0.95f, 0.97f, 1.0f);
    for (int x = X0 + 16; x < X1; x += 16) {
        Box(x, G + H - 2, Z0 + 1, x + 1, G + H, Z1 - 1, M_STEEL);   // roof trusses
        for (int z : {336, 352, 368}) { Set(x, G + H - 3, z, M_LIGHT); wl.lampVoxels.push_back({x, G + H - 3, z}); }
    }
    gD->lights.push_back(wl);
    // big gate on the east wall
    Box(X1 - 1, G, 340, X1, G + 20, 364, M_AIR);
    GatePlace gp;
    gp.center = vec3((X1 - 0.5f) * VS, (G + 10) * VS + 0.02f, 352 * VS);
    gp.half = vec3(0.12f, 2.48f, 2.98f);
    gp.openHeight = 4.9f;
    gp.color = vec4(0.62f, 0.64f, 0.66f, 1);
    int gateIdx = (int)gD->gates.size();
    gD->gates.push_back(gp);
    Switch gs;
    gs.action = SW_GATE; gs.target = gateIdx; gs.label = "Warehouse gate";
    gs.pos = vec3(X1 * VS + 0.03f, (G + 5.5f) * VS, 367.5f * VS); gs.normal = vec3(1, 0, 0);
    gD->switches.push_back(gs);
    gs.pos = vec3((X1 - 1) * VS - 0.03f, (G + 5.5f) * VS, 336.5f * VS); gs.normal = vec3(-1, 0, 0);
    gD->switches.push_back(gs);
    // personnel door
    Box(X1 - 1, G, 326, X1, G + 9, 330, M_AIR);
    gD->doors.push_back({vec3((X1 - 0.5f) * VS, G * VS + 0.03f, 326 * VS + 0.06f), -PI * 0.5f, 7, 17, M_METAL, true, 2500.0f});
    // storage racks
    for (int x = 92; x < 150; x += 20) {
        for (int ux : {x, x + 15}) for (int uz : {324, 327}) Box(ux, G, uz, ux + 1, G + 16, uz + 1, M_STEEL);
        for (int y : {G + 5, G + 10, G + 15}) Box(x, y, 324, x + 16, y + 1, 328, M_PLANK);
        Prop(PROP_CRATE, Mv(x + 4, G + 6, 326), 0.1f);
        Prop(PROP_CRATE, Mv(x + 11, G + 11, 326), -0.1f);
        Prop(PROP_BARREL, Mv(x + 8, G + 1, 326), 0);
    }
    // office in the corner
    Box(84, G, Z0 + 1, 85, G + 12, 338, M_PLASTER);
    Box(X0 + 1, G, 337, 85, G + 12, 338, M_PLASTER);
    Box(X0 + 1, G + 12, Z0 + 1, 85, G + 13, 338, M_CONCRETE);
    Box(84, G + 4, 324, 85, G + 9, 334, M_GLASS);
    Box(70, G, 337, 74, G + 9, 338, M_AIR);
    gD->doors.push_back({Mv(70, G, 337.5f) + vec3(0.06f, 0.03f, 0), 0, 7, 17, M_WOOD, true, 900.0f});
    Prop(PROP_DESK, Mv(72, G, 326), 0);
    Prop(PROP_CHAIR, Mv(72, G, 330), PI);
    Prop(PROP_BOOKCASE, Mv(62, G, 330), PI * 0.5f);
    Prop(PROP_TV, Mv(78, G + 6, 324), 0);
    Set(72, G + 11, 328, M_LIGHT);
    wl.lampVoxels.clear();
    // vault with weight-plate puzzle
    Box(90, G, 356, 92, G + 16, Z1 - 1, M_CONCRETE);
    Box(X0 + 1, G, 356, 92, G + 16, 358, M_CONCRETE);
    Box(X0 + 1, G + 16, 356, 92, G + 17, Z1 - 1, M_CONCRETE);
    Box(68, G, 356, 84, G + 14, 358, M_AIR);
    GatePlace vg;
    vg.center = vec3(76 * VS, (G + 7) * VS + 0.02f, 357 * VS);
    vg.half = vec3(1.98f, 1.73f, 0.22f);
    vg.openHeight = 3.6f;
    vg.color = vec4(0.25f, 0.27f, 0.3f, 1);
    int vaultIdx = (int)gD->gates.size();
    gD->gates.push_back(vg);
    LightGroup vl;
    vl.radius = 8.0f; vl.color = vec3(1.0f, 0.6f, 0.3f);
    Set(76, G + 15, 372, M_LIGHT); vl.lampVoxels.push_back({76, G + 15, 372});
    gD->lights.push_back(vl);
    gD->vehicles.push_back({VEH_LOADER, Mv(76, G, 372) + vec3(0, 1.5f, 0), PI});
    PressurePlate pp;
    pp.center = vec3(112 * VS, G * VS + 0.03f, 368 * VS);
    pp.half = vec3(1.6f, 0.05f, 1.6f);
    pp.threshold = 1500.0f;
    pp.gate = vaultIdx;
    pp.name = "Vault scale";
    gD->plates.push_back(pp);
    Box(104, G - 1, 360, 120, G, 376, M_PAINT_YELLOW);   // marked plate area
    // pallets and loose cargo for the puzzle
    Prop(PROP_PALLET, Mv(130, G, 344), 0);
    Prop(PROP_CRATE, Mv(130, G + 1, 344), 0);
    Prop(PROP_PALLET, Mv(130, G, 360), 0);
    Prop(PROP_CRATE, Mv(130, G + 1, 360), 0.2f);
    Prop(PROP_CRATE, Mv(100, G, 344), 0.4f);
    Prop(PROP_CRATE, Mv(106, G, 340), -0.3f);
    Prop(PROP_CONCRETE_BLOCK, Mv(140, G, 376), 0);
    Prop(PROP_BARREL, Mv(96, G, 378), 0);
    Prop(PROP_BARREL, Mv(99, G, 378), 0);
    Prop(PROP_STEEL_BEAM, Mv(120, G, 330), PI * 0.5f);
    gD->vehicles.push_back({VEH_FORKLIFT, Mv(140, G, 352) + vec3(0, 0.8f, 0), -PI * 0.5f});
    Npc(Mv(110, G, 350), 0, 8.0f);
    gD->landmarks.push_back({Mv(166, G, 352) + vec3(0, 0.1f, 0), "Warehouse"});

    // industrial yard: asphalt + shipping containers
    Box(156, 11, 290, 228, 12, 430, M_ASPHALT);
    Box(X0 - 8, 11, 384, X1, 12, 430, M_ASPHALT);
    Container(166, G, 296, M_CONTAINER, true);
    Container(166, G + 10, 296, M_PAINT_RED, true);
    Container(194, G, 296, M_PAINT_GREEN, true);
    Container(166, G, 396, M_PAINT_RED, true);
    Container(194, G, 396, M_CONTAINER, true);
    Container(194, G + 10, 396, M_PAINT_GREEN, true);
    Container(66, G, 400, M_CONTAINER, true);
    Container(96, G, 400, M_PAINT_GREEN, true);
    for (int i = 0; i < 4; ++i) Prop(PROP_BARREL, Mv(214 + (i % 2) * 3, G, 318 + (i / 2) * 3), 0);
    Prop(PROP_PALLET, Mv(214, G, 340), 0.3f);
    Prop(PROP_CONE, Mv(180, G, 352), 0); Prop(PROP_CONE, Mv(186, G, 352), 0); Prop(PROP_CONE, Mv(192, G, 352), 0);
    gD->vehicles.push_back({VEH_TRUCK, Mv(200, G, 370) + vec3(0, 1.6f, 0), 0});
    Npc(Mv(200, G, 340), 0, 10.0f);
}

// ------------------------------------------------------------------ simple multi-storey block (condemned building)
void Block(int x0, int z0, int w, int d, int floors, uint8_t wall, bool doorSouth) {
    for (int f = 0; f < floors; ++f) {
        int yb = G + f * FLOOR_H;
        Box(x0, yb, z0, x0 + w, yb + 1, z0 + d, M_CONCRETE);
        Box(x0, yb + 1, z0, x0 + w, yb + FLOOR_H, z0 + 1, wall);
        Box(x0, yb + 1, z0 + d - 1, x0 + w, yb + FLOOR_H, z0 + d, wall);
        Box(x0, yb + 1, z0, x0 + 1, yb + FLOOR_H, z0 + d, wall);
        Box(x0 + w - 1, yb + 1, z0, x0 + w, yb + FLOOR_H, z0 + d, wall);
        for (int p = 3; p + 4 <= w - 3; p += 8) {
            Box(x0 + p, yb + 4, z0, x0 + p + 4, yb + 9, z0 + 1, M_GLASS);
            Box(x0 + p, yb + 4, z0 + d - 1, x0 + p + 4, yb + 9, z0 + d, M_GLASS);
        }
        for (int p = 3; p + 4 <= d - 3; p += 8) {
            Box(x0, yb + 4, z0 + p, x0 + 1, yb + 9, z0 + p + 4, M_GLASS);
            Box(x0 + w - 1, yb + 4, z0 + p, x0 + w, yb + 9, z0 + p + 4, M_GLASS);
        }
        Box(x0 + w / 2, yb + 1, z0 + 1, x0 + w / 2 + 1, yb + FLOOR_H, z0 + d - 1, M_PLASTER);
        Box(x0 + w / 2, yb + 1, z0 + d / 2 - 2, x0 + w / 2 + 1, yb + 10, z0 + d / 2 + 2, M_AIR);
        if (f + 1 < floors) {
            for (int k = 0; k < 12; ++k) Box(x0 + w - 6, yb + 1, z0 + 2 + k, x0 + w - 2, yb + 2 + k, z0 + 3 + k, M_CONCRETE);
            Box(x0 + w - 6, yb + FLOOR_H, z0 + 2, x0 + w - 2, yb + FLOOR_H + 1, z0 + 13, M_AIR);
        }
        float fy = (yb + 1) * VS + 0.02f;
        Prop(f % 2 ? PROP_SOFA : PROP_TABLE, Mv(x0 + 6, 0, z0 + 8) + vec3(0, fy, 0), 0.2f * f);
        Prop(PROP_CRATE, Mv(x0 + 8, 0, z0 + d - 6) + vec3(0, fy, 0), 0.5f);
        Prop(f == 0 ? PROP_BOOKCASE : PROP_CHAIR, Mv(x0 + 4, 0, z0 + d - 4) + vec3(0, fy, 0), 0);
    }
    int yt = G + floors * FLOOR_H;
    Box(x0, yt, z0, x0 + w, yt + 1, z0 + d, M_CONCRETE);
    Box(x0, yt + 1, z0, x0 + w, yt + 3, z0 + 1, wall);
    Box(x0, yt + 1, z0 + d - 1, x0 + w, yt + 3, z0 + d, wall);
    Box(x0, yt + 1, z0, x0 + 1, yt + 3, z0 + d, wall);
    Box(x0 + w - 1, yt + 1, z0, x0 + w, yt + 3, z0 + d, wall);
    if (doorSouth) {
        Box(x0 + 6, G + 1, z0 + d - 1, x0 + 10, G + 10, z0 + d, M_AIR);
        gD->doors.push_back({Mv(x0 + 6, G + 1, z0 + d - 0.5f) + vec3(0.06f, 0.03f, 0), 0, 7, 17, M_WOOD, false, 800.0f});
    }
}

// ------------------------------------------------------------------ construction site + crane + park
void ConstructionSite() {
    // crane tower (lattice)
    const int CX = 420, CZ = 420, TOP = 88;
    Box(CX - 4, G - 1, CZ - 4, CX + 12, G + 2, CZ + 12, M_CONCRETE);
    for (int y = G + 2; y < TOP; ++y) {
        for (int cx : {CX, CX + 7}) for (int cz : {CZ, CZ + 7}) Set(cx, y, cz, M_STEEL);
        int ph = (y - G) % 8;
        if (ph == 0) {
            Box(CX, y, CZ, CX + 8, y + 1, CZ + 1, M_STEEL); Box(CX, y, CZ + 7, CX + 8, y + 1, CZ + 8, M_STEEL);
            Box(CX, y, CZ, CX + 1, y + 1, CZ + 8, M_STEEL); Box(CX + 7, y, CZ, CX + 8, y + 1, CZ + 8, M_STEEL);
        } else {
            Set(CX + ph, y, CZ, M_STEEL); Set(CX + 7 - ph, y, CZ + 7, M_STEEL);
            Set(CX, y, CZ + ph, M_STEEL); Set(CX + 7, y, CZ + 7 - ph, M_STEEL);
        }
    }
    Box(CX - 1, TOP, CZ - 1, CX + 9, TOP + 2, CZ + 9, M_STEEL);
    Box(CX + 1, TOP + 2, CZ + 1, CX + 7, TOP + 6, CZ + 5, M_PAINT_YELLOW);
    Box(CX + 2, TOP + 3, CZ + 1, CX + 6, TOP + 5, CZ + 2, M_GLASS);
    // tower ladder side
    for (int y = G + 2; y < TOP; y += 2) Set(CX + 3, y, CZ + 8, M_METAL);
    CranePlace cp;
    cp.pivot = vec3((CX + 4) * VS, (TOP + 2) * VS + 0.5f, (CZ + 4) * VS);
    cp.jib = 16.0f; cp.angle = PI * 0.5f; cp.chain = 12.5f;
    int craneIdx = (int)gD->cranes.size();
    gD->cranes.push_back(cp);
    Switch cs;
    cs.action = SW_CRANE; cs.target = craneIdx; cs.label = "Crane start / stop";
    cs.pos = vec3((CX + 6) * VS, (G + 5.5f) * VS, (CZ + 12) * VS + 0.03f); cs.normal = vec3(0, 0, 1);
    gD->switches.push_back(cs);
    cs.action = SW_CRANE_DROP; cs.label = "Release wrecking ball";
    cs.pos = vec3((CX + 2) * VS, (G + 5.5f) * VS, (CZ + 12) * VS + 0.03f);
    gD->switches.push_back(cs);
    Box(CX - 4, G + 2, CZ + 11, CX + 12, G + 8, CZ + 12, M_CONCRETE);   // control wall
    gD->landmarks.push_back({vec3((CX + 4) * VS, G * VS + 0.1f, (CZ + 16) * VS), "Crane"});

    // condemned brick building in the crane's swing radius
    Block(340, 404, 32, 32, 3, M_BRICK, true);
    Npc(Mv(350, G + 1, 412), 0, 3.0f);

    // concrete frame under construction
    const int FX0 = 440, FX1 = 488, FZ0 = 296, FZ1 = 344;
    for (int f = 0; f <= 4; ++f) {
        int yb = G + f * FLOOR_H;
        if (f > 0 && f < 4) Box(FX0, yb, FZ0, FX1, yb + 1, FZ1, M_CONCRETE);
        if (f == 4) Box(FX0, yb, FZ0, FX0 + 32, yb + 1, FZ1, M_CONCRETE);   // top slab only partially poured
        if (f == 0) Box(FX0, yb, FZ0, FX1, yb + 1, FZ1, M_CONCRETE);
        if (f < 4)
            for (int x = FX0; x < FX1; x += 15)
                for (int z = FZ0; z < FZ1; z += 15) Box(x, yb + 1, z, x + 2, yb + FLOOR_H, z + 2, M_CONCRETE);
        if (f < 4) {
            int s = yb + 1;
            for (int k = 0; k < 12; ++k) Box(FX1 - 6, s, FZ0 + 3 + k, FX1 - 2, s + 1 + k, FZ0 + 4 + k, M_CONCRETE);
            Box(FX1 - 6, yb + FLOOR_H, FZ0 + 3, FX1 - 2, yb + FLOOR_H + 1, FZ0 + 14, M_AIR);
        }
    }
    Box(FX0, G + 1, FZ0, FX0 + 30, G + 9, FZ0 + 1, M_BRICK);
    Box(FX0, G + 1, FZ0, FX0 + 1, G + 6, FZ1, M_BRICK);
    Box(FX0, G + FLOOR_H + 1, FZ0, FX0 + 16, G + FLOOR_H + 4, FZ0 + 1, M_BRICK);
    // scaffolding along the south face
    for (int x = FX0; x <= FX1; x += 8)
        for (int z : {FZ1 + 1, FZ1 + 6}) Box(x, G, z, x + 1, G + 40, z + 1, M_METAL);
    for (int y = G + 10; y < G + 40; y += 10) Box(FX0, y, FZ1 + 1, FX1 + 1, y + 1, FZ1 + 7, M_PLANK);
    // materials
    for (int i = 0; i < 3; ++i) Prop(PROP_STEEL_BEAM, Mv(452 + i * 3, G, 360), 0);
    Prop(PROP_STEEL_BEAM, Mv(455, G + 3, 362), 0.05f);
    Prop(PROP_CONCRETE_BLOCK, Mv(470, G, 362), 0);
    Prop(PROP_CONCRETE_BLOCK, Mv(478, G, 362), 0.3f);
    Prop(PROP_BRICK_PILE, Mv(462, G, 372), 0);
    Prop(PROP_BRICK_PILE, Mv(466, G, 376), 0.6f);
    Prop(PROP_PALLET, Mv(474, G, 376), 0);
    Prop(PROP_PLANK, Mv(450, G, 380), 0.2f);
    Prop(PROP_PLANK, Mv(452, G, 382), 0.3f);
    Prop(PROP_WALL_SECTION, Mv(484, G, 380), 0);
    for (int i = 0; i < 5; ++i) Prop(PROP_CONE, Mv(436 + i * 6, G, 352), 0);
    // sand piles
    for (int pile = 0; pile < 2; ++pile) {
        int px = 470 + pile * 18, pz = 410;
        for (int dz = -9; dz <= 9; ++dz)
            for (int dx = -9; dx <= 9; ++dx) {
                float r = std::sqrt((float)(dx * dx + dz * dz));
                int h = (int)((9.0f - r) * 0.7f);
                if (h > 0) Box(px + dx, G, pz + dz, px + dx + 1, G + h, pz + dz + 1, M_SAND);
            }
    }
    gD->landmarks.push_back({Mv(464, G, 356) + vec3(0, 0.1f, 0), "Construction Site"});
    Npc(Mv(460, G, 365), 0, 10.0f);

    // park
    Box(296, 11, 342, 392, 12, 346, M_SAND);
    Box(342, 11, 296, 346, 12, 392, M_SAND);
    const int trees[][2] = {{304, 304}, {320, 330}, {300, 370}, {330, 380}, {370, 304}, {384, 330}, {365, 372}, {386, 386}};
    for (auto& t : trees) Tree(t[0], t[1], 16 + (t[0] % 3) * 3, 6 + t[1] % 2, (uint32_t)(t[0] * 7 + t[1]));
    Prop(PROP_BENCH, Mv(336, G, 340), 0); Prop(PROP_BENCH, Mv(352, G, 340), 0);
    Prop(PROP_BENCH, Mv(336, G, 350), PI); Prop(PROP_BENCH, Mv(352, G, 350), PI);
    Prop(PROP_WOOD_TOWER, Mv(366, G, 320), 0);
    Prop(PROP_GLASS_TOWER, Mv(372, G, 326), 0);
    Prop(PROP_WOOD_TOWER, Mv(378, G, 318), 0.4f);
    Prop(PROP_BIG_BALL, Mv(330, G, 372), 0);
    Prop(PROP_TRASHCAN, Mv(346, G, 338), 0);
    gD->seesaws.push_back({vec3(318 * VS, G * VS + 0.6f, 318 * VS), 0.3f});
    for (int x : {312, 340}) Box(x, G, 316, x + 1, G + 2, 321, M_METAL);   // seesaw stand hint
    Box(316, G, 317, 321, G + 2, 320, M_METAL);
    LightGroup pl;
    pl.nightOnly = true; pl.radius = 9.0f; pl.color = vec3(1.0f, 0.85f, 0.55f);
    for (int x : {320, 368}) for (int z : {336, 352}) {
        Box(x, G, z, x + 1, G + 14, z + 1, M_METAL);
        Set(x, G + 14, z, M_LIGHT);
        pl.lampVoxels.push_back({x, G + 14, z});
    }
    gD->lights.push_back(pl);
    Npc(Mv(344, G, 330), 0, 12.0f);
    Npc(Mv(344, G, 360), PI, 12.0f);
    gD->landmarks.push_back({Mv(344, G, 344) + vec3(0, 0.1f, 0), "Park"});
}

void Roads() {
    const int S = VoxelWorld::SX;
    // N-S road x[236,276), E-W road z[236,276), sidewalks 8 voxels
    Box(236, 11, 0, 276, 12, S, M_ASPHALT);
    Box(0, 11, 236, S, 12, 276, M_ASPHALT);
    for (int side : {228, 276}) {
        Box(side, 11, 0, side + 8, 12, S, M_CONCRETE);
        Box(0, 11, side, S, 12, side + 8, M_CONCRETE);
    }
    Box(236, 11, 236, 276, 12, 276, M_ASPHALT);
    // curbs
    for (int c : {235, 276}) { Box(c, 11, 0, c + 1, 12, S, M_CURB); Box(0, 11, c, S, 12, c + 1, M_CURB); }
    Box(236, 11, 228, 276, 12, 284, M_ASPHALT);
    Box(228, 11, 236, 284, 12, 276, M_ASPHALT);
    // dashed center lines
    for (int t = 0; t < S; t += 16) {
        if (t >= 228 && t < 284) continue;
        Box(255, 11, t, 257, 12, t + 8, M_ROADLINE);
        Box(t, 11, 255, t + 8, 12, 257, M_ROADLINE);
    }
    // crosswalks
    for (int k = 238; k < 274; k += 4) {
        Box(k, 11, 222, k + 2, 12, 234, M_ROADLINE); Box(k, 11, 278, k + 2, 12, 290, M_ROADLINE);
        Box(222, 11, k, 234, 12, k + 2, M_ROADLINE); Box(278, 11, k, 290, 12, k + 2, M_ROADLINE);
    }
    Box(236, 11, 222, 276, 12, 234, M_ASPHALT);
    for (int k = 238; k < 274; k += 4) Box(k, 11, 224, k + 2, 12, 232, M_ROADLINE);
    // street lamps
    LightGroup sl;
    sl.nightOnly = true; sl.radius = 11.0f; sl.color = vec3(1.0f, 0.78f, 0.45f);
    for (int t = 24; t < S - 16; t += 48) {
        if (t > 212 && t < 300) continue;
        StreetLamp(229, t, 1, 0, sl);
        StreetLamp(282, t + 24, -1, 0, sl);
        StreetLamp(t, 229, 0, 1, sl);
        StreetLamp(t + 24, 282, 0, -1, sl);
    }
    gD->lights.push_back(sl);
    // perimeter wall
    Box(0, G, 0, S, G + 6, 2, M_CONCRETE);
    Box(0, G, S - 2, S, G + 6, S, M_CONCRETE);
    Box(0, G, 0, 2, G + 6, S, M_CONCRETE);
    Box(S - 2, G, 0, S, G + 6, S, M_CONCRETE);
    for (int r : {236, 276}) {   // openings where the roads meet the wall are closed with barriers
        (void)r;
    }
    // street furniture
    for (int t = 40; t < S - 40; t += 96) {
        if (t > 200 && t < 312) continue;
        Prop(PROP_BENCH, Mv(232, G, t + 10), PI * 0.5f);
        Prop(PROP_TRASHCAN, Mv(232, G, t + 16), 0);
        Prop(PROP_BENCH, Mv(t + 10, G, 280), 0);
    }
    gD->vehicles.push_back({VEH_VAN, Mv(300, G, 244) + vec3(0, 1.3f, 0), PI * 0.5f});
    gD->vehicles.push_back({VEH_CAR, Mv(246, G, 300) + vec3(0, 1.0f, 0), 0});
    gD->vehicles.push_back({VEH_CAR, Mv(140, G, 266) + vec3(0, 1.0f, 0), -PI * 0.5f});
    Npc(Mv(232, G, 190), 0, 14.0f);
    Npc(Mv(300, G, 280), PI, 14.0f);
}

}  // namespace

void BuildVoxels(VoxelWorld& w, MapData& data, std::function<void(float)> progress) {
    gW = &w; gD = &data;
    const int S = VoxelWorld::SX;
    // terrain
    Box(0, 0, 0, S, 1, S, M_BEDROCK);
    Box(0, 1, 0, S, 11, S, M_DIRT);
    Box(0, 11, 0, S, 12, S, M_GRASS);
    if (progress) progress(0.05f);
    Roads();
    if (progress) progress(0.15f);
    // residential block (north-west)
    House(Frame{40, 170, 2, 40, 32}, 2, M_BRICK, M_ROOF, 0);
    House(Frame{110, 170, 2, 40, 32}, 2, M_PLASTER, M_ROOF, 1);
    House(Frame{184, 40, 3, 40, 32}, 2, M_BRICK, M_ROOF, 2);
    House(Frame{184, 100, 3, 40, 32}, 1, M_PLASTER, M_ROOF, 3);
    House(Frame{40, 60, 0, 40, 32}, 2, M_PLASTER, M_ROOF, 4);
    gD->vehicles.push_back({VEH_CAR, Mv(98, G, 214) + vec3(0, 1.0f, 0), PI});
    const int nwTrees[][2] = {{30, 140}, {100, 140}, {150, 120}, {140, 60}, {20, 30}, {90, 20}, {160, 20}, {24, 216}, {200, 216}};
    for (auto& t : nwTrees) Tree(t[0], t[1], 16 + (t[1] % 4) * 2, 6, (uint32_t)(t[0] * 13 + t[1]));
    gD->landmarks.push_back({Mv(100, G, 220) + vec3(0, 0.1f, 0), "Residential Street"});
    if (progress) progress(0.35f);
    ApartmentTower();
    const int neTrees[][2] = {{420, 60}, {460, 120}, {480, 200}, {300, 40}};
    for (auto& t : neTrees) Tree(t[0], t[1], 18, 7, (uint32_t)(t[0] * 3 + t[1]));
    if (progress) progress(0.55f);
    Warehouse();
    if (progress) progress(0.7f);
    ConstructionSite();
    if (progress) progress(0.85f);
    data.spawn = vec3(232 * VOXEL_SIZE, G * VOXEL_SIZE + 0.05f, 222 * VOXEL_SIZE);
    data.spawnYaw = PI * 0.75f;
    data.landmarks.insert(data.landmarks.begin(), {data.spawn, "Spawn (Crossroads)"});
    if (progress) progress(1.0f);
}

}  // namespace MapBuilder
