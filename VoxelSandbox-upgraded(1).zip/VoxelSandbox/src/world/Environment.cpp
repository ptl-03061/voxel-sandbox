#include "world/Environment.h"
#include "engine/Audio.h"
#include "destruction/VoxelWorld.h"

const char* WeatherName(Weather w) {
    switch (w) {
    case Weather::Clear: return "Clear";
    case Weather::Cloudy: return "Cloudy";
    case Weather::Rain: return "Rain";
    case Weather::Storm: return "Storm";
    case Weather::Fog: return "Fog";
    default: return "?";
    }
}

static float Approach(float cur, float target, float rate, float dt) {
    float k = 1.0f - std::exp(-rate * dt);
    return cur + (target - cur) * k;
}

void Environment::update(float dt, const vec3& camPos, Particles& particles, const VoxelWorld& world) {
    mTime += dt;
    if (!cyclePaused) timeOfDay = std::fmod(timeOfDay + dt * daySpeed, 24.0f);

    // automatic weather changes every few minutes
    mWeatherTimer += dt;
    if (autoWeather && mWeatherTimer > 240.0f) {
        mWeatherTimer = 0;
        float r = GRng().f01();
        weather = r < 0.4f ? Weather::Clear : r < 0.62f ? Weather::Cloudy : r < 0.82f ? Weather::Rain : r < 0.92f ? Weather::Storm : Weather::Fog;
    }

    // sun path: rises at 6, sets at 18
    float ang = (timeOfDay - 6.0f) / 12.0f * 3.14159265f;
    vec3 sun = glm::normalize(vec3(std::cos(ang) * 0.85f, std::sin(ang), 0.35f));
    float sunH = sun.y;
    float nightTarget = glm::clamp(0.5f - sunH * 3.0f, 0.0f, 1.0f);
    mNight = nightTarget;
    // at night the shadow-casting light is the moon (opposite of the sun)
    mSunDir = sunH > -0.05f ? sun : glm::normalize(vec3(-sun.x, -sun.y, sun.z) + vec3(0, 0.1f, 0));
    if (mSunDir.y < 0.08f) mSunDir = glm::normalize(vec3(mSunDir.x, 0.08f, mSunDir.z));

    float cloudT = 0.15f, rainT = 0, fogT = 0;
    switch (weather) {
    case Weather::Clear: cloudT = 0.15f; break;
    case Weather::Cloudy: cloudT = 0.75f; break;
    case Weather::Rain: cloudT = 0.9f; rainT = 0.7f; fogT = 0.25f; break;
    case Weather::Storm: cloudT = 1.0f; rainT = 1.0f; fogT = 0.35f; break;
    case Weather::Fog: cloudT = 0.6f; fogT = 1.0f; break;
    default: break;
    }
    mCloud = Approach(mCloud, cloudT, 0.3f, dt);
    mRain = Approach(mRain, rainT, 0.4f, dt);
    mFog = Approach(mFog, fogT, 0.3f, dt);
    mWet = glm::clamp(mWet + (mRain > 0.2f ? dt * 0.05f : -dt * 0.02f), 0.0f, 1.0f);
    float windStrength = 1.0f + mRain * 3.0f + (weather == Weather::Storm ? 3.0f : 0.0f);
    mWind = vec3(std::cos(mTime * 0.05f), 0, std::sin(mTime * 0.05f) * 0.5f + 0.5f) * windStrength;

    // colors
    float day = 1.0f - mNight;
    float dusk = glm::clamp(1.0f - std::abs(sunH) * 4.0f, 0.0f, 1.0f);
    vec3 skyDay(0.32f, 0.55f, 0.9f), skyNight(0.02f, 0.03f, 0.07f), skyDusk(0.55f, 0.38f, 0.42f);
    vec3 horDay(0.72f, 0.8f, 0.9f), horNight(0.05f, 0.06f, 0.1f), horDusk(0.95f, 0.55f, 0.3f);
    mSky = glm::mix(glm::mix(skyNight, skyDay, day), skyDusk, dusk * 0.6f);
    mHorizon = glm::mix(glm::mix(horNight, horDay, day), horDusk, dusk * 0.7f);
    vec3 grey = vec3(glm::dot(mSky, vec3(0.33f))) * 0.9f + vec3(0.05f);
    mSky = glm::mix(mSky, grey * (0.4f + 0.6f * day), mCloud * 0.75f);
    mHorizon = glm::mix(mHorizon, vec3(glm::dot(mHorizon, vec3(0.33f))), mCloud * 0.6f);
    vec3 sunCol = glm::mix(vec3(1.0f, 0.96f, 0.88f) * 2.6f, vec3(1.6f, 0.75f, 0.4f), dusk);
    vec3 moonCol(0.25f, 0.32f, 0.5f);
    mSunColor = sunH > -0.05f ? sunCol * glm::clamp(sunH * 6.0f + 0.3f, 0.0f, 1.0f) : moonCol;
    mSunColor *= (1.0f - mCloud * 0.65f);
    mFogColor = glm::mix(mHorizon, vec3(0.55f, 0.58f, 0.62f) * (0.2f + 0.8f * day), mFog * 0.8f);

    // lightning
    mFlash = std::max(0.0f, mFlash - dt * 3.5f);
    if (weather == Weather::Storm && mRain > 0.6f) {
        mLightningTimer -= dt;
        if (mLightningTimer <= 0) {
            mLightningTimer = GRng().range(5.0f, 14.0f);
            mFlash = 1.0f;
            mFlashPos = camPos + vec3(GRng().range(-150, 150), 0, GRng().range(-150, 150));
            mThunderDelay = glm::length(mFlashPos - camPos) / 340.0f + 0.2f;
        }
    }
    if (mThunderDelay >= 0) {
        mThunderDelay -= dt;
        if (mThunderDelay < 0) GAudio().play(SND_THUNDER, camPos, 1.0f, GRng().range(0.8f, 1.1f), false, false, SoundCat::Ambient);
    }

    // rain particles around the camera (skip indoors: rain only where the column above is open)
    if (mRain > 0.05f) {
        int n = (int)(mRain * 220.0f * dt * 30.0f / 30.0f * 3.0f);
        for (int i = 0; i < n; ++i) {
            vec3 p = camPos + vec3(GRng().range(-14, 14), GRng().range(4, 14), GRng().range(-14, 14));
            ivec3 v = ivec3(glm::floor(p / VOXEL_SIZE));
            // cheap roof test: sample a few voxels above the drop
            bool covered = false;
            for (int k = 0; k < 40 && !covered; k += 4)
                if (world.inBounds(v.x, v.y + k, v.z) && IsSolid(world.get(v.x, v.y + k, v.z))) covered = true;
            if (covered) continue;
            particles.spawn(PType::Rain, p, vec3(mWind.x * 0.5f, -16.0f, mWind.z * 0.5f), vec4(0.7f, 0.75f, 0.85f, 0.45f), 0.03f, 1.4f);
        }
    }

    // ambience loops
    Audio& a = GAudio();
    auto loop = [&](uint32_t& h, SoundId id, float vol) {
        if (vol > 0.02f) {
            if (!h || !a.playing(h)) h = a.play(id, camPos, vol, 1.0f, false, true, SoundCat::Ambient);
            else a.setVoice(h, camPos, vol, 1.0f);
        } else if (h) { a.stop(h); h = 0; }
    };
    float indoorDamp = 1.0f;
    {
        ivec3 v = ivec3(glm::floor(camPos / VOXEL_SIZE));
        for (int k = 4; k < 60; k += 3)
            if (world.inBounds(v.x, v.y + k, v.z) && IsSolid(world.get(v.x, v.y + k, v.z))) { indoorDamp = 0.45f; break; }
    }
    loop(mAmbWind, SND_AMB_WIND, (0.18f + mCloud * 0.2f + (weather == Weather::Storm ? 0.3f : 0.0f)) * indoorDamp);
    loop(mAmbBirds, SND_AMB_BIRDS, (1.0f - mNight) * (1.0f - mRain) * 0.35f * indoorDamp);
    loop(mAmbNight, SND_AMB_NIGHT, mNight * (1.0f - mRain) * 0.35f * indoorDamp);
    loop(mAmbRain, SND_AMB_RAIN, mRain * 0.7f * indoorDamp);
}

void Environment::stopAmbience() {
    for (uint32_t* h : {&mAmbWind, &mAmbBirds, &mAmbNight, &mAmbRain})
        if (*h) { GAudio().stop(*h); *h = 0; }
}

void Environment::fill(FrameParams& fp) const {
    fp.sunDir = mSunDir;
    fp.sunColor = mSunColor;
    fp.skyColor = mSky;
    fp.horizonColor = mHorizon;
    fp.groundColor = glm::mix(vec3(0.28f, 0.25f, 0.22f), vec3(0.03f, 0.03f, 0.04f), mNight);
    fp.fogColor = mFogColor;
    fp.fogDensity = 0.004f + mFog * 0.028f + mRain * 0.004f;
    fp.fogHeight = 3.0f + mFog * 10.0f;
    fp.wetness = mWet;
    fp.night = mNight;
    fp.cloudCover = mCloud;
    fp.emissiveScale = 0.6f + mNight * 1.8f;
    fp.flash = mFlash;
}
