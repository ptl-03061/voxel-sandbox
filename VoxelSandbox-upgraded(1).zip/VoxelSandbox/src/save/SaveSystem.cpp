#include "save/SaveSystem.h"
#include "Game.h"
#include "destruction/Destruction.h"
#include "world/Environment.h"
#include "gameplay/Props.h"
#include "gameplay/Vehicle.h"
#include "gameplay/Npc.h"
#include "gameplay/Sandbox.h"
#include "gameplay/Player.h"

void SaveSystem::hookDestruction() {
    mGame->destr.onVoxelRemoved = [this](const ivec3& v) { recordRemoval(v); };
}

void SaveSystem::recordRemoval(const ivec3& v) {
    auto& runs = mEdits[{v.x, v.z}];
    for (auto& r : runs)
        if (v.y >= r.y0 - 1 && v.y <= r.y1 + 1) { r.y0 = std::min(r.y0, v.y); r.y1 = std::max(r.y1, v.y); return; }
    runs.push_back({v.y, v.y});
}

bool SaveSystem::hasSave(const std::string& path) const {
    FILE* f = fopen(path.c_str(), "rb");
    if (f) { fclose(f); return true; }
    return false;
}

bool SaveSystem::save(const std::string& path, std::string& err) {
    Game& g = *mGame;
    if (!g.worldReady) { err = "world not ready"; return false; }
    std::string tmp = path + ".tmp";
    FILE* f = fopen(tmp.c_str(), "wb");
    if (!f) { err = "cannot open " + tmp; return false; }
    fprintf(f, "voxelsandbox-save %d\n", VERSION);
    vec3 p = g.player.feet();
    fprintf(f, "player %.3f %.3f %.3f %.4f %d\n", p.x, p.y, p.z, g.player.yaw, (int)g.sandbox.tool);
    fprintf(f, "env %.4f %d %.3f %.2f\n", g.env.timeOfDay, (int)g.env.weather, g.gravityScale, g.timeScale);
    for (auto& op : g.objs.objects()) {
        VoxelObject* o = op.get();
        if (!o->alive || (o->flags & (OBJ_DEBRIS | OBJ_STRUCTURE))) continue;
        if (o->flags & OBJ_PROP) {
            vec3 c = o->bounds.center();
            fprintf(f, "obj %s %.3f %.3f %.3f %.4f %.3f\n", o->name.c_str(), c.x, c.y, c.z, 0.0f, o->scale);
        }
    }
    for (auto& v : g.vehicles.vehicles()) {
        vec3 vp = v->position();
        fprintf(f, "veh %d %.3f %.3f %.3f\n", (int)v->type, vp.x, vp.y, vp.z);
    }
    for (auto& n : g.npcs.npcs())
        fprintf(f, "npc %.3f %.3f %.3f\n", n->home.x, n->home.y, n->home.z);
    for (auto& kv : mEdits) {
        fprintf(f, "col %d %d", kv.first.first, kv.first.second);
        for (auto& r : kv.second) fprintf(f, " %d %d", r.y0, r.y1);
        fprintf(f, "\n");
    }
    fprintf(f, "end\n");
    fclose(f);
    if (rename(tmp.c_str(), path.c_str()) != 0) { err = "rename failed"; return false; }
    return true;
}

bool SaveSystem::load(const std::string& path, std::string& err) {
    FILE* f = fopen(path.c_str(), "rb");
    if (!f) { err = "no save file"; return false; }
    char line[512];
    if (!fgets(line, sizeof line, f) || strncmp(line, "voxelsandbox-save ", 18) != 0) {
        fclose(f); err = "not a save file"; return false;
    }
    int ver = atoi(line + 18);
    if (ver > VERSION) { fclose(f); err = "save is from a newer version"; return false; }
    Game& g = *mGame;
    std::vector<std::string> pending;
    while (fgets(line, sizeof line, f)) {
        if (!strncmp(line, "end", 3)) break;
        char key[16];
        if (sscanf(line, "%15s", key) != 1) continue;
        if (!strcmp(key, "player")) {
            float x, y, z, yaw; int tool;
            if (sscanf(line + 6, "%f %f %f %f %d", &x, &y, &z, &yaw, &tool) == 5) {
                g.player.teleport(vec3(x, y + 0.05f, z));
                g.player.yaw = yaw;
            }
        } else if (!strcmp(key, "env")) {
            float tod, gsc, tsc; int w;
            if (sscanf(line + 4, "%f %d %f %f", &tod, &w, &gsc, &tsc) == 4) {
                g.env.timeOfDay = tod; g.env.setWeather((Weather)w);
                g.setGravityScale(gsc); g.timeScale = tsc;
            }
        } else if (!strcmp(key, "obj") || !strcmp(key, "veh") || !strcmp(key, "npc")) {
            pending.push_back(line);
        } else if (!strcmp(key, "col")) {
            int x, z, y0, y1, adv;
            const char* s = line + 4;
            if (sscanf(s, "%d %d%n", &x, &z, &adv) == 2) {
                s += adv;
                while (sscanf(s, " %d %d%n", &y0, &y1, &adv) == 2) {
                    s += adv;
                    for (int y = y0; y <= y1; ++y)
                        if (g.world.inBounds(x, y, z) && g.world.get(x, y, z)) {
                            g.world.set(x, y, z, M_AIR);
                            g.destr.addWeakness(ivec3(x, y - 1, z), 0.05f);
                        }
                }
            }
        }
    }
    fclose(f);
    for (auto& l : pending) {
        char key[16], name[64];
        sscanf(l.c_str(), "%15s", key);
        if (!strcmp(key, "veh")) {
            int t; float x, y, z;
            if (sscanf(l.c_str() + 4, "%d %f %f %f", &t, &x, &y, &z) == 4 &&
                t >= 0 && t < (int)VEH_COUNT)
                g.vehicles.spawn((VehicleType)t, vec3(x, y + 0.3f, z), 0.0f);
        } else if (!strcmp(key, "npc")) {
            float x, y, z;
            if (sscanf(l.c_str() + 4, "%f %f %f", &x, &y, &z) == 3)
                g.npcs.spawn(vec3(x, y + 0.02f, z), 0.0f);
        } else {
            float x, y, z, yaw, sc;
            if (sscanf(l.c_str() + 4, "%63s %f %f %f %f %f", name, &x, &y, &z, &yaw, &sc) == 6) {
                for (int t = 0; t < (int)PROP_COUNT; ++t)
                    if (!strcmp(GetPropDef(t).name, name)) {
                        VoxelModel m = BuildProp(t);
                        vec3 size = m.sizeMeters();
                        quat rot = glm::angleAxis(yaw, vec3(0, 1, 0));
                        vec3 corner = vec3(x, y, z) - rot * vec3(size.x * 0.5f, size.y * 0.5f, size.z * 0.5f);
                        g.objs.create(std::move(m), corner, rot, OBJ_PROP, vec3(0), vec3(0), sc, name);
                        break;
                    }
            }
        }
    }
    mEdits.clear();
    return true;
}
