// Persistent sandbox state: player, environment, spawned objects/vehicles/NPCs and world
// edits (destroyed voxels as per-column run-length ranges) so destruction persists between
// sessions. Versioned text format; unreadable files are rejected, never fatal.
#pragma once
#include "core/Common.h"
#include <map>

class Game;

class SaveSystem {
public:
    void init(Game* g) { mGame = g; }
    void hookDestruction();            // installs the onVoxelRemoved edit log
    void recordRemoval(const ivec3& v);

    bool save(const std::string& path, std::string& err);
    bool load(const std::string& path, std::string& err);
    bool hasSave(const std::string& path) const;

    int editCount() const { return (int)mEdits.size(); }

private:
    struct Run { int y0, y1; };
    std::map<std::pair<int, int>, std::vector<Run>> mEdits;   // (x,z) -> sorted runs
    Game* mGame = nullptr;
    static constexpr int VERSION = 1;
};
