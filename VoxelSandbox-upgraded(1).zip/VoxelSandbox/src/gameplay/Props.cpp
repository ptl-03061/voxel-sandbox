#include "gameplay/Props.h"

static const PropDef kDefs[PROP_COUNT] = {
    {"Wooden Crate", "Physics"},   {"Oil Barrel", "Physics"},       {"Chair", "Furniture"},
    {"Table", "Furniture"},        {"Sofa", "Furniture"},           {"Bed", "Furniture"},
    {"Shelf", "Furniture"},        {"Fridge", "Furniture"},         {"Glass Pane", "Construction"},
    {"Concrete Block", "Construction"}, {"Brick Pile", "Construction"}, {"Steel Beam", "Construction"},
    {"Wood Plank", "Construction"}, {"Pallet", "Construction"},     {"Traffic Cone", "Physics"},
    {"Park Bench", "Furniture"},   {"Trash Can", "Physics"},        {"Brick Wall", "Construction"},
    {"Television", "Furniture"},   {"Floor Lamp", "Furniture"},     {"Bookcase", "Furniture"},
    {"Desk", "Furniture"},         {"Plank Tower", "Physics"},      {"Glass Tower", "Physics"},
    {"Heavy Ball", "Physics"},
};

const PropDef& GetPropDef(int t) { return kDefs[glm::clamp(t, 0, PROP_COUNT - 1)]; }

static constexpr float FINE = 0.125f;

VoxelModel BuildProp(int type) {
    VoxelModel m;
    switch (type) {
    case PROP_CRATE: {
        m.resize({7, 7, 7}, FINE);
        m.box({0, 0, 0}, {7, 7, 7}, M_PLANK);
        for (int i = 0; i < 7; ++i) {   // dark frame edges
            for (int a = 0; a < 7; a += 6)
                for (int b = 0; b < 7; b += 6) { m.set(i, a, b, M_DARKWOOD); m.set(a, i, b, M_DARKWOOD); m.set(a, b, i, M_DARKWOOD); }
        }
        break;
    }
    case PROP_BARREL: {
        m.resize({5, 7, 5}, FINE);
        for (int y = 0; y < 7; ++y)
            for (int z = 0; z < 5; ++z)
                for (int x = 0; x < 5; ++x) {
                    float dx = x - 2.0f, dz = z - 2.0f;
                    if (dx * dx + dz * dz <= 5.2f) m.set(x, y, z, (y == 1 || y == 5) ? M_RUST : M_PAINT_RED);
                }
        break;
    }
    case PROP_CHAIR: {
        m.resize({4, 8, 4}, FINE);
        for (int lx : {0, 3}) for (int lz : {0, 3}) m.box({lx, 0, lz}, {lx + 1, 3, lz + 1}, M_WOOD);
        m.box({0, 3, 0}, {4, 4, 4}, M_WOOD);
        m.box({0, 4, 3}, {4, 8, 4}, M_WOOD);
        m.box({1, 5, 3}, {3, 7, 4}, M_FABRIC);
        break;
    }
    case PROP_TABLE: {
        m.resize({10, 6, 6}, FINE);
        for (int lx : {0, 9}) for (int lz : {0, 5}) m.box({lx, 0, lz}, {lx + 1, 5, lz + 1}, M_DARKWOOD);
        m.box({0, 5, 0}, {10, 6, 6}, M_WOOD);
        break;
    }
    case PROP_SOFA: {
        m.resize({14, 6, 6}, FINE);
        m.box({0, 0, 0}, {14, 3, 6}, M_FABRIC);
        m.box({0, 3, 4}, {14, 6, 6}, M_FABRIC);
        m.box({0, 3, 0}, {2, 5, 6}, M_FABRIC);
        m.box({12, 3, 0}, {14, 5, 6}, M_FABRIC);
        m.box({0, 0, 0}, {14, 1, 6}, M_DARKWOOD);
        break;
    }
    case PROP_BED: {
        m.resize({10, 5, 16}, FINE);
        m.box({0, 0, 0}, {10, 2, 16}, M_DARKWOOD);
        m.box({0, 2, 0}, {10, 3, 16}, M_FABRIC);
        m.box({0, 0, 15}, {10, 6, 16}, M_DARKWOOD);
        m.box({2, 3, 12}, {8, 4, 15}, M_PLASTER);   // pillow
        m.box({0, 3, 0}, {10, 3, 11}, M_PAINT_BLUE);
        break;
    }
    case PROP_SHELF: {
        m.resize({10, 14, 3}, FINE);
        m.box({0, 0, 0}, {1, 14, 3}, M_METAL);
        m.box({9, 0, 0}, {10, 14, 3}, M_METAL);
        for (int y = 0; y < 14; y += 4) m.box({0, y, 0}, {10, y + 1, 3}, M_METAL);
        m.box({2, 5, 0}, {4, 7, 3}, M_PLANK);   // boxes on shelves
        m.box({6, 9, 0}, {8, 12, 3}, M_PAINT_YELLOW);
        break;
    }
    case PROP_FRIDGE: {
        m.resize({6, 14, 6}, FINE);
        m.box({0, 0, 0}, {6, 14, 6}, M_PLASTER);
        m.box({0, 9, 0}, {6, 10, 1}, M_METAL);
        m.set(5, 11, 0, M_METAL); m.set(5, 6, 0, M_METAL);
        break;
    }
    case PROP_GLASS_PANE: {
        m.resize({12, 12, 1}, FINE);
        m.box({0, 0, 0}, {12, 12, 1}, M_GLASS);
        m.box({0, 0, 0}, {12, 1, 1}, M_METAL);
        break;
    }
    case PROP_CONCRETE_BLOCK: {
        m.resize({4, 4, 8});
        m.box({0, 0, 0}, {4, 4, 8}, M_CONCRETE);
        break;
    }
    case PROP_BRICK_PILE: {
        m.resize({8, 4, 6}, FINE);
        for (int y = 0; y < 4; ++y) m.box({y % 2, y, 0}, {8 - (y % 2), y + 1, 6 - y}, M_BRICK);
        break;
    }
    case PROP_STEEL_BEAM: {   // I-beam 4m long
        m.resize({3, 3, 32}, FINE);
        m.box({0, 0, 0}, {3, 1, 32}, M_STEEL);
        m.box({1, 1, 0}, {2, 2, 32}, M_STEEL);
        m.box({0, 2, 0}, {3, 3, 32}, M_STEEL);
        break;
    }
    case PROP_PLANK: {
        m.resize({2, 1, 20}, FINE);
        m.box({0, 0, 0}, {2, 1, 20}, M_PLANK);
        break;
    }
    case PROP_PALLET: {
        m.resize({10, 2, 10}, FINE);
        for (int x = 0; x < 10; x += 3) m.box({x, 1, 0}, {x + 2, 2, 10}, M_PLANK);
        for (int z : {0, 4, 9}) m.box({0, 0, z}, {10, 1, z + 1}, M_DARKWOOD);
        break;
    }
    case PROP_CONE: {
        m.resize({4, 6, 4}, FINE);
        m.box({0, 0, 0}, {4, 1, 4}, M_PLASTIC);
        m.box({1, 1, 1}, {3, 6, 3}, M_PAINT_RED);
        m.box({1, 3, 1}, {3, 4, 3}, M_PLASTER);
        break;
    }
    case PROP_BENCH: {
        m.resize({14, 6, 4}, FINE);
        for (int lx : {1, 12}) m.box({lx, 0, 0}, {lx + 1, 3, 4}, M_METAL);
        m.box({0, 3, 0}, {14, 4, 3}, M_PLANK);
        m.box({0, 4, 3}, {14, 6, 4}, M_PLANK);
        break;
    }
    case PROP_TRASHCAN: {
        m.resize({4, 6, 4}, FINE);
        m.box({0, 0, 0}, {4, 6, 4}, M_PAINT_GREEN);
        m.box({1, 1, 1}, {3, 6, 3}, M_AIR);
        m.box({0, 5, 0}, {4, 6, 4}, M_PLASTIC);
        break;
    }
    case PROP_WALL_SECTION: {
        m.resize({12, 10, 1});
        m.box({0, 0, 0}, {12, 10, 1}, M_BRICK);
        m.box({4, 3, 0}, {8, 7, 1}, M_GLASS);
        break;
    }
    case PROP_TV: {
        m.resize({8, 6, 4}, FINE);
        m.box({2, 0, 1}, {6, 1, 3}, M_PLASTIC);
        m.box({0, 1, 1}, {8, 6, 3}, M_PLASTIC);
        m.box({1, 2, 0}, {7, 5, 1}, M_GLASS);
        break;
    }
    case PROP_LAMP: {
        m.resize({3, 13, 3}, FINE);
        m.box({0, 0, 0}, {3, 1, 3}, M_METAL);
        m.box({1, 1, 1}, {2, 11, 2}, M_METAL);
        m.box({0, 11, 0}, {3, 13, 3}, M_LIGHT);
        break;
    }
    case PROP_BOOKCASE: {
        m.resize({8, 14, 3}, FINE);
        m.box({0, 0, 0}, {8, 14, 3}, M_DARKWOOD);
        for (int y = 1; y < 13; y += 4) {
            m.box({1, y, 0}, {7, y + 3, 2}, M_AIR);
            for (int x = 1; x < 7; ++x) m.box({x, y, 0}, {x + 1, y + 2 + (x % 2), 2}, (uint8_t)(x % 3 == 0 ? M_PAINT_RED : x % 3 == 1 ? M_PAINT_BLUE : M_FABRIC));
        }
        break;
    }
    case PROP_DESK: {
        m.resize({12, 6, 6}, FINE);
        m.box({0, 5, 0}, {12, 6, 6}, M_WOOD);
        m.box({0, 0, 0}, {4, 5, 6}, M_WOOD);
        m.box({11, 0, 0}, {12, 5, 6}, M_WOOD);
        m.box({4, 0, 5}, {11, 5, 6}, M_WOOD);
        break;
    }
    case PROP_WOOD_TOWER: {   // Jenga style tower (one object, splits under damage)
        m.resize({6, 24, 6}, FINE);
        for (int y = 0; y < 24; ++y) {
            if (y % 2 == 0) { m.box({0, y, 0}, {6, y + 1, 2}, M_PLANK); m.box({0, y, 4}, {6, y + 1, 6}, M_PLANK); }
            else { m.box({0, y, 0}, {2, y + 1, 6}, M_DARKWOOD); m.box({4, y, 0}, {6, y + 1, 6}, M_DARKWOOD); }
        }
        break;
    }
    case PROP_GLASS_TOWER: {
        m.resize({6, 20, 6}, FINE);
        for (int y = 0; y < 20; ++y) {
            bool frame = (y % 5 == 0);
            m.box({0, y, 0}, {6, y + 1, 6}, frame ? M_METAL : M_GLASS);
            if (!frame) m.box({1, y, 1}, {5, y + 1, 5}, M_AIR);
        }
        break;
    }
    case PROP_BIG_BALL: {
        m.resize({8, 8, 8}, FINE);
        for (int z = 0; z < 8; ++z) for (int y = 0; y < 8; ++y) for (int x = 0; x < 8; ++x) {
            vec3 d = vec3(x, y, z) + 0.5f - 4.0f;
            if (glm::length(d) <= 4.0f) m.set(x, y, z, M_STEEL);
        }
        break;
    }
    default:
        m.resize({4, 4, 4}, FINE);
        m.box({0, 0, 0}, {4, 4, 4}, M_PLANK);
    }
    return m;
}
