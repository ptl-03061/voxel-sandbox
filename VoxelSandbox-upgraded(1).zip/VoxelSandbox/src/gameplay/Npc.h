// Crash-test-dummy characters: procedural walk animation on kinematic bodies, physics ragdoll on impact,
// balance stagger for small hits and a blended get-up recovery. Non-graphic: dummies never get injured.
#pragma once
#include "physics/PhysicsWorld.h"
#include "engine/Renderer.h"

#include <Jolt/Physics/Collision/GroupFilterTable.h>
#include <Jolt/Physics/Constraints/Constraint.h>

enum NpcPart { NP_PELVIS, NP_TORSO, NP_HEAD, NP_UARM_L, NP_LARM_L, NP_UARM_R, NP_LARM_R, NP_THIGH_L, NP_SHIN_L, NP_THIGH_R, NP_SHIN_R, NP_COUNT };
enum class NpcState { Idle, Walk, Stagger, Ragdoll, Recover };

struct NpcPose {
    vec3 pos[NP_COUNT];
    quat rot[NP_COUNT];
    vec3 joints[10];
};

class Npc {
public:
    bool create(PhysicsWorld* phys, JPH::GroupFilterTable* filter, int group, const vec3& feet, float yaw, const vec3& shirt);
    void destroy();
    // called once per physics sub-step before PhysicsSystem::Update
    void prePhysics(float dt);
    void update(float dt);   // state machine (per frame)
    void render(Renderer& r);

    void hit(const vec3& point, const vec3& dir, float energy);
    void explosion(const vec3& c, float radius, float power);
    void makeRagdoll(const vec3& impulse, const vec3& at);
    bool ownsBody(JPH::BodyID id) const;
    vec3 center() const;

    NpcState state = NpcState::Idle;
    vec3 home{0};
    float wanderRadius = 12.0f;
    int knockdowns = 0;
    PhysTag tag;

private:
    void computePose(NpcPose& out, const vec3& root, float yaw, float walkAmt, float phase, float crouch, float lean, float armsUp) const;
    void driveKinematic(const NpcPose& p, float dt);
    void setMotion(bool dynamic);
    bool groundHeight(const vec3& at, float& y) const;
    void pickTarget();

    PhysicsWorld* mPhys = nullptr;
    JPH::BodyID mBodies[NP_COUNT];
    JPH::Ref<JPH::Constraint> mJoints[10];
    vec3 mShirt{0.2f, 0.4f, 0.8f};
    float mRadius[NP_COUNT], mHalf[NP_COUNT];

    vec3 mRoot{0};
    float mYaw = 0;
    vec3 mTarget{0};
    float mPhase = 0, mWalkAmt = 0, mStateTime = 0, mIdleTime = 0, mRest = 0;
    float mStaggerLean = 0;
    vec3 mStaggerVel{0};
    NpcPose mFrom;       // captured ragdoll pose for get-up blending
    float mCooldown = 0;
    bool mDynamic = false;
    bool mValid = false;
};

class NpcManager {
public:
    void init(PhysicsWorld* phys);
    void clear();
    Npc* spawn(const vec3& feet, float yaw);
    void prePhysics(float dt) { for (auto& n : mNpcs) n->prePhysics(dt); }
    void update(float dt) { for (auto& n : mNpcs) n->update(dt); }
    void render(Renderer& r, const vec3& cam, float dist);
    void explosion(const vec3& c, float radius, float power) { for (auto& n : mNpcs) n->explosion(c, radius, power); }
    void remove(Npc* n);
    std::vector<std::unique_ptr<Npc>>& npcs() { return mNpcs; }
    int ragdollCount() const;
private:
    PhysicsWorld* mPhys = nullptr;
    JPH::Ref<JPH::GroupFilterTable> mFilter;
    std::vector<std::unique_ptr<Npc>> mNpcs;
    int mNextGroup = 1;
};
