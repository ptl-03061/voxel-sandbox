#include "gameplay/Sandbox.h"
#include "engine/Audio.h"

#include <Jolt/Physics/Body/BodyLock.h>
#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Collision/Shape/SphereShape.h>
#include <glm/gtx/quaternion.hpp>

using namespace JPH;

const char* ToolName(int t) {
    static const char* n[TOOL_COUNT] = {"Physics Hand", "Sledgehammer", "Cannon", "Bomb", "Rocket", "Spawner",
                                        "Rope", "Cut Rope", "Freeze", "Weld"};
    return n[glm::clamp(t, 0, TOOL_COUNT - 1)];
}

void Sandbox::init(PhysicsWorld* phys, ObjectManager* objs, Destruction* destr, VehicleManager* veh, NpcManager* npcs, Particles* parts) {
    mPhys = phys; mObjs = objs; mDestr = destr; mVeh = veh; mNpcs = npcs; mParts = parts;
    catalog.clear();
    for (int i = 0; i < PROP_COUNT; ++i) catalog.push_back({GetPropDef(i).name, GetPropDef(i).category, SpawnKind::Prop, i});
    for (int i = 0; i < VEH_COUNT; ++i) catalog.push_back({VehicleName(i), "Vehicles", SpawnKind::Vehicle, i});
    catalog.push_back({"Crash Dummy", "Characters", SpawnKind::Npc, 0});
    catalog.push_back({"Timed Bomb", "Explosives", SpawnKind::Bomb, 0});
    categories = {"Furniture", "Construction", "Physics", "Vehicles", "Characters", "Explosives"};
}

void Sandbox::clear() {
    release();
    for (auto& p : mProjectiles) if (!p->body.IsInvalid()) { mPhys->bi().RemoveBody(p->body); mPhys->bi().DestroyBody(p->body); }
    mProjectiles.clear();
}

bool Sandbox::aim(const vec3& eye, const vec3& dir, float maxDist, RayHit& hit) {
    return mPhys->raycast(eye, dir, maxDist, hit, ignoreBody);
}

// ---------------------------------------------------------------- hand
void Sandbox::release() {
    if (!mHeld.IsInvalid() && mPhys->bi().IsAdded(mHeld)) mPhys->bi().SetAngularVelocity(mHeld, mPhys->bi().GetAngularVelocity(mHeld) * 0.3f);
    mHeld = BodyID();
}

bool Sandbox::grabToggle(const vec3& eye, const vec3& dir) {
    if (holding()) { release(); GAudio().play2D(SND_UI_BACK, 0.4f); return false; }
    RayHit h;
    if (!aim(eye, dir, 14.0f, h)) return false;
    BodyInterface& bi = mPhys->bi();
    PhysTag* t = h.tag;
    if (!t || t->type == TagType::WorldChunk || t->type == TagType::Platform) return false;
    if (t->type == TagType::RagdollPart) {
        Npc* n = (Npc*)t->ptr;
        if (n->state != NpcState::Ragdoll) n->makeRagdoll(vec3(0, 1, 0), h.point);
    }
    if (t->type == TagType::VoxelObject) {
        VoxelObject* o = (VoxelObject*)t->ptr;
        if (o->flags & OBJ_KINEMATIC) { o->flags &= ~OBJ_KINEMATIC; bi.SetMotionType(o->body, EMotionType::Dynamic, EActivation::Activate); }
    }
    if (bi.GetMotionType(h.body) != EMotionType::Dynamic) return false;
    mHeld = h.body;
    RMat44 T = bi.GetWorldTransform(mHeld);
    mGrabLocal = ToG(Vec3(T.InversedRotationTranslation() * RVec3(h.point.x, h.point.y, h.point.z)));
    mHoldDist = glm::clamp(h.dist, 1.5f, 10.0f);
    quat camYaw = glm::angleAxis(std::atan2(dir.x, dir.z), vec3(0, 1, 0));
    mRelRot = glm::inverse(camYaw) * ToG(T.GetQuaternion());
    bi.ActivateBody(mHeld);
    GAudio().play2D(SND_UI_CLICK, 0.5f, 1.3f);
    return true;
}

void Sandbox::throwHeld(const vec3& dir) {
    if (!holding()) return;
    BodyInterface& bi = mPhys->bi();
    float m = mPhys->massOf(mHeld);
    float speed = 6.0f + 26.0f * std::min(1.0f, std::sqrt(150.0f / std::max(m, 1.0f)));
    bi.SetLinearVelocity(mHeld, ToJ(dir * speed));
    bi.SetAngularVelocity(mHeld, ToJ(GRng().unitVec() * 2.0f));
    GAudio().play(SND_THROW, ToG(Vec3(bi.GetPosition(mHeld))), 0.7f, 1.0f);
    mHeld = BodyID();
}

void Sandbox::rotateHeld(float dx, float dy) {
    if (!holding()) return;
    mRelRot = glm::angleAxis(dx, vec3(0, 1, 0)) * glm::angleAxis(dy, vec3(1, 0, 0)) * mRelRot;
    mRelRot = glm::normalize(mRelRot);
}

void Sandbox::scaleTarget(const vec3& eye, const vec3& dir, float factor) {
    BodyID id = mHeld;
    if (id.IsInvalid()) { RayHit h; if (aim(eye, dir, 14.0f, h)) id = h.body; }
    PhysTag* t = mPhys->tagOf(id);
    if (!t || t->type != TagType::VoxelObject) return;
    VoxelObject* o = (VoxelObject*)t->ptr;
    if (o->flags & OBJ_DOOR) return;
    mObjs->setScale(o, o->scale * factor);
    GAudio().play2D(SND_UI_CLICK, 0.5f, factor > 1 ? 1.2f : 0.8f);
}

void Sandbox::duplicateTarget(const vec3& eye, const vec3& dir) {
    RayHit h;
    BodyID id = mHeld;
    if (id.IsInvalid() && aim(eye, dir, 14.0f, h)) id = h.body;
    PhysTag* t = mPhys->tagOf(id);
    if (!t) return;
    if (t->type == TagType::VoxelObject) {
        VoxelObject* o = (VoxelObject*)t->ptr;
        float up = o->model.sizeMeters().y * o->scale + 0.1f;
        if (mObjs->duplicate(o, vec3(0, up, 0))) GAudio().play(SND_SPAWN, eye + dir * 2.0f, 0.6f);
    } else if (t->type == TagType::Vehicle) {
        Vehicle* v = (Vehicle*)t->ptr;
        mVeh->spawn(v->type, v->position() + vec3(0, 3.5f, 0), std::atan2((v->rotation() * vec3(0, 0, 1)).x, (v->rotation() * vec3(0, 0, 1)).z));
        GAudio().play(SND_SPAWN, eye + dir * 2.0f, 0.6f);
    } else if (t->type == TagType::RagdollPart) {
        Npc* n = (Npc*)t->ptr;
        mNpcs->spawn(n->center() + vec3(1.0f, 0.5f, 0), 0);
    }
}

void Sandbox::deleteTarget(const vec3& eye, const vec3& dir) {
    RayHit h;
    BodyID id = mHeld;
    if (id.IsInvalid() && aim(eye, dir, 20.0f, h)) id = h.body;
    PhysTag* t = mPhys->tagOf(id);
    if (!t) return;
    if (id == mHeld) mHeld = BodyID();
    if (t->type == TagType::VoxelObject) mObjs->destroy((VoxelObject*)t->ptr);
    else if (t->type == TagType::Vehicle) mVeh->remove((Vehicle*)t->ptr);
    else if (t->type == TagType::RagdollPart) mNpcs->remove((Npc*)t->ptr);
    else if (t->type == TagType::Projectile) ((Projectile*)t->ptr)->dead = true;
    else return;
    GAudio().play2D(SND_UI_BACK, 0.6f, 0.7f);
}

void Sandbox::freezeTarget(const vec3& eye, const vec3& dir) {
    BodyID id = mHeld;
    RayHit h;
    if (id.IsInvalid() && aim(eye, dir, 14.0f, h)) id = h.body;
    PhysTag* t = mPhys->tagOf(id);
    if (!t || t->type != TagType::VoxelObject) return;
    VoxelObject* o = (VoxelObject*)t->ptr;
    if (o->flags & OBJ_DOOR) return;
    BodyInterface& bi = mPhys->bi();
    if (o->flags & OBJ_KINEMATIC) {
        o->flags &= ~OBJ_KINEMATIC;
        bi.SetMotionType(o->body, EMotionType::Dynamic, EActivation::Activate);
    } else {
        o->flags |= OBJ_KINEMATIC;
        o->flags &= ~OBJ_DEBRIS;
        if (id == mHeld) mHeld = BodyID();
        bi.SetMotionType(o->body, EMotionType::Kinematic, EActivation::DontActivate);
        bi.SetLinearAndAngularVelocity(o->body, Vec3::sZero(), Vec3::sZero());
    }
    GAudio().play2D(SND_SWITCH, 0.5f, 1.4f);
}

// ---------------------------------------------------------------- primary fire
void Sandbox::useTool(const vec3& eye, const vec3& dir) {
    switch (tool) {
    case TOOL_HAND:
        grabToggle(eye, dir);
        break;
    case TOOL_HAMMER: {
        if (mCooldown > 0) return;
        mCooldown = 0.38f;
        GAudio().play(SND_SWING, eye, 0.5f, GRng().range(0.9f, 1.1f));
        RayHit h;
        if (aim(eye, dir, 3.0f, h)) {
            if (h.tag && h.tag->type == TagType::RagdollPart) {
                ((Npc*)h.tag->ptr)->makeRagdoll(dir * 7.0f + vec3(0, 2.0f, 0), h.point);
            } else {
                int n = mDestr->damageAt(h.point - h.normal * 0.05f, 0.42f, 0.75f, dir * 3.0f);
                if (n == 0) mDestr->playImpactSound(mDestr->materialNear(h.point - h.normal * 0.05f, h.tag), h.point, 0.6f, false);
                if (mPhys->bi().GetMotionType(h.body) == EMotionType::Dynamic)
                    mPhys->bi().AddImpulse(h.body, ToJ(dir * 600.0f), RVec3(h.point.x, h.point.y, h.point.z));
            }
        }
        break;
    }
    case TOOL_CANNON:
        if (mCooldown > 0) return;
        mCooldown = 0.45f;
        fireProjectile(0, eye, dir);
        break;
    case TOOL_BOMB:
        if (mCooldown > 0) return;
        mCooldown = 0.6f;
        fireProjectile(1, eye, dir);
        break;
    case TOOL_ROCKET:
        if (mCooldown > 0) return;
        mCooldown = 0.9f;
        fireProjectile(2, eye, dir);
        break;
    case TOOL_SPAWN:
        if (mCooldown > 0) return;
        mCooldown = 0.3f;
        spawnSelected(eye, dir);
        break;
    case TOOL_ROPE: {
        if (mCooldown > 0 || !mConstraints) return;
        mCooldown = 0.3f;
        RayHit h;
        if (aim(eye, dir, 24.0f, h)) {
            JPH::BodyID attach;
            if (h.tag && mPhys->bi().GetMotionType(h.body) == JPH::EMotionType::Dynamic) attach = h.body;
            mConstraints->createRope(eye + dir * 1.2f, h.point, LinkStyle::Rope, attach, JPH::BodyID(), 0.05f, 6000.0f);
        }
        break;
    }
    case TOOL_UNROPE:
        if (mCooldown > 0 || !mConstraints) return;
        mCooldown = 0.2f;
        { RayHit h; if (aim(eye, dir, 20.0f, h)) mConstraints->breakRopesNear(h.point, 0.8f); }
        break;
    case TOOL_FREEZE: {
        if (mCooldown > 0) return;
        mCooldown = 0.25f;
        RayHit h;
        if (aim(eye, dir, 24.0f, h) && h.tag && h.tag->type == TagType::VoxelObject) {
            auto* o = (VoxelObject*)h.tag->ptr;
            if (o->flags & OBJ_KINEMATIC) { o->flags &= ~OBJ_KINEMATIC; mPhys->bi().SetMotionType(o->body, JPH::EMotionType::Dynamic, JPH::EActivation::Activate); }
            else { o->flags |= OBJ_KINEMATIC; o->flags &= ~OBJ_DEBRIS; mPhys->bi().SetMotionType(o->body, JPH::EMotionType::Kinematic, JPH::EActivation::DontActivate); }
        }
        break;
    }
    case TOOL_WELD: {
        if (mCooldown > 0 || !mConstraints) return;
        mCooldown = 0.25f;
        RayHit h;
        if (aim(eye, dir, 20.0f, h) && h.tag && h.tag->type == TagType::VoxelObject) {
            if (mWeldA.IsInvalid()) mWeldA = h.body;
            else if (h.body != mWeldA) { mConstraints->createJoint(mWeldA, h.body, h.point, false, vec3(0), 40000.0f); mWeldA = JPH::BodyID(); }
        }
        break;
    }
    }
}

void Sandbox::fireProjectile(int type, const vec3& eye, const vec3& dir) {
    int alive = 0;
    for (auto& p : mProjectiles) alive += p->type == type;
    if (alive >= 30) {   // recycle the oldest of this type
        for (auto& p : mProjectiles) if (p->type == type && !p->dead) { p->dead = true; break; }
    }
    auto p = std::make_unique<Projectile>();
    p->type = type;
    p->tag.type = TagType::Projectile;
    p->tag.ptr = p.get();
    p->tag.index = type;
    vec3 start = eye + dir * 0.8f;
    RefConst<Shape> shape;
    float mass, speed;
    if (type == 0) { shape = new SphereShape(0.2f); mass = 30.0f; speed = 48.0f; p->life = 14.0f; }
    else if (type == 1) { shape = new SphereShape(0.22f); mass = 8.0f; speed = 13.0f; p->life = 30.0f; p->fuse = 3.0f; }
    else { shape = new CapsuleShape(0.25f, 0.1f); mass = 12.0f; speed = 34.0f; p->life = 6.0f; }
    quat rot = type == 2 ? glm::rotation(vec3(0, 1, 0), dir) : quat(1, 0, 0, 0);
    BodyCreationSettings bs(shape, RVec3(start.x, start.y, start.z), ToJ(rot), EMotionType::Dynamic, Layers::MOVING);
    bs.mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
    bs.mMassPropertiesOverride.mMass = mass;
    bs.mMotionQuality = EMotionQuality::LinearCast;
    bs.mLinearVelocity = ToJ(dir * speed + (type == 1 ? vec3(0, 3.0f, 0) : vec3(0)));
    bs.mRestitution = type == 1 ? 0.35f : 0.15f;
    bs.mFriction = 0.6f;
    bs.mGravityFactor = type == 2 ? 0.05f : 1.0f;
    bs.mUserData = (uint64_t)(uintptr_t)&p->tag;
    p->body = mPhys->bi().CreateAndAddBody(bs, EActivation::Activate);
    if (p->body.IsInvalid()) return;
    GAudio().play(type == 0 ? SND_CANNON : SND_THROW, eye, type == 0 ? 0.9f : 0.6f, type == 2 ? 0.6f : 1.0f);
    if (type == 0) for (int i = 0; i < 8; ++i) mParts->spawn(PType::Smoke, start, dir * 3.0f + GRng().unitVec(), vec4(0.7f, 0.7f, 0.7f, 0.4f), 0.4f, 1.2f);
    mProjectiles.push_back(std::move(p));
}

void Sandbox::spawnSelected(const vec3& eye, const vec3& dir) {
    RayHit h;
    vec3 pos = aim(eye, dir, 30.0f, h) ? h.point + h.normal * 0.15f : eye + dir * 5.0f;
    spawnItem(spawnIndex, pos, std::atan2(dir.x, dir.z));
}

void Sandbox::spawnItem(int index, const vec3& pos, float yaw) {
    if (index < 0 || index >= (int)catalog.size()) return;
    const SpawnItem& it = catalog[index];
    quat rot = glm::angleAxis(yaw, vec3(0, 1, 0));
    switch (it.kind) {
    case SpawnKind::Prop: {
        VoxelModel m = BuildProp(it.id);
        vec3 size = m.sizeMeters();
        vec3 p = pos + vec3(0, 0.05f, 0) - rot * vec3(size.x * 0.5f, 0, size.z * 0.5f);
        mObjs->create(std::move(m), p, rot, OBJ_PROP, vec3(0), vec3(0), 1.0f, it.name);
        break;
    }
    case SpawnKind::Vehicle: mVeh->spawn((VehicleType)it.id, pos + vec3(0, 1.8f, 0), yaw); break;
    case SpawnKind::Npc: mNpcs->spawn(pos + vec3(0, 0.05f, 0), yaw + 3.14159f); break;
    case SpawnKind::Bomb: {
        auto p = std::make_unique<Projectile>();
        p->type = 1; p->tag.type = TagType::Projectile; p->tag.ptr = p.get(); p->tag.index = 1;
        p->life = 30.0f; p->fuse = 5.0f;
        BodyCreationSettings bs(new SphereShape(0.22f), RVec3(pos.x, pos.y + 0.3f, pos.z), Quat::sIdentity(), EMotionType::Dynamic, Layers::MOVING);
        bs.mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
        bs.mMassPropertiesOverride.mMass = 8.0f;
        bs.mUserData = (uint64_t)(uintptr_t)&p->tag;
        p->body = mPhys->bi().CreateAndAddBody(bs, EActivation::Activate);
        mProjectiles.push_back(std::move(p));
        break;
    }
    }
    GAudio().play(SND_SPAWN, pos, 0.6f, 1.0f);
}

// ---------------------------------------------------------------- update
void Sandbox::prePhysics(float dt, const vec3& eye, const vec3& dir, float camYaw) {
    mCooldown = std::max(0.0f, mCooldown - dt);
    if (!holding()) return;
    BodyInterface& bi = mPhys->bi();
    if (!bi.IsAdded(mHeld) || bi.GetMotionType(mHeld) != EMotionType::Dynamic) { mHeld = BodyID(); return; }
    RMat44 T = bi.GetWorldTransform(mHeld);
    vec3 grabW = ToG(Vec3(T * RVec3(mGrabLocal.x, mGrabLocal.y, mGrabLocal.z)));
    vec3 target = eye + dir * mHoldDist;
    mHoldTarget = target;
    mBeamFrom = eye + vec3(0, -0.25f, 0) + glm::cross(dir, vec3(0, 1, 0)) * -0.25f;
    float m = mPhys->massOf(mHeld);
    float gain = 14.0f * std::min(1.0f, std::sqrt(4000.0f / std::max(m, 1.0f)));
    vec3 v = (target - grabW) * gain;
    float maxV = 30.0f;
    if (glm::length(v) > maxV) v = glm::normalize(v) * maxV;
    // break the grip if the object is stuck far away from the hand
    if (glm::distance(target, grabW) > 6.0f) { release(); return; }
    quat qT = glm::angleAxis(camYaw, vec3(0, 1, 0)) * mRelRot;
    quat q = ToG(T.GetQuaternion());
    quat dq = qT * glm::inverse(q);
    if (dq.w < 0) dq = -dq;
    float angle = 2.0f * std::acos(glm::clamp(dq.w, -1.0f, 1.0f));
    vec3 axis = std::fabs(angle) > 1e-4f ? vec3(dq.x, dq.y, dq.z) / std::sin(angle * 0.5f) : vec3(0);
    vec3 w = axis * angle * 9.0f * std::min(1.0f, std::sqrt(2000.0f / std::max(m, 1.0f)));
    if (glm::length(w) > 14.0f) w = glm::normalize(w) * 14.0f;
    bi.SetLinearAndAngularVelocity(mHeld, ToJ(v), ToJ(w));
}

void Sandbox::onContact(PhysTag* a, PhysTag* b) {
    for (PhysTag* t : {a, b})
        if (t && t->type == TagType::Projectile && t->index == 2) ((Projectile*)t->ptr)->explode = true;
}

void Sandbox::update(float dt) {
    BodyInterface& bi = mPhys->bi();
    for (auto& up : mProjectiles) {
        Projectile* p = up.get();
        if (p->dead) continue;
        p->life -= dt;
        vec3 pos = ToG(Vec3(bi.GetPosition(p->body)));
        if (p->type == 1) {
            p->fuse -= dt;
            if (p->fuse <= 0) p->explode = true;
        } else if (p->type == 2) {
            vec3 v = ToG(bi.GetLinearVelocity(p->body));
            mParts->spawn(PType::Smoke, pos - glm::normalize(v + vec3(1e-4f)) * 0.4f, GRng().unitVec() * 0.3f, vec4(0.75f, 0.75f, 0.75f, 0.45f), 0.35f, 1.6f);
            mParts->spawn(PType::Fire, pos - glm::normalize(v + vec3(1e-4f)) * 0.35f, -v * 0.05f, vec4(1.0f, 0.6f, 0.2f, 0.9f), 0.25f, 0.12f);
            if (p->life <= 0) p->explode = true;
        }
        if (p->explode) {
            if (p->type == 1) mDestr->explode(pos, 2.4f, 1.6f);
            else if (p->type == 2) mDestr->explode(pos, 1.9f, 1.3f);
            p->dead = true;
        } else if (p->life <= 0 || pos.y < -20.0f) p->dead = true;
    }
    for (auto& p : mProjectiles)
        if (p->dead && !p->body.IsInvalid()) {
            if (p->body == mHeld) mHeld = BodyID();
            bi.RemoveBody(p->body); bi.DestroyBody(p->body); p->body = BodyID();
        }
    mProjectiles.erase(std::remove_if(mProjectiles.begin(), mProjectiles.end(), [](const std::unique_ptr<Projectile>& p) { return p->dead; }), mProjectiles.end());
}

void Sandbox::render(Renderer& r) {
    BodyInterface& bi = mPhys->bi();
    for (auto& p : mProjectiles) {
        RVec3 pp; Quat q;
        bi.GetPositionAndRotation(p->body, pp, q);
        vec3 pos = ToG(Vec3(pp));
        mat4 rot = glm::mat4_cast(ToG(q));
        if (p->type == 0) r.drawInstance(MESH_SPHERE, glm::translate(mat4(1), pos) * glm::scale(mat4(1), vec3(0.4f)), vec4(0.12f, 0.12f, 0.13f, 1), vec4(0.35f, 1.0f, 0, 0));
        else if (p->type == 1) {
            bool blink = std::fmod(p->fuse, p->fuse < 1.0f ? 0.15f : 0.5f) < 0.07f;
            r.drawInstance(MESH_SPHERE, glm::translate(mat4(1), pos) * rot * glm::scale(mat4(1), vec3(0.44f)), vec4(0.08f, 0.08f, 0.09f, 1), vec4(0.5f, 0.2f, 0, 0));
            r.drawInstance(MESH_CUBE, glm::translate(mat4(1), pos) * rot * glm::translate(mat4(1), vec3(0, 0.22f, 0)) * glm::scale(mat4(1), vec3(0.08f)),
                           blink ? vec4(1.0f, 0.1f, 0.05f, 1) : vec4(0.3f, 0.05f, 0.05f, 1), vec4(0.4f, 0, blink ? 6.0f : 0.0f, 0));
            if (blink) r.addLight({pos + vec3(0, 0.3f, 0), 3.0f, vec3(1.0f, 0.1f, 0.05f) * 1.5f});
        } else {
            vec3 ax = ToG(q) * vec3(0, 0.25f, 0);
            r.drawCapsule(pos - ax, pos + ax, 0.1f, vec4(0.85f, 0.85f, 0.8f, 1), vec4(0.3f, 0.6f, 0, 0));
            r.drawInstance(MESH_CONE, glm::translate(mat4(1), pos + ax * 1.6f) * rot * glm::scale(mat4(1), vec3(0.2f, 0.2f, 0.2f)), vec4(0.85f, 0.1f, 0.05f, 1), vec4(0.4f, 0.2f, 0, 0));
            r.addLight({pos - ax * 2.0f, 5.0f, vec3(1.0f, 0.6f, 0.25f) * 2.0f});
        }
    }
    if (holding()) {
        // energy beam from the hand to the grabbed point
        RMat44 T = bi.GetWorldTransform(mHeld);
        vec3 grabW = ToG(Vec3(T * RVec3(mGrabLocal.x, mGrabLocal.y, mGrabLocal.z)));
        for (int i = 0; i <= 10; ++i) {
            float t = i / 10.0f;
            vec3 p = glm::mix(mBeamFrom, grabW, t);
            r.drawParticle(p, 0.06f + 0.03f * std::sin(t * 20.0f), vec4(0.3f, 0.7f, 1.0f, 0.7f), 0, 0, true);
        }
        r.drawParticle(grabW, 0.25f, vec4(0.4f, 0.8f, 1.0f, 0.8f), 0, 0, true);
    }
}

std::string Sandbox::targetInfo(const vec3& eye, const vec3& dir) {
    RayHit h;
    if (!aim(eye, dir, 14.0f, h) || !h.tag) return "";
    char buf[128];
    switch (h.tag->type) {
    case TagType::VoxelObject: {
        VoxelObject* o = (VoxelObject*)h.tag->ptr;
        snprintf(buf, sizeof(buf), "%s  %.0f kg%s", o->name.empty() ? "Debris" : o->name.c_str(), o->mass, (o->flags & OBJ_KINEMATIC) ? "  [frozen]" : "");
        return buf;
    }
    case TagType::Vehicle: {
        Vehicle* v = (Vehicle*)h.tag->ptr;
        snprintf(buf, sizeof(buf), "%s  %.0f%% %s", VehicleName(v->type), v->health, h.dist < 5.0f ? " - tap ENTER" : "");
        return buf;
    }
    case TagType::RagdollPart: return "Crash Dummy";
    case TagType::WorldChunk: {
        vec3 p = h.point - h.normal * 0.05f;
        return MatInfo(mDestr->materialNear(p, h.tag)).name;
    }
    default: return "";
    }
}
