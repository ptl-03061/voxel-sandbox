#include "gameplay/Machinery.h"
#include "destruction/Destruction.h"
#include "engine/Renderer.h"
#include "engine/Audio.h"

#include <Jolt/Physics/Body/BodyCreationSettings.h>
#include <Jolt/Physics/Collision/Shape/BoxShape.h>

using namespace JPH;

void Machinery::init(PhysicsWorld* p, ObjectManager* o, Destruction* d) { mPhys = p; mObjs = o; mDestr = d; }
void Machinery::clear() { mNodes.clear(); mMachines.clear(); mGridDirty = true; }

BodyID Machinery::makeBox(const vec3& pos, const vec3& half) {
    BodyCreationSettings bcs(new BoxShape(Vec3(half.x, half.y, half.z)), RVec3(pos.x, pos.y, pos.z),
                             Quat::sIdentity(), EMotionType::Kinematic, Layers::KINEMATIC);
    return mPhys->bi().CreateAndAddBody(bcs, EActivation::Activate);
}

int Machinery::addGenerator(const vec3& pos, float cap) {
    PowerNode n; n.id = mNextId++; n.kind = PowerKind::Generator; n.pos = pos; n.capacity = cap;
    n.body = makeBox(pos + vec3(0, 0.4f, 0), vec3(0.45f, 0.4f, 0.45f));
    mNodes.push_back(n); mGridDirty = true; return (int)mNodes.size() - 1;
}
int Machinery::addBattery(const vec3& pos, float cap) {
    PowerNode n; n.id = mNextId++; n.kind = PowerKind::Battery; n.pos = pos; n.capacity = cap; n.charge = 1.0f;
    n.body = makeBox(pos + vec3(0, 0.25f, 0), vec3(0.3f, 0.25f, 0.3f));
    mNodes.push_back(n); mGridDirty = true; return (int)mNodes.size() - 1;
}
int Machinery::addBreaker(const vec3& pos) {
    PowerNode n; n.id = mNextId++; n.kind = PowerKind::Breaker; n.pos = pos;
    n.body = makeBox(pos + vec3(0, 0.35f, 0), vec3(0.15f, 0.35f, 0.12f));
    mNodes.push_back(n); mGridDirty = true; return (int)mNodes.size() - 1;
}
int Machinery::addPanel(const vec3& pos) {
    PowerNode n; n.id = mNextId++; n.kind = PowerKind::Panel; n.pos = pos;
    n.body = makeBox(pos + vec3(0, 0.7f, 0), vec3(0.25f, 0.5f, 0.08f));
    mNodes.push_back(n); mGridDirty = true; return (int)mNodes.size() - 1;
}

int Machinery::addConveyor(const vec3& pos, float yaw, float length) {
    Machine m; m.id = mNextId++; m.kind = MachineKind::Conveyor; m.name = "Conveyor";
    m.basePos = pos + vec3(0, 0.25f, 0); m.half = vec3(length * 0.5f, 0.12f, 0.45f); m.yaw = yaw;
    m.body = makeBox(m.basePos, m.half);
    m.beltDir = vec3(std::cos(yaw), 0, std::sin(yaw));
    mMachines.push_back(m); return m.id;
}
int Machinery::addLift(const vec3& pos, float travel, float halfXZ) {
    Machine m; m.id = mNextId++; m.kind = MachineKind::Lift; m.name = "Hydraulic lift";
    m.basePos = pos + vec3(0, 0.15f, 0); m.half = vec3(halfXZ, 0.15f, halfXZ);
    m.body = makeBox(m.basePos, m.half);
    m.targetOffset = vec3(0, travel, 0); m.speed = 0.5f;
    mMachines.push_back(m); return m.id;
}
int Machinery::addFan(const vec3& pos, float yaw, float pitch) {
    Machine m; m.id = mNextId++; m.kind = MachineKind::Fan; m.name = "Fan";
    m.basePos = pos + vec3(0, 0.6f, 0); m.half = vec3(0.4f, 0.4f, 0.3f); m.yaw = yaw;
    m.body = makeBox(m.basePos, m.half);
    mat3 ry = glm::rotate(mat4(1), yaw, vec3(0, 1, 0));
    mat3 rx = glm::rotate(mat4(1), pitch, vec3(1, 0, 0));
    m.beltDir = ry * rx * vec3(0, 0, 1);
    mMachines.push_back(m); return m.id;
}
int Machinery::addPress(const vec3& pos) {
    Machine m; m.id = mNextId++; m.kind = MachineKind::Press; m.name = "Press";
    m.basePos = pos + vec3(0, 2.2f, 0); m.half = vec3(0.9f, 0.35f, 0.9f);
    m.body = makeBox(m.basePos, m.half);
    m.targetOffset = vec3(0, -1.6f, 0); m.speed = 0.8f;
    mMachines.push_back(m); return m.id;
}
int Machinery::addPoweredDoor(const vec3& pos, float yaw, const vec3& half, float openDist) {
    Machine m; m.id = mNextId++; m.kind = MachineKind::PoweredDoor; m.name = "Powered door";
    m.basePos = pos; m.half = half; m.yaw = yaw;
    m.body = makeBox(pos, half);
    m.targetOffset = glm::rotate(vec3(openDist, 0, 0), yaw, vec3(0, 1, 0));
    m.speed = 1.4f;
    mMachines.push_back(m); return m.id;
}

void Machinery::toggleBreaker(int node) {
    if (node < 0 || node >= (int)mNodes.size()) return;
    if (mNodes[node].kind != PowerKind::Breaker) return;
    mNodes[node].on = !mNodes[node].on;
    GAudio().play(SND_METAL_HIT, mNodes[node].pos, 0.5f, 1.4f);
    mGridDirty = true;
}
void Machinery::setNodeOn(int node, bool on) {
    if (node < 0 || node >= (int)mNodes.size()) return;
    mNodes[node].on = on; mGridDirty = true;
}

void Machinery::recomputePower() {
    for (auto& n : mNodes) {
        n.powered = false;
        if ((n.kind == PowerKind::Generator || n.kind == PowerKind::Battery) && n.on)
            n.powered = n.kind == PowerKind::Generator || n.charge > 0.02f;
    }
    for (auto& m : mMachines) {
        m.powered = false;
        bool anySource = false, breakerOpen = false;
        for (auto& n : mNodes) {
            if (glm::distance2(n.pos, m.basePos) > n.radius * n.radius) continue;
            if (n.kind == PowerKind::Breaker && !n.on) breakerOpen = true;
            if ((n.kind == PowerKind::Generator || n.kind == PowerKind::Battery) && n.on &&
                (n.kind == PowerKind::Generator || n.charge > 0.02f)) anySource = true;
        }
        m.powered = anySource && !breakerOpen;
    }
    for (auto& n : mNodes) {
        if (n.kind != PowerKind::Panel) continue;
        bool anySource = false, breakerOpen = false;
        for (auto& src : mNodes) {
            if (glm::distance2(src.pos, n.pos) > src.radius * src.radius) continue;
            if (src.kind == PowerKind::Breaker && !src.on) breakerOpen = true;
            if ((src.kind == PowerKind::Generator || src.kind == PowerKind::Battery) && src.on &&
                (src.kind == PowerKind::Generator || src.charge > 0.02f)) anySource = true;
        }
        n.powered = anySource && !breakerOpen;
    }
    mGridDirty = false;
}

void Machinery::prePhysics(float dt) {
    if (mGridDirty) recomputePower();
    BodyInterface& bi = mPhys->bi();
    for (auto& m : mMachines) {
        bool want = m.powered;
        switch (m.kind) {
        case MachineKind::Conveyor:
            bi.SetLinearVelocity(m.body, want ? ToJ(m.beltDir * m.beltSpeed) : Vec3::sZero());
            break;
        case MachineKind::Lift:
        case MachineKind::PoweredDoor: {
            float target = want ? 1.0f : 0.0f;
            m.t = MoveTowards(m.t, target, dt * m.speed);
            vec3 off = m.targetOffset * m.t;
            bi.SetPositionAndRotation(m.body, RVec3(m.basePos.x + off.x, m.basePos.y + off.y, m.basePos.z + off.z),
                                      ToJ(glm::angleAxis(m.yaw, vec3(0, 1, 0))), EActivation::Activate);
            break;
        }
        case MachineKind::Press: {
            float target = want ? 1.0f : 0.0f;
            float prev = m.t;
            m.t = MoveTowards(m.t, target, dt * m.speed);
            if (want && m.t > 0.4f && prev <= 0.4f && m.cooldown <= 0) {
                vec3 crush = m.basePos + m.targetOffset * m.t;
                if (mDestr) mDestr->damageAt(crush, m.half.x * 1.2f, m.pressDamage, vec3(0, -2, 0), true, m.body);
                GAudio().play(SND_METAL_HEAVY, crush, 0.9f, 0.7f);
                m.cooldown = 1.2f;
            }
            vec3 off = m.targetOffset * m.t;
            bi.SetPositionAndRotation(m.body, RVec3(m.basePos.x + off.x, m.basePos.y + off.y, m.basePos.z + off.z),
                                      ToJ(glm::angleAxis(m.yaw, vec3(0, 1, 0))), EActivation::Activate);
            break;
        }
        case MachineKind::Fan: {
            if (want) {
                m.phase += dt * 20.0f;
                std::vector<BodyID> bodies;
                vec3 c = m.basePos + m.beltDir * m.fanRadius * 0.5f;
                mPhys->bodiesInSphere(c, m.fanRadius, bodies);
                for (auto id : bodies) {
                    if (bi.GetMotionType(id) != EMotionType::Dynamic) continue;
                    float mass = mPhys->massOf(id);
                    if (mass > 1e7f) continue;
                    vec3 p = ToG(bi.GetPosition(id));
                    float along = glm::dot(p - m.basePos, m.beltDir);
                    if (along < 0 || along > m.fanRadius) continue;
                    float fall = 1.0f - along / m.fanRadius;
                    bi.AddForce(id, ToJ(m.beltDir * m.fanForce * fall * std::min(mass, 300.0f) * 0.05f));
                }
            }
            break;
        }
        }
        m.cooldown -= dt;
    }
    for (auto& n : mNodes)
        if (n.kind == PowerKind::Battery && n.powered) n.charge = std::max(0.0f, n.charge - dt * 0.01f);
}

void Machinery::update(float dt) { (void)dt; }

void Machinery::onExplosion(const vec3& c, float radius) {
    for (auto& n : mNodes)
        if (n.kind == PowerKind::Breaker && glm::distance2(n.pos, c) < radius * radius * 4.0f) {
            n.on = false;
            mGridDirty = true;
        }
}

void Machinery::render(Renderer& r, const vec3& camPos) {
    static const float gColors[][3] = {
        {0.9f, 0.7f, 0.2f}, {0.3f, 0.5f, 0.9f}, {0.8f, 0.25f, 0.2f}, {0.4f, 0.4f, 0.45f}
    };
    for (auto& n : mNodes) {
        if (glm::distance2(n.pos, camPos) > 120.0f * 120.0f) continue;
        vec4 col(gColors[(int)n.kind][0], gColors[(int)n.kind][1], gColors[(int)n.kind][2], 1);
        if (!n.powered) col *= 0.45f;
        float h = n.kind == PowerKind::Panel ? 0.7f : (n.kind == PowerKind::Breaker ? 0.35f : 0.4f);
        vec3 s = n.kind == PowerKind::Panel ? vec3(0.25f, 0.5f, 0.08f)
               : n.kind == PowerKind::Breaker ? vec3(0.15f, 0.35f, 0.12f)
               : vec3(0.45f, 0.4f, 0.45f);
        mat4 m = glm::translate(mat4(1), n.pos + vec3(0, h, 0)) * glm::scale(mat4(1), s * 2.0f) * glm::scale(mat4(1), vec3(0.5f));
        r.drawInstance(MESH_CUBE, m, col, vec4(0.55f, 0, 0, 0));
        if (n.kind == PowerKind::Generator && n.powered)
            r.drawInstance(MESH_SPHERE, glm::translate(mat4(1), n.pos + vec3(0, 0.85f, 0)), vec4(0.3f, 1.0f, 0.3f, 1), vec4(0.2f, 1.0f, 0, 0));
    }
    for (auto& m : mMachines) {
        if (glm::distance2(m.basePos, camPos) > 150.0f * 150.0f) continue;
        vec4 col = m.powered ? vec4(0.65f, 0.68f, 0.72f, 1) : vec4(0.4f, 0.4f, 0.42f, 1);
        if (m.kind == MachineKind::Conveyor) col = m.powered ? vec4(0.25f, 0.28f, 0.32f, 1) : vec4(0.2f, 0.2f, 0.22f, 1);
        vec3 off = m.targetOffset * m.t;
        mat4 t = glm::translate(mat4(1), m.basePos + off) * glm::toMat4(glm::angleAxis(m.yaw, vec3(0, 1, 0)))
               * glm::scale(mat4(1), m.half);
        r.drawInstance(MESH_CUBE, t, col, vec4(0.6f, 0, 0, 0));
        if (m.kind == MachineKind::Fan && m.powered) {
            for (int i = 0; i < 3; ++i) {
                float a = m.phase + i * 2.094f;
                vec3 loff = glm::rotate(vec3(std::cos(a) * 0.25f, std::sin(a) * 0.25f, 0.35f), m.yaw, vec3(0, 1, 0));
                mat4 b = glm::translate(mat4(1), m.basePos + off + loff)
                       * glm::rotate(mat4(1), m.yaw, vec3(0, 1, 0)) * glm::rotate(mat4(1), a, vec3(0, 0, 1))
                       * glm::scale(mat4(1), vec3(0.25f, 0.04f, 0.03f));
                r.drawInstance(MESH_CUBE, b, vec4(0.85f, 0.85f, 0.9f, 1), vec4(0.4f, 0, 0, 0));
            }
        }
    }
}
