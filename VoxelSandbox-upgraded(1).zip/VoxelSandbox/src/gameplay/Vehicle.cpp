#include "gameplay/Vehicle.h"
#include "engine/Audio.h"
#include "engine/Particles.h"

#include <Jolt/Physics/Body/BodyLock.h>
#include <Jolt/Physics/Body/BodyLockMulti.h>
#include <Jolt/Physics/Collision/Shape/BoxShape.h>
#include <Jolt/Physics/Collision/Shape/OffsetCenterOfMassShape.h>
#include <Jolt/Physics/Collision/Shape/StaticCompoundShape.h>
#include <array>

using namespace JPH;

const char* VehicleName(int t) {
    static const char* n[VEH_COUNT] = {"Sedan", "Delivery Van", "Dump Truck", "Forklift", "Wheel Loader"};
    return n[glm::clamp(t, 0, VEH_COUNT - 1)];
}

namespace {
struct WheelDef { vec3 pos; float r, w; bool steer, drive, hand; };
struct Cfg {
    float mass;
    std::vector<VehicleBox> boxes;
    std::vector<WheelDef> wheels;
    float torque, maxRpm, diffRatio;
    float suspMin, suspMax, suspFreq, suspDamp;
    float comDrop, maxSteer;
    vec3 seat;
    float camDist, camHeight, boost;
    bool rearSteer;
};

VehicleBox B(vec3 c, vec3 h, vec3 col, float rough = 0.35f, float metal = 0.5f, bool collide = true, float emissive = 0) {
    return {c, h, vec4(col, 1), vec4(rough, metal, emissive, 0), collide};
}

Cfg MakeCfg(VehicleType t) {
    Cfg c{};
    const vec3 glass(0.08f, 0.1f, 0.13f), black(0.04f, 0.04f, 0.045f), chrome(0.7f, 0.7f, 0.72f), light(1.0f, 0.95f, 0.8f), red(0.9f, 0.05f, 0.03f);
    switch (t) {
    case VEH_CAR: {
        vec3 paint(0.62f, 0.07f, 0.06f);
        c.mass = 1300; c.torque = 520; c.maxRpm = 6500; c.diffRatio = 3.4f;
        c.suspMin = 0.08f; c.suspMax = 0.32f; c.suspFreq = 1.6f; c.suspDamp = 0.5f; c.comDrop = 0.25f; c.maxSteer = 0.6f;
        c.boxes = {B({0, 0, 0}, {0.86f, 0.28f, 2.1f}, paint, 0.25f, 0.6f),
                   B({0, 0.52f, -0.2f}, {0.78f, 0.25f, 1.05f}, glass, 0.08f, 0.2f),
                   B({0, 0.79f, -0.25f}, {0.8f, 0.035f, 0.85f}, paint, 0.25f, 0.6f, false),
                   B({0, -0.12f, 2.12f}, {0.88f, 0.1f, 0.06f}, black, 0.6f, 0.0f, false),
                   B({0, -0.12f, -2.12f}, {0.88f, 0.1f, 0.06f}, black, 0.6f, 0.0f, false),
                   B({0.6f, 0.08f, 2.11f}, {0.17f, 0.07f, 0.03f}, light, 0.2f, 0, false, 3.0f),
                   B({-0.6f, 0.08f, 2.11f}, {0.17f, 0.07f, 0.03f}, light, 0.2f, 0, false, 3.0f),
                   B({0.62f, 0.1f, -2.11f}, {0.15f, 0.06f, 0.03f}, red, 0.2f, 0, false, 1.5f),
                   B({-0.62f, 0.1f, -2.11f}, {0.15f, 0.06f, 0.03f}, red, 0.2f, 0, false, 1.5f)};
        c.wheels = {{{0.82f, 0, 1.3f}, 0.36f, 0.26f, true, true, false}, {{-0.82f, 0, 1.3f}, 0.36f, 0.26f, true, true, false},
                    {{0.82f, 0, -1.3f}, 0.36f, 0.26f, false, false, true}, {{-0.82f, 0, -1.3f}, 0.36f, 0.26f, false, false, true}};
        c.seat = {0.35f, 0.45f, -0.2f}; c.camDist = 6.5f; c.camHeight = 2.2f; c.boost = 1.0f;
        break;
    }
    case VEH_VAN: {
        vec3 paint(0.9f, 0.9f, 0.88f);
        c.mass = 2100; c.torque = 650; c.maxRpm = 5500; c.diffRatio = 3.9f;
        c.suspMin = 0.1f; c.suspMax = 0.35f; c.suspFreq = 1.5f; c.suspDamp = 0.5f; c.comDrop = 0.3f; c.maxSteer = 0.6f;
        c.boxes = {B({0, 0, 0}, {0.95f, 0.3f, 2.4f}, paint, 0.3f, 0.4f),
                   B({0, 0.95f, -0.45f}, {0.95f, 0.66f, 1.95f}, paint, 0.3f, 0.4f),
                   B({0, 0.75f, 1.75f}, {0.9f, 0.45f, 0.5f}, glass, 0.08f, 0.2f),
                   B({0, 0.98f, -0.45f}, {0.96f, 0.15f, 1.6f}, vec3(0.1f, 0.35f, 0.75f), 0.3f, 0.3f, false),
                   B({0.65f, 0.1f, 2.41f}, {0.18f, 0.08f, 0.03f}, light, 0.2f, 0, false, 3.0f),
                   B({-0.65f, 0.1f, 2.41f}, {0.18f, 0.08f, 0.03f}, light, 0.2f, 0, false, 3.0f),
                   B({0, -0.15f, 2.43f}, {0.96f, 0.1f, 0.05f}, black, 0.6f, 0, false)};
        c.wheels = {{{0.88f, 0, 1.6f}, 0.38f, 0.28f, true, true, false}, {{-0.88f, 0, 1.6f}, 0.38f, 0.28f, true, true, false},
                    {{0.88f, 0, -1.6f}, 0.38f, 0.28f, false, false, true}, {{-0.88f, 0, -1.6f}, 0.38f, 0.28f, false, false, true}};
        c.seat = {0.4f, 0.75f, 1.6f}; c.camDist = 7.5f; c.camHeight = 2.8f; c.boost = 1.0f;
        break;
    }
    case VEH_TRUCK: {
        vec3 paint(0.95f, 0.62f, 0.05f), bed(0.35f, 0.36f, 0.38f);
        c.mass = 6500; c.torque = 2600; c.maxRpm = 3200; c.diffRatio = 4.5f;
        c.suspMin = 0.15f; c.suspMax = 0.45f; c.suspFreq = 1.3f; c.suspDamp = 0.6f; c.comDrop = 0.35f; c.maxSteer = 0.55f;
        c.boxes = {B({0, 0, 0}, {1.15f, 0.32f, 3.7f}, black, 0.6f, 0.4f),
                   B({0, 1.05f, 2.75f}, {1.15f, 0.8f, 0.95f}, paint, 0.3f, 0.5f),
                   B({0, 1.25f, 3.71f}, {1.05f, 0.4f, 0.04f}, glass, 0.08f, 0.2f, false),
                   B({0, 0.42f, -0.9f}, {1.2f, 0.1f, 2.7f}, bed, 0.5f, 0.7f),
                   B({1.15f, 0.95f, -0.9f}, {0.05f, 0.45f, 2.7f}, bed, 0.5f, 0.7f),
                   B({-1.15f, 0.95f, -0.9f}, {0.05f, 0.45f, 2.7f}, bed, 0.5f, 0.7f),
                   B({0, 0.95f, -3.55f}, {1.2f, 0.45f, 0.05f}, bed, 0.5f, 0.7f),
                   B({0, 0.95f, 1.75f}, {1.2f, 0.45f, 0.05f}, bed, 0.5f, 0.7f),
                   B({0.8f, 0.35f, 3.71f}, {0.2f, 0.1f, 0.03f}, light, 0.2f, 0, false, 3.0f),
                   B({-0.8f, 0.35f, 3.71f}, {0.2f, 0.1f, 0.03f}, light, 0.2f, 0, false, 3.0f),
                   B({0, 0.05f, 3.75f}, {1.18f, 0.15f, 0.06f}, chrome, 0.2f, 1.0f, false)};
        c.wheels = {{{1.05f, 0, 2.6f}, 0.52f, 0.36f, true, false, false}, {{-1.05f, 0, 2.6f}, 0.52f, 0.36f, true, false, false},
                    {{1.05f, 0, -1.4f}, 0.52f, 0.4f, false, true, true}, {{-1.05f, 0, -1.4f}, 0.52f, 0.4f, false, true, true},
                    {{1.05f, 0, -2.75f}, 0.52f, 0.4f, false, true, true}, {{-1.05f, 0, -2.75f}, 0.52f, 0.4f, false, true, true}};
        c.seat = {0.5f, 1.2f, 2.8f}; c.camDist = 11.0f; c.camHeight = 4.0f; c.boost = 1.4f;
        break;
    }
    case VEH_FORKLIFT: {
        vec3 paint(0.95f, 0.72f, 0.05f);
        c.mass = 2800; c.torque = 900; c.maxRpm = 3000; c.diffRatio = 6.0f;
        c.suspMin = 0.05f; c.suspMax = 0.15f; c.suspFreq = 2.5f; c.suspDamp = 0.7f; c.comDrop = 0.35f; c.maxSteer = 0.8f;
        c.boxes = {B({0, 0, 0}, {0.6f, 0.32f, 0.95f}, paint, 0.35f, 0.4f),
                   B({0, 0.5f, -0.72f}, {0.62f, 0.28f, 0.25f}, vec3(0.2f, 0.2f, 0.22f), 0.5f, 0.6f),
                   B({0.55f, 1.0f, 0.45f}, {0.035f, 0.68f, 0.035f}, black, 0.5f, 0.5f),
                   B({-0.55f, 1.0f, 0.45f}, {0.035f, 0.68f, 0.035f}, black, 0.5f, 0.5f),
                   B({0.55f, 1.0f, -0.55f}, {0.035f, 0.68f, 0.035f}, black, 0.5f, 0.5f),
                   B({-0.55f, 1.0f, -0.55f}, {0.035f, 0.68f, 0.035f}, black, 0.5f, 0.5f),
                   B({0, 1.7f, -0.05f}, {0.6f, 0.03f, 0.55f}, black, 0.5f, 0.5f),
                   B({0.32f, 1.05f, 1.0f}, {0.05f, 1.35f, 0.06f}, vec3(0.3f, 0.3f, 0.32f), 0.4f, 0.8f),
                   B({-0.32f, 1.05f, 1.0f}, {0.05f, 1.35f, 0.06f}, vec3(0.3f, 0.3f, 0.32f), 0.4f, 0.8f),
                   B({0, 0.45f, -0.1f}, {0.3f, 0.12f, 0.25f}, black, 0.8f, 0.0f, false)};
        c.wheels = {{{0.5f, 0, 0.6f}, 0.33f, 0.24f, false, true, false}, {{-0.5f, 0, 0.6f}, 0.33f, 0.24f, false, true, false},
                    {{0.48f, 0, -0.6f}, 0.27f, 0.2f, true, false, true}, {{-0.48f, 0, -0.6f}, 0.27f, 0.2f, true, false, true}};
        c.seat = {0, 0.75f, -0.1f}; c.camDist = 5.5f; c.camHeight = 2.6f; c.boost = 1.0f; c.rearSteer = true;
        break;
    }
    case VEH_LOADER: {
        vec3 paint(0.95f, 0.55f, 0.05f), steel(0.25f, 0.25f, 0.27f);
        c.mass = 11000; c.torque = 9000; c.maxRpm = 2600; c.diffRatio = 6.0f;
        c.suspMin = 0.1f; c.suspMax = 0.3f; c.suspFreq = 1.4f; c.suspDamp = 0.7f; c.comDrop = 0.45f; c.maxSteer = 0.55f;
        c.boxes = {B({0, 0.1f, -0.2f}, {1.1f, 0.5f, 1.8f}, paint, 0.35f, 0.4f),
                   B({0, 1.3f, -0.4f}, {0.75f, 0.7f, 0.65f}, glass, 0.08f, 0.2f),
                   B({0, 2.03f, -0.4f}, {0.8f, 0.05f, 0.7f}, paint, 0.35f, 0.4f, false),
                   B({0, 0.85f, -1.5f}, {1.0f, 0.3f, 0.5f}, paint, 0.35f, 0.4f),
                   B({0.85f, 0.45f, 1.85f}, {0.1f, 0.15f, 0.6f}, steel, 0.4f, 0.8f),
                   B({-0.85f, 0.45f, 1.85f}, {0.1f, 0.15f, 0.6f}, steel, 0.4f, 0.8f),
                   B({0, 0.05f, 2.6f}, {1.45f, 0.55f, 0.12f}, steel, 0.45f, 0.9f),
                   B({0, -0.45f, 2.25f}, {1.45f, 0.06f, 0.4f}, steel, 0.45f, 0.9f),
                   B({1.42f, -0.15f, 2.25f}, {0.04f, 0.35f, 0.4f}, steel, 0.45f, 0.9f),
                   B({-1.42f, -0.15f, 2.25f}, {0.04f, 0.35f, 0.4f}, steel, 0.45f, 0.9f),
                   B({0.5f, 1.85f, 0.26f}, {0.12f, 0.06f, 0.02f}, light, 0.2f, 0, false, 3.0f),
                   B({-0.5f, 1.85f, 0.26f}, {0.12f, 0.06f, 0.02f}, light, 0.2f, 0, false, 3.0f)};
        c.wheels = {{{1.15f, 0, 1.15f}, 0.75f, 0.5f, true, true, false}, {{-1.15f, 0, 1.15f}, 0.75f, 0.5f, true, true, false},
                    {{1.15f, 0, -1.25f}, 0.75f, 0.5f, false, true, true}, {{-1.15f, 0, -1.25f}, 0.75f, 0.5f, false, true, true}};
        c.seat = {0, 1.2f, -0.4f}; c.camDist = 10.0f; c.camHeight = 4.2f; c.boost = 2.2f;
        break;
    }
    default: break;
    }
    return c;
}
}  // namespace

bool Vehicle::create(PhysicsWorld* phys, VehicleType t, const vec3& pos, float yaw) {
    mPhys = phys;
    type = t;
    Cfg cfg = MakeCfg(t);
    mass = cfg.mass;
    mBoxes = cfg.boxes;
    mSeat = cfg.seat;
    camDistance = cfg.camDist; camHeight = cfg.camHeight; destructionBoost = cfg.boost;
    mComDrop = cfg.comDrop;
    tag.type = TagType::Vehicle; tag.ptr = this;
    mHalf = vec3(0);
    for (auto& b : mBoxes) if (b.collide) mHalf = glm::max(mHalf, glm::abs(b.center) + b.half);

    StaticCompoundShapeSettings comp;
    for (auto& b : mBoxes)
        if (b.collide) comp.AddShape(ToJ(b.center), Quat::sIdentity(), new BoxShape(ToJ(b.half), std::min(0.05f, std::min(b.half.x, std::min(b.half.y, b.half.z)) * 0.5f)));
    auto cres = comp.Create();
    if (cres.HasError()) { LOGE("vehicle shape: %s", cres.GetError().c_str()); return false; }
    auto ores = OffsetCenterOfMassShapeSettings(Vec3(0, -cfg.comDrop, 0), cres.Get()).Create();
    if (ores.HasError()) { LOGE("vehicle com: %s", ores.GetError().c_str()); return false; }

    mGroup = new GroupFilterTable(2);
    mGroup->DisableCollision(0, 1);
    static int sGroupId = 1000;
    int gid = sGroupId++;

    quat rot = glm::angleAxis(yaw, vec3(0, 1, 0));
    BodyCreationSettings bs(ores.Get(), RVec3(pos.x, pos.y, pos.z), ToJ(rot), EMotionType::Dynamic, Layers::VEHICLE);
    bs.mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
    bs.mMassPropertiesOverride.mMass = cfg.mass;
    bs.mMotionQuality = EMotionQuality::LinearCast;
    bs.mFriction = 0.5f;
    bs.mRestitution = 0.1f;
    bs.mUserData = (uint64_t)(uintptr_t)&tag;
    bs.mCollisionGroup = CollisionGroup(mGroup, (CollisionGroup::GroupID)gid, 0);
    body = phys->bi().CreateAndAddBody(bs, EActivation::Activate);
    if (body.IsInvalid()) return false;

    VehicleConstraintSettings vs;
    vs.mUp = Vec3::sAxisY();
    vs.mForward = Vec3::sAxisZ();
    vs.mMaxPitchRollAngle = JPH_PI;
    auto* ctl = new WheeledVehicleControllerSettings();
    ctl->mEngine.mMaxTorque = cfg.torque;
    ctl->mEngine.mMaxRPM = cfg.maxRpm;
    ctl->mEngine.mMinRPM = 900.0f;
    ctl->mTransmission.mMode = ETransmissionMode::Auto;
    ctl->mTransmission.mShiftUpRPM = cfg.maxRpm * 0.68f;
    ctl->mTransmission.mShiftDownRPM = cfg.maxRpm * 0.32f;
    if (t == VEH_FORKLIFT || t == VEH_LOADER) {
        ctl->mTransmission.mGearRatios = {3.2f, 1.8f};
        ctl->mTransmission.mReverseGearRatios = {-3.2f};
    }
    vs.mController = ctl;
    std::vector<int> driven;
    for (size_t i = 0; i < cfg.wheels.size(); ++i) {
        const WheelDef& w = cfg.wheels[i];
        Ref<WheelSettingsWV> ws = new WheelSettingsWV();
        ws->mPosition = ToJ(w.pos);
        ws->mSuspensionDirection = Vec3(0, -1, 0);
        ws->mSteeringAxis = Vec3(0, 1, 0);
        ws->mWheelUp = Vec3(0, 1, 0);
        ws->mWheelForward = Vec3(0, 0, 1);
        ws->mRadius = w.r;
        ws->mWidth = w.w;
        ws->mSuspensionMinLength = cfg.suspMin;
        ws->mSuspensionMaxLength = cfg.suspMax;
        ws->mSuspensionSpring.mFrequency = cfg.suspFreq;
        ws->mSuspensionSpring.mDamping = cfg.suspDamp;
        ws->mMaxSteerAngle = w.steer ? cfg.maxSteer : 0.0f;
        ws->mMaxHandBrakeTorque = w.hand ? 4000.0f * cfg.mass / 1300.0f : 0.0f;
        ws->mMaxBrakeTorque = 1500.0f * cfg.mass / 1300.0f;
        ws->mInertia = 0.5f * (20.0f * w.r / 0.3f) * w.r * w.r;
        vs.mWheels.push_back(Ref<WheelSettings>(ws.GetPtr()));
        mWheelRadius.push_back(w.r);
        mWheelWidth.push_back(w.w);
        if (w.drive) driven.push_back((int)i);
    }
    // wheels are defined in left/right pairs: differentials and anti-roll bars per axle
    int axles = 0;
    for (size_t i = 0; i + 1 < driven.size(); i += 2) ++axles;
    for (size_t i = 0; i + 1 < driven.size(); i += 2) {
        VehicleDifferentialSettings d;
        d.mLeftWheel = driven[i]; d.mRightWheel = driven[i + 1];
        d.mDifferentialRatio = cfg.diffRatio;
        d.mEngineTorqueRatio = 1.0f / axles;
        ctl->mDifferentials.push_back(d);
    }
    for (size_t i = 0; i + 1 < cfg.wheels.size(); i += 2) {
        VehicleAntiRollBar ar;
        ar.mLeftWheel = (int)i; ar.mRightWheel = (int)i + 1;
        ar.mStiffness = 1200.0f * cfg.mass / 1300.0f;
        vs.mAntiRollBars.push_back(ar);
    }
    {
        BodyLockWrite lock(phys->sys().GetBodyLockInterface(), body);
        if (!lock.Succeeded()) return false;
        mConstraint = new VehicleConstraint(lock.GetBody(), vs);
    }
    mTester = new VehicleCollisionTesterCastCylinder(Layers::VEHICLE, 0.05f);
    mConstraint->SetVehicleCollisionTester(mTester);
    phys->sys().AddConstraint(mConstraint);
    phys->sys().AddStepListener(mConstraint);

    if (t == VEH_FORKLIFT) {
        // motorized fork carriage on a slider constraint
        vec3 forkLocal(0, -0.15f, 1.14f);
        mForkBoxes = {B({0, 0.3f, 0}, {0.36f, 0.32f, 0.03f}, vec3(0.2f, 0.2f, 0.22f), 0.5f, 0.6f),
                      B({0.2f, -0.02f, 0.55f}, {0.06f, 0.025f, 0.58f}, vec3(0.25f, 0.25f, 0.27f), 0.4f, 0.8f),
                      B({-0.2f, -0.02f, 0.55f}, {0.06f, 0.025f, 0.58f}, vec3(0.25f, 0.25f, 0.27f), 0.4f, 0.8f)};
        StaticCompoundShapeSettings fc;
        for (auto& b : mForkBoxes) fc.AddShape(ToJ(b.center), Quat::sIdentity(), new BoxShape(ToJ(b.half), 0.01f));
        vec3 fp = pos + rot * forkLocal;
        BodyCreationSettings fs(fc.Create().Get(), RVec3(fp.x, fp.y, fp.z), ToJ(rot), EMotionType::Dynamic, Layers::VEHICLE);
        fs.mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
        fs.mMassPropertiesOverride.mMass = 250.0f;
        fs.mFriction = 0.9f;
        fs.mUserData = (uint64_t)(uintptr_t)&tag;
        fs.mCollisionGroup = CollisionGroup(mGroup, (CollisionGroup::GroupID)gid, 1);
        forkBody = phys->bi().CreateAndAddBody(fs, EActivation::Activate);
        SliderConstraintSettings ss;
        ss.mAutoDetectPoint = false;
        ss.mPoint1 = ss.mPoint2 = RVec3(fp.x, fp.y, fp.z);
        vec3 up = rot * vec3(0, 1, 0), fw = rot * vec3(0, 0, 1);
        ss.mSliderAxis1 = ss.mSliderAxis2 = ToJ(up);
        ss.mNormalAxis1 = ss.mNormalAxis2 = ToJ(fw);
        ss.mLimitsMin = 0.0f; ss.mLimitsMax = mMaxForkHeight;
        ss.mMotorSettings = MotorSettings(4.0f, 1.0f);
        ss.mMotorSettings.SetForceLimit(60000.0f);
        std::array<BodyID, 2> ids{body, forkBody};
        BodyLockMultiWrite lock(phys->sys().GetBodyLockInterface(), ids.data(), 2);
        Body* a = lock.GetBody(0); Body* b = lock.GetBody(1);
        if (a && b) {
            mForkSlider = static_cast<SliderConstraint*>(ss.Create(*a, *b));
            mForkSlider->SetMotorState(EMotorState::Position);
            mForkSlider->SetTargetPosition(0.0f);
            phys->sys().AddConstraint(mForkSlider);
        }
    }
    return true;
}

void Vehicle::destroy() {
    if (!mPhys) return;
    GAudio().stop(mEngineVoice); GAudio().stop(mSkidVoice);
    if (mForkSlider) { mPhys->sys().RemoveConstraint(mForkSlider); mForkSlider = nullptr; }
    if (mConstraint) { mPhys->sys().RemoveStepListener(mConstraint); mPhys->sys().RemoveConstraint(mConstraint); mConstraint = nullptr; }
    for (BodyID* b : {&body, &forkBody})
        if (!b->IsInvalid()) { mPhys->bi().RemoveBody(*b); mPhys->bi().DestroyBody(*b); *b = BodyID(); }
}

vec3 Vehicle::position() const { return ToG(Vec3(mPhys->bi().GetPosition(body))); }
quat Vehicle::rotation() const { return ToG(mPhys->bi().GetRotation(body)); }
vec3 Vehicle::velocity() const { return ToG(mPhys->bi().GetLinearVelocity(body)); }
float Vehicle::speedKmh() const { return glm::length(velocity()) * 3.6f; }
vec3 Vehicle::seatWorld() const { return position() + rotation() * mSeat; }
vec3 Vehicle::exitPoint() const {
    quat q = rotation();
    vec3 side = q * vec3(1, 0, 0);
    side.y = 0;
    if (glm::length(side) < 0.1f) side = vec3(1, 0, 0);
    side = glm::normalize(side);
    vec3 base = position();
    // prefer the driver side, then other side, then on the roof
    for (float s : {1.0f, -1.0f}) {
        vec3 p = base + side * s * (mHalf.x + 0.7f) + vec3(0, 0.3f, 0);
        RayHit h;
        if (!mPhys->raycast(base + vec3(0, 0.3f, 0), side * s, mHalf.x + 1.0f, h, body)) return p;
    }
    return base + vec3(0, mHalf.y + 1.2f, 0);
}

float Vehicle::rpm() const {
    auto* c = static_cast<const WheeledVehicleController*>(mConstraint->GetController());
    return c->GetEngine().GetCurrentRPM();
}
int Vehicle::gear() const {
    auto* c = static_cast<const WheeledVehicleController*>(mConstraint->GetController());
    return c->GetTransmission().GetCurrentGear();
}

void Vehicle::applyDamage(float amount, const vec3& at) {
    if (wrecked || amount <= 0) return;
    health -= amount;
    if (health <= 0) {
        health = 0;
        wrecked = true;
        GAudio().play(SND_METAL_HEAVY, at, 1.0f, 0.7f);
    }
}

void Vehicle::update(float dt, const VehicleInput& inRaw, bool occupied, Particles* parts) {
    BodyInterface& bi = mPhys->bi();
    auto* ctl = static_cast<WheeledVehicleController*>(mConstraint->GetController());
    VehicleInput in = inRaw;
    if (!occupied || wrecked) { in = VehicleInput(); in.handbrake = !occupied || wrecked; }
    quat q = rotation();
    vec3 fwd = q * vec3(0, 0, 1);
    vec3 vel = velocity();
    float vz = glm::dot(vel, fwd);
    float forward = in.throttle, brake = in.brake;
    if (forward > 0.1f && vz < -0.8f) { brake = 1.0f; forward = 0; }
    if (forward < -0.1f && vz > 0.8f) { brake = 1.0f; forward = 0; }
    float speed = std::fabs(vz);
    float steer = in.steer * glm::mix(1.0f, 0.45f, Saturate(speed / 25.0f));
    if (type == VEH_FORKLIFT) steer = -steer;   // rear-wheel steering
    ctl->SetDriverInput(forward, steer, brake, in.handbrake ? 1.0f : 0.0f);
    if (occupied && (std::fabs(forward) > 0.01f || std::fabs(steer) > 0.01f || brake > 0)) bi.ActivateBody(body);

    if (mForkSlider) {
        forkHeight = glm::clamp(forkHeight + in.fork * dt * 0.9f, 0.0f, mMaxForkHeight);
        mForkSlider->SetTargetPosition(forkHeight);
        if (std::fabs(in.fork) > 0.01f) { bi.ActivateBody(body); bi.ActivateBody(forkBody); }
    }

    // engine and tire sounds
    float r = rpm();
    float load = Saturate(std::fabs(forward));
    if (occupied && !wrecked) mEngineFade = std::min(1.0f, mEngineFade + dt * 2.0f);
    else mEngineFade = std::max(0.0f, mEngineFade - dt * 0.7f);
    vec3 p = position();
    if (mEngineFade > 0.01f) {
        float basePitch = (type == VEH_CAR) ? 1.0f : (type == VEH_VAN ? 0.85f : (type == VEH_FORKLIFT ? 1.1f : 0.6f));
        float pitch = basePitch * (0.55f + 1.3f * Saturate(r / 6500.0f * (type == VEH_CAR ? 1.0f : 1.8f)));
        float vol = mEngineFade * (0.25f + 0.45f * load);
        if (!GAudio().playing(mEngineVoice)) mEngineVoice = GAudio().play(SND_ENGINE, p, vol, pitch, true, true);
        else GAudio().setVoice(mEngineVoice, p, vol, pitch);
    } else if (mEngineVoice) { GAudio().stop(mEngineVoice); mEngineVoice = 0; }

    float slip = 0;
    for (auto* w : mConstraint->GetWheels()) {
        if (!w->HasContact()) continue;
        auto* wv = static_cast<const WheelWV*>(w);
        slip = std::max(slip, std::fabs(wv->mLateralSlip) * Saturate(speed / 6.0f) + std::fabs(wv->mLongitudinalSlip) * 0.3f * Saturate(speed / 4.0f));
    }
    if (slip > 0.25f && speed > 3.0f) {
        float vol = Saturate((slip - 0.25f) * 2.0f) * 0.6f;
        if (!GAudio().playing(mSkidVoice)) mSkidVoice = GAudio().play(SND_SKID, p, vol, 1.0f, true, true);
        else GAudio().setVoice(mSkidVoice, p, vol, 1.0f);
        if (parts && GRng().f01() < 0.3f) {
            int i = GRng().irange(0, (int)mConstraint->GetWheels().size() - 1);
            auto* w = mConstraint->GetWheels()[i];
            if (w->HasContact()) parts->spawn(PType::Dust, ToG(Vec3(w->GetContactPosition())) + vec3(0, 0.1f, 0), vec3(0, 0.6f, 0), vec4(0.55f, 0.55f, 0.55f, 0.35f), 0.5f, 1.4f);
        }
    } else if (mSkidVoice) { GAudio().stop(mSkidVoice); mSkidVoice = 0; }

    // damage smoke / fire
    if (parts && health < 55.0f) {
        mSmokeTimer -= dt;
        if (mSmokeTimer <= 0) {
            mSmokeTimer = health < 20 ? 0.06f : 0.18f;
            vec3 engine = p + q * vec3(0, mHalf.y * 0.6f, mHalf.z * (type == VEH_FORKLIFT ? -0.6f : 0.6f));
            float dark = health < 25 ? 0.12f : 0.4f;
            parts->spawn(PType::Smoke, engine, vec3(GRng().range(-0.3f, 0.3f), 1.5f, GRng().range(-0.3f, 0.3f)), vec4(dark, dark, dark, 0.5f), 0.6f, 3.0f);
            if (wrecked && GRng().f01() < 0.5f) parts->spawn(PType::Fire, engine, vec3(0, 1.8f, 0), vec4(1.0f, 0.5f, 0.1f, 0.9f), 0.5f, 0.5f);
        }
    }
}

void Vehicle::render(Renderer& r, bool night) {
    BodyInterface& bi = mPhys->bi();
    mat4 M = ToG(bi.GetWorldTransform(body));
    float dmg = 0.45f + 0.55f * (health / 100.0f);
    for (auto& b : mBoxes) {
        mat4 m = M * glm::translate(mat4(1), b.center) * glm::scale(mat4(1), b.half * 2.0f);
        vec4 col = b.color;
        vec4 prm = b.params;
        if (prm.z > 0) prm.z = (headlights || night) && !wrecked ? prm.z : 0.15f;
        else col = vec4(vec3(col) * dmg, col.a);
        r.drawInstance(MESH_CUBE, m, col, prm);
    }
    if (!forkBody.IsInvalid()) {
        mat4 F = ToG(bi.GetWorldTransform(forkBody));
        for (auto& b : mForkBoxes) r.drawInstance(MESH_CUBE, F * glm::translate(mat4(1), b.center) * glm::scale(mat4(1), b.half * 2.0f), b.color, b.params);
    }
    const auto& wheels = mConstraint->GetWheels();
    for (size_t i = 0; i < wheels.size(); ++i) {
        mat4 W = ToG(mConstraint->GetWheelWorldTransform((uint)i, Vec3::sAxisY(), Vec3::sAxisX()));
        float rad = mWheelRadius[i], wid = mWheelWidth[i];
        r.drawInstance(MESH_CYLINDER, W * glm::scale(mat4(1), vec3(rad * 2.0f, wid, rad * 2.0f)), vec4(0.05f, 0.05f, 0.05f, 1), vec4(0.85f, 0, 0, 0));
        r.drawInstance(MESH_CYLINDER, W * glm::scale(mat4(1), vec3(rad * 1.2f, wid * 1.04f, rad * 1.2f)), vec4(0.6f, 0.6f, 0.62f, 1), vec4(0.3f, 1.0f, 0, 0));
        // spoke marker so wheel rotation is visible
        r.drawInstance(MESH_CUBE, W * glm::scale(mat4(1), vec3(rad * 1.15f, wid * 1.06f, rad * 0.18f)), vec4(0.2f, 0.2f, 0.22f, 1), vec4(0.4f, 0.8f, 0, 0), false);
    }
    if ((headlights || night) && !wrecked) {
        quat q = rotation();
        vec3 front = position() + q * vec3(0, 0.3f, mHalf.z + 3.0f);
        r.addLight({front, 9.0f, vec3(1.0f, 0.9f, 0.7f) * 1.6f});
    }
}

// ---------------------------------------------------------------- manager
void VehicleManager::clear() {
    for (auto& v : mVehicles) v->destroy();
    mVehicles.clear();
}

Vehicle* VehicleManager::spawn(VehicleType t, const vec3& pos, float yaw) {
    auto v = std::make_unique<Vehicle>();
    if (!v->create(mPhys, t, pos, yaw)) { v->destroy(); return nullptr; }
    mVehicles.push_back(std::move(v));
    return mVehicles.back().get();
}

void VehicleManager::remove(Vehicle* v) {
    for (size_t i = 0; i < mVehicles.size(); ++i)
        if (mVehicles[i].get() == v) { v->destroy(); mVehicles.erase(mVehicles.begin() + i); return; }
}

void VehicleManager::update(float dt, Vehicle* driven, const VehicleInput& in, Particles* parts) {
    for (auto& v : mVehicles) v->update(dt, in, v.get() == driven, parts);
}

void VehicleManager::render(Renderer& r, const vec3& cam, float dist, bool night) {
    for (auto& v : mVehicles) {
        vec3 p = v->position();
        if (glm::distance(p, cam) > dist || !r.sphereVisible(p, 6.0f)) continue;
        v->render(r, night);
    }
}

Vehicle* VehicleManager::find(BodyID id) {
    for (auto& v : mVehicles) if (v->owns(id)) return v.get();
    return nullptr;
}

Vehicle* VehicleManager::nearest(const vec3& p, float maxDist) {
    Vehicle* best = nullptr;
    float bd = maxDist;
    for (auto& v : mVehicles) {
        float d = glm::distance(v->position(), p);
        if (d < bd) { bd = d; best = v.get(); }
    }
    return best;
}
