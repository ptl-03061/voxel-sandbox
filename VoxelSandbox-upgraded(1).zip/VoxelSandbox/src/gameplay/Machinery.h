// Machinery: simplified power simulation (generators -> batteries -> breakers -> consumers)
// and physical machines: conveyors, hydraulic lifts, fans, industrial presses, powered doors.
// Power is boolean flow over a node graph, recomputed only when the grid changes.
#pragma once
#include "core/Common.h"
#include "physics/PhysicsWorld.h"
#include "destruction/VoxelObject.h"

enum class PowerKind : uint8_t { Generator, Battery, Breaker, Panel };
enum class MachineKind : uint8_t { Conveyor, Lift, Fan, Press, PoweredDoor };

struct PowerNode {
    int id = 0;
    PowerKind kind = PowerKind::Panel;
    vec3 pos{0};
    float capacity = 0;      // generators/batteries: kW available
    float radius = 12.0f;    // power range (keeps the model cheap on mobile)
    bool on = true;          // breaker state / generator running
    bool powered = false;    // computed
    float charge = 1.0f;     // batteries
    JPH::BodyID body;
};

struct Machine {
    int id = 0;
    MachineKind kind;
    std::string name;
    JPH::BodyID body;
    vec3 basePos{0}, half{0.5f};
    float yaw = 0;
    bool powered = false;
    vec3 targetOffset{0};
    float t = 0;             // 0..1 animation
    float speed = 1.0f;
    float phase = 0;
    vec3 beltDir{1, 0, 0};
    float beltSpeed = 2.0f;
    float fanForce = 900.0f;
    float fanRadius = 6.0f;
    float pressDamage = 1.2f;
    float cooldown = 0;
};

class Destruction;
class Renderer;
class Particles;

class Machinery {
public:
    void init(PhysicsWorld* phys, ObjectManager* objs, Destruction* destr);
    void clear();

    int addGenerator(const vec3& pos, float capacity = 10.0f);
    int addBattery(const vec3& pos, float capacity = 5.0f);
    int addBreaker(const vec3& pos);
    int addPanel(const vec3& pos);

    int addConveyor(const vec3& pos, float yaw, float length);
    int addLift(const vec3& pos, float travel, float halfXZ = 1.2f);
    int addFan(const vec3& pos, float yaw, float pitch);
    int addPress(const vec3& pos);
    int addPoweredDoor(const vec3& pos, float yaw, const vec3& half, float openDist);

    void toggleBreaker(int node);
    void setNodeOn(int node, bool on);
    void onExplosion(const vec3& c, float radius);

    void prePhysics(float dt);
    void update(float dt);
    void render(Renderer& r, const vec3& camPos);

    std::vector<PowerNode>& nodes() { return mNodes; }
    std::vector<Machine>& machines() { return mMachines; }
    int poweredCount() const { int n = 0; for (auto& m : mMachines) n += m.powered; return n; }

private:
    JPH::BodyID makeBox(const vec3& pos, const vec3& half);
    void recomputePower();

    PhysicsWorld* mPhys = nullptr;
    ObjectManager* mObjs = nullptr;
    Destruction* mDestr = nullptr;
    std::vector<PowerNode> mNodes;
    std::vector<Machine> mMachines;
    int mNextId = 1;
    bool mGridDirty = true;
};
