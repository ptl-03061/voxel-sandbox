// First-person player built on Jolt CharacterVirtual (stairs, slopes, moving platforms, pushes props).
#pragma once
#include "physics/PhysicsWorld.h"

#include <Jolt/Physics/Character/CharacterVirtual.h>

class Destruction;

class Player {
public:
    void init(PhysicsWorld* phys, const vec3& feetPos, float yaw);
    void shutdown();
    // move: x = strafe right, y = forward (-1..1)
    void update(float dt, const vec2& move, bool jump, bool sprint, Destruction* destr);
    void teleport(const vec3& feet);
    void park();                     // hide physics capsule while driving
    void look(float dYaw, float dPitch);

    vec3 feet() const { return mFeet; }
    vec3 eye() const { return mFeet + vec3(0, EYE + mBob, 0); }
    vec3 forward() const;           // camera forward
    vec3 flatForward() const;
    vec3 right() const;
    vec3 velocity() const { return mVel; }
    bool onGround() const { return mOnGround; }
    JPH::BodyID innerBody() const { return mInner; }

    float yaw = 0, pitch = 0;
    float health = 100.0f;
    float hurtFlash = 0;
    float speedWalk = 4.2f, speedSprint = 7.5f, jumpSpeed = 5.4f;
    bool noclip = false;
    vec3 spawnPoint{0};
    void damage(float amount);

    static constexpr float HEIGHT = 1.8f, RADIUS = 0.3f, EYE = 1.62f;

private:
    PhysicsWorld* mPhys = nullptr;
    JPH::Ref<JPH::CharacterVirtual> mChar;
    JPH::BodyID mInner;
    vec3 mFeet{0}, mVel{0};
    bool mOnGround = false;
    float mStepAccum = 0, mBob = 0, mBobPhase = 0;
    float mAirTime = 0, mFallSpeed = 0;
};
