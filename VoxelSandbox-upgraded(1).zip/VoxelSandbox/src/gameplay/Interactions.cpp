#include "gameplay/Interactions.h"
#include "destruction/Destruction.h"
#include "engine/Audio.h"

#include <Jolt/Physics/Body/BodyLock.h>
#include <Jolt/Physics/Body/BodyLockMulti.h>
#include <glm/gtx/quaternion.hpp>
#include <Jolt/Physics/Collision/GroupFilterTable.h>
#include <Jolt/Physics/Collision/Shape/BoxShape.h>
#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Collision/Shape/SphereShape.h>
#include <Jolt/Physics/Constraints/DistanceConstraint.h>
#include <Jolt/Physics/Constraints/HingeConstraint.h>
#include <Jolt/Physics/Constraints/PointConstraint.h>

using namespace JPH;

void Interactions::init(PhysicsWorld* phys, VoxelWorld* world, ObjectManager* objs) {
    mPhys = phys; mWorld = world; mObjs = objs;
    platformTag.type = TagType::Platform;
}

void Interactions::clear() {
    BodyInterface& bi = mPhys->bi();
    auto kill = [&](BodyID& id) { if (!id.IsInvalid()) { bi.RemoveBody(id); bi.DestroyBody(id); id = BodyID(); } };
    for (auto& c : mCranes) {
        for (auto& j : c.joints) if (j) mPhys->sys().RemoveConstraint(j);
        c.joints.clear();
        for (auto& l : c.links) kill(l);
        kill(c.ball); kill(c.jib);
    }
    for (auto& e : mElevators) { kill(e.body); GAudio().stop(e.voice); }
    for (auto& g : mGates) { kill(g.body); GAudio().stop(g.voice); }
    mCranes.clear(); mElevators.clear(); mGates.clear(); mSwitches.clear(); mPlates.clear(); mLights.clear();
}

// ---------------------------------------------------------------- doors
VoxelObject* Interactions::addDoor(const vec3& hingeBottom, float yaw, int w, int h, uint8_t mat, bool window, float breakImpulse) {
    VoxelModel m;
    m.resize({w, h, 1}, 0.125f);
    m.box({0, 0, 0}, {w, h, 1}, mat);
    if (window) m.box({2, h / 2, 0}, {w - 2, h - 3, 1}, M_GLASS);
    m.set(w - 2, h * 45 / 100, 0, M_METAL);   // handle
    quat rot = glm::angleAxis(yaw, vec3(0, 1, 0));
    vec3 pos = hingeBottom - rot * vec3(0, 0, 0.0625f);
    VoxelObject* o = mObjs->create(std::move(m), pos, rot, OBJ_DOOR | OBJ_NO_SPLIT, vec3(0), vec3(0), 1.0f, "Door");
    if (!o) return nullptr;
    HingeConstraintSettings hs;
    hs.mSpace = EConstraintSpace::WorldSpace;
    vec3 hp = hingeBottom + vec3(0, h * 0.0625f, 0);
    hs.mPoint1 = hs.mPoint2 = RVec3(hp.x, hp.y, hp.z);
    hs.mHingeAxis1 = hs.mHingeAxis2 = Vec3::sAxisY();
    hs.mNormalAxis1 = hs.mNormalAxis2 = ToJ(rot * vec3(1, 0, 0));
    hs.mLimitsMin = -1.8f; hs.mLimitsMax = 1.8f;
    hs.mMaxFrictionTorque = 18.0f;
    BodyLockWrite lock(mPhys->sys().GetBodyLockInterface(), o->body);
    if (lock.Succeeded()) {
        o->hinge = hs.Create(Body::sFixedToWorld, lock.GetBody());
    }
    if (o->hinge) mPhys->sys().AddConstraint(o->hinge);
    o->hingeBreakImpulse = breakImpulse;
    // frame voxel next to the hinge: if it's destroyed, the door falls out
    o->hingeAnchorVoxel = VoxelWorld::toVoxel(hingeBottom + rot * vec3(-0.15f, 0, 0) + vec3(0, 1.0f, 0));
    return o;
}

VoxelObject* Interactions::addSeesaw(const vec3& pivot, float yaw) {
    VoxelModel m;
    m.resize({40, 2, 6}, 0.125f);
    m.box({0, 0, 0}, {40, 2, 6}, M_PLANK);
    m.box({0, 1, 0}, {3, 2, 6}, M_PAINT_RED);
    m.box({37, 1, 0}, {40, 2, 6}, M_PAINT_BLUE);
    quat rot = glm::angleAxis(yaw, vec3(0, 1, 0));
    vec3 pos = pivot - rot * vec3(2.5f, 0.125f, 0.375f);
    VoxelObject* o = mObjs->create(std::move(m), pos, rot, OBJ_PROP | OBJ_NO_SPLIT, vec3(0), vec3(0), 1.0f, "Seesaw");
    if (!o) return nullptr;
    HingeConstraintSettings hs;
    hs.mPoint1 = hs.mPoint2 = RVec3(pivot.x, pivot.y, pivot.z);
    hs.mHingeAxis1 = hs.mHingeAxis2 = ToJ(rot * vec3(0, 0, 1));
    hs.mNormalAxis1 = hs.mNormalAxis2 = ToJ(rot * vec3(1, 0, 0));
    hs.mLimitsMin = -0.45f; hs.mLimitsMax = 0.45f;
    BodyLockWrite lock(mPhys->sys().GetBodyLockInterface(), o->body);
    if (lock.Succeeded()) o->hinge = hs.Create(Body::sFixedToWorld, lock.GetBody());
    if (o->hinge) mPhys->sys().AddConstraint(o->hinge);
    o->hingeBreakImpulse = 0;
    return o;
}

// ---------------------------------------------------------------- elevators / gates
int Interactions::addElevator(const vec3& base, const vec3& half, const std::vector<float>& floors) {
    Elevator e;
    e.base = base; e.half = half; e.floors = floors; e.y = floors.empty() ? base.y : floors[0];
    BodyCreationSettings bs(new BoxShape(ToJ(half), 0.02f), RVec3(base.x, e.y, base.z), Quat::sIdentity(), EMotionType::Kinematic, Layers::KINEMATIC);
    bs.mUserData = (uint64_t)(uintptr_t)&platformTag;
    bs.mFriction = 0.9f;
    e.body = mPhys->bi().CreateAndAddBody(bs, EActivation::Activate);
    mElevators.push_back(e);
    return (int)mElevators.size() - 1;
}

int Interactions::addGate(const vec3& c, const vec3& half, float openHeight) {
    Gate g;
    g.closed = c; g.half = half; g.openHeight = openHeight;
    BodyCreationSettings bs(new BoxShape(ToJ(half), 0.02f), RVec3(c.x, c.y, c.z), Quat::sIdentity(), EMotionType::Kinematic, Layers::KINEMATIC);
    bs.mUserData = (uint64_t)(uintptr_t)&platformTag;
    g.body = mPhys->bi().CreateAndAddBody(bs, EActivation::Activate);
    mGates.push_back(g);
    return (int)mGates.size() - 1;
}

// ---------------------------------------------------------------- crane
void Interactions::addCrane(const vec3& pivot, float jibLength, float startAngle, float chainLen) {
    Crane c;
    c.pivot = pivot; c.jibLength = jibLength; c.angle = startAngle; c.chainLen = chainLen;
    BodyInterface& bi = mPhys->bi();
    Ref<GroupFilterTable> gf = new GroupFilterTable(16);
    for (int i = 0; i < 16; ++i) for (int j = i + 1; j < 16; ++j) gf->DisableCollision(i, j);
    static int sCraneGroup = 50000;
    int gid = sCraneGroup++;
    vec3 dir(std::sin(startAngle), 0, std::cos(startAngle));
    quat rot = glm::angleAxis(startAngle, vec3(0, 1, 0));
    vec3 jc = pivot + dir * (jibLength * 0.5f - 2.0f);
    BodyCreationSettings js(new BoxShape(Vec3(0.45f, 0.45f, jibLength * 0.5f + 2.0f), 0.05f), RVec3(jc.x, jc.y, jc.z), ToJ(rot), EMotionType::Kinematic, Layers::KINEMATIC);
    js.mCollisionGroup = CollisionGroup(gf, (CollisionGroup::GroupID)gid, 0);
    js.mUserData = (uint64_t)(uintptr_t)&platformTag;
    c.jib = bi.CreateAndAddBody(js, EActivation::Activate);

    const int N = 8;
    float linkLen = c.chainLen / N;
    vec3 tip = pivot + dir * jibLength - vec3(0, 0.5f, 0);
    BodyID prev = c.jib;
    for (int i = 0; i < N; ++i) {
        vec3 lc = tip - vec3(0, (i + 0.5f) * linkLen, 0);
        BodyCreationSettings ls(new CapsuleShape(linkLen * 0.5f - 0.06f, 0.07f), RVec3(lc.x, lc.y, lc.z), Quat::sIdentity(), EMotionType::Dynamic, Layers::MOVING);
        ls.mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
        ls.mMassPropertiesOverride.mMass = 140.0f;
        ls.mCollisionGroup = CollisionGroup(gf, (CollisionGroup::GroupID)gid, (CollisionGroup::SubGroupID)(1 + i));
        ls.mLinearDamping = 0.05f; ls.mAngularDamping = 0.4f;
        BodyID id = bi.CreateAndAddBody(ls, EActivation::Activate);
        c.links.push_back(id);
        vec3 jp = tip - vec3(0, i * linkLen, 0);
        PointConstraintSettings ps;
        ps.mPoint1 = ps.mPoint2 = RVec3(jp.x, jp.y, jp.z);
        ps.mNumVelocityStepsOverride = 20; ps.mNumPositionStepsOverride = 6;
        BodyID pair[2] = {prev, id};
        BodyLockMultiWrite lock(mPhys->sys().GetBodyLockInterface(), pair, 2);
        if (lock.GetBody(0) && lock.GetBody(1)) {
            Ref<Constraint> cs = ps.Create(*lock.GetBody(0), *lock.GetBody(1));
            mPhys->sys().AddConstraint(cs);
            c.joints.push_back(cs);
        }
        prev = id;
    }
    // the wrecking ball
    vec3 bc = tip - vec3(0, c.chainLen + 0.85f, 0);
    BodyCreationSettings bs(new SphereShape(0.85f), RVec3(bc.x, bc.y, bc.z), Quat::sIdentity(), EMotionType::Dynamic, Layers::MOVING);
    bs.mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
    bs.mMassPropertiesOverride.mMass = 2600.0f;
    bs.mMotionQuality = EMotionQuality::LinearCast;
    bs.mCollisionGroup = CollisionGroup(gf, (CollisionGroup::GroupID)gid, 15);
    bs.mRestitution = 0.1f; bs.mFriction = 0.6f;
    c.ball = bi.CreateAndAddBody(bs, EActivation::Activate);
    {
        vec3 jp = tip - vec3(0, c.chainLen, 0);
        PointConstraintSettings ps;
        ps.mPoint1 = ps.mPoint2 = RVec3(jp.x, jp.y, jp.z);
        ps.mNumVelocityStepsOverride = 20; ps.mNumPositionStepsOverride = 6;
        BodyID pair[2] = {prev, c.ball};
        {
            BodyLockMultiWrite lock(mPhys->sys().GetBodyLockInterface(), pair, 2);
            if (lock.GetBody(0) && lock.GetBody(1)) {
                Ref<Constraint> cs = ps.Create(*lock.GetBody(0), *lock.GetBody(1));
                mPhys->sys().AddConstraint(cs);
                c.joints.push_back(cs);
            }
        }
        // rope limit from the jib tip directly to the ball keeps the heavy chain stable
        DistanceConstraintSettings ds;
        ds.mPoint1 = RVec3(tip.x, tip.y, tip.z);
        ds.mPoint2 = RVec3(bc.x, bc.y + 0.85f, bc.z);
        ds.mMinDistance = 0.0f; ds.mMaxDistance = c.chainLen + 0.02f;
        BodyID pair2[2] = {c.jib, c.ball};
        BodyLockMultiWrite lock2(mPhys->sys().GetBodyLockInterface(), pair2, 2);
        if (lock2.GetBody(0) && lock2.GetBody(1)) {
            Ref<Constraint> cs = ds.Create(*lock2.GetBody(0), *lock2.GetBody(1));
            mPhys->sys().AddConstraint(cs);
            c.joints.push_back(cs);
        }
    }
    mCranes.push_back(c);
}

// ---------------------------------------------------------------- per step
void Interactions::prePhysics(float dt) {
    BodyInterface& bi = mPhys->bi();
    for (auto& e : mElevators) {
        float ty = e.floors.empty() ? e.y : e.floors[glm::clamp(e.target, 0, (int)e.floors.size() - 1)];
        float ny = MoveTowards(e.y, ty, e.speed * dt);
        e.moving = std::fabs(ny - e.y) > 1e-5f;
        e.y = ny;
        bi.MoveKinematic(e.body, RVec3(e.base.x, e.y, e.base.z), Quat::sIdentity(), dt);
    }
    for (auto& g : mGates) {
        float nt = MoveTowards(g.t, g.open ? 1.0f : 0.0f, dt * 0.35f);
        vec3 p = g.closed + vec3(0, g.openHeight * nt, 0);
        g.t = nt;
        bi.MoveKinematic(g.body, RVec3(p.x, p.y, p.z), Quat::sIdentity(), dt);
    }
    for (auto& c : mCranes) {
        c.targetSpeed = c.running ? 0.22f : 0.0f;
        c.speed = MoveTowards(c.speed, c.targetSpeed, dt * 0.08f);
        c.angle += c.speed * dt;
        vec3 dir(std::sin(c.angle), 0, std::cos(c.angle));
        vec3 jc = c.pivot + dir * (c.jibLength * 0.5f - 2.0f);
        bi.MoveKinematic(c.jib, RVec3(jc.x, jc.y, jc.z), ToJ(glm::angleAxis(c.angle, vec3(0, 1, 0))), dt);
        if (c.speed > 0) for (auto& l : c.links) bi.ActivateBody(l);
    }
}

void Interactions::update(float dt, Destruction* destr) {
    BodyInterface& bi = mPhys->bi();
    // door hinges break from excessive force or when the frame is destroyed
    for (auto& up : mObjs->objects()) {
        VoxelObject* o = up.get();
        if (!o->alive || !o->hinge || o->hingeBreakImpulse <= 0) continue;
        auto* h = static_cast<HingeConstraint*>(o->hinge.GetPtr());
        float lambda = h->GetTotalLambdaPosition().Length();
        bool anchorGone = o->hingeAnchorVoxel.x >= 0 && mWorld->get(o->hingeAnchorVoxel) == M_AIR &&
                          mWorld->get(o->hingeAnchorVoxel + ivec3(0, 2, 0)) == M_AIR;
        if (lambda > o->hingeBreakImpulse || anchorGone) {
            mPhys->sys().RemoveConstraint(o->hinge);
            o->hinge = nullptr;
            o->flags &= ~OBJ_NO_SPLIT;
            bi.ActivateBody(o->body);
            GAudio().play(SND_WOOD_BREAK, vec3(o->transform[3]), 0.8f, 0.9f);
        }
    }
    // elevator motor hum
    for (auto& e : mElevators) {
        vec3 p(e.base.x, e.y, e.base.z);
        if (e.moving) {
            if (!GAudio().playing(e.voice)) e.voice = GAudio().play(SND_HUM, p, 0.45f, 1.0f, true, true);
            else GAudio().setVoice(e.voice, p, 0.45f, 1.0f);
        } else if (e.voice) { GAudio().stop(e.voice); e.voice = 0; }
    }
    for (auto& g : mGates) {
        bool moving = (g.open && g.t < 1.0f) || (!g.open && g.t > 0.0f);
        vec3 p = g.closed + vec3(0, g.openHeight * g.t, 0);
        if (moving) {
            if (!GAudio().playing(g.voice)) g.voice = GAudio().play(SND_HUM, p, 0.6f, 0.7f, true, true);
            else GAudio().setVoice(g.voice, p, 0.6f, 0.7f);
        } else if (g.voice) { GAudio().stop(g.voice); g.voice = 0; GAudio().play(SND_METAL_HEAVY, p, 0.5f, 0.8f); }
    }
    // weight puzzle plates
    std::vector<BodyID> ids;
    for (auto& p : mPlates) {
        ids.clear();
        mPhys->bodiesInBox(p.center - p.half, p.center + p.half + vec3(0, 1.6f, 0), ids);
        float load = 0;
        for (auto id : ids) {
            if (bi.GetMotionType(id) != EMotionType::Dynamic) continue;
            vec3 c = ToG(Vec3(bi.GetCenterOfMassPosition(id)));
            if (c.x < p.center.x - p.half.x || c.x > p.center.x + p.half.x || c.z < p.center.z - p.half.z || c.z > p.center.z + p.half.z) continue;
            if (c.y > p.center.y + 3.0f) continue;
            load += mPhys->massOf(id);
        }
        p.load = Lerp(p.load, load, std::min(1.0f, dt * 4.0f));
        if (!p.solved && p.load >= p.threshold) {
            p.solved = true;
            GAudio().play2D(SND_SWITCH, 1.0f, 0.8f);
            GAudio().play(SND_HORN, p.center, 0.6f, 1.5f);
            if (p.gate >= 0 && p.gate < (int)mGates.size()) mGates[p.gate].open = true;
        }
    }
    for (auto& s : mSwitches) s.anim = MoveTowards(s.anim, s.state ? 1.0f : 0.0f, dt * 6.0f);
    (void)destr;
}

// ---------------------------------------------------------------- use
int Interactions::findSwitch(const vec3& eye, const vec3& dir, float maxDist) const {
    int best = -1;
    float bestScore = 1e9f;
    for (size_t i = 0; i < mSwitches.size(); ++i) {
        vec3 d = mSwitches[i].pos - eye;
        float dist = glm::length(d);
        if (dist > maxDist) continue;
        float c = glm::dot(d / std::max(dist, 1e-3f), dir);
        if (c < 0.75f && dist > 1.3f) continue;
        float score = dist * (2.0f - c);
        if (score < bestScore) { bestScore = score; best = (int)i; }
    }
    return best;
}

void Interactions::activate(int idx) {
    if (idx < 0 || idx >= (int)mSwitches.size()) return;
    Switch& s = mSwitches[idx];
    GAudio().play(SND_SWITCH, s.pos, 0.8f, 1.0f);
    switch (s.action) {
    case SW_ELEVATOR:
        if (s.target < (int)mElevators.size()) {
            Elevator& e = mElevators[s.target];
            int n = std::max<int>(1, (int)e.floors.size());
            if (s.param == -1) e.target = std::min(n - 1, e.target + 1);        // up
            else if (s.param == -2) e.target = std::max(0, e.target - 1);       // down
            else e.target = glm::clamp(s.param, 0, n - 1);                      // call to this floor
            s.state = true;
        }
        break;
    case SW_GATE:
        if (s.target < (int)mGates.size()) { mGates[s.target].open = !mGates[s.target].open; s.state = mGates[s.target].open; }
        break;
    case SW_LIGHTS:
        if (s.target < (int)mLights.size()) { mLights[s.target].on = !mLights[s.target].on; s.state = mLights[s.target].on; }
        break;
    case SW_CRANE:
        if (s.target < (int)mCranes.size()) { mCranes[s.target].running = !mCranes[s.target].running; s.state = mCranes[s.target].running; }
        break;
    case SW_CRANE_DROP:
        if (s.target < (int)mCranes.size()) {
            Crane& c = mCranes[s.target];
            if (!c.dropped && c.joints.size() >= 2) {
                // release the ball: remove last chain joint and the rope limit
                for (size_t k = c.joints.size() - 2; k < c.joints.size(); ++k) mPhys->sys().RemoveConstraint(c.joints[k]);
                c.joints.resize(c.joints.size() - 2);
                c.dropped = true;
                s.state = true;
                GAudio().play(SND_METAL_HEAVY, s.pos, 0.8f, 1.2f);
            }
        }
        break;
    }
}

bool Interactions::useDoor(const vec3& eye, const vec3& dir) {
    RayHit h;
    if (!mPhys->raycast(eye, dir, 2.5f, h)) return false;
    if (!h.tag || h.tag->type != TagType::VoxelObject) return false;
    VoxelObject* o = (VoxelObject*)h.tag->ptr;
    if (!(o->flags & OBJ_DOOR)) return false;
    mPhys->bi().AddImpulse(o->body, ToJ(dir * 260.0f), RVec3(h.point.x, h.point.y, h.point.z));
    GAudio().play(SND_DOOR, h.point, 0.7f, GRng().range(0.9f, 1.1f));
    return true;
}

std::string Interactions::plateStatus(const vec3& p) const {
    for (auto& pl : mPlates) {
        if (glm::distance(vec2(p.x, p.z), vec2(pl.center.x, pl.center.z)) < 9.0f) {
            char buf[160];
            if (pl.solved) snprintf(buf, sizeof(buf), "%s: SOLVED - vault open", pl.name.c_str());
            else snprintf(buf, sizeof(buf), "%s: %.0f / %.0f kg on the plate", pl.name.c_str(), pl.load, pl.threshold);
            return buf;
        }
    }
    return "";
}

// ---------------------------------------------------------------- rendering
void Interactions::render(Renderer& r) {
    BodyInterface& bi = mPhys->bi();
    for (auto& e : mElevators) {
        mat4 m = glm::translate(mat4(1), vec3(e.base.x, e.y, e.base.z)) * glm::scale(mat4(1), e.half * 2.0f);
        r.drawInstance(MESH_CUBE, m, vec4(0.42f, 0.44f, 0.47f, 1), vec4(0.35f, 0.9f, 0, 5));
        // guard rails
        for (int s = -1; s <= 1; s += 2) {
            mat4 rail = glm::translate(mat4(1), vec3(e.base.x + s * (e.half.x - 0.04f), e.y + 0.55f, e.base.z)) * glm::scale(mat4(1), vec3(0.06f, 0.06f, e.half.z * 2.0f));
            r.drawInstance(MESH_CUBE, rail, vec4(0.9f, 0.75f, 0.1f, 1), vec4(0.4f, 0.6f, 0, 0));
        }
    }
    for (auto& g : mGates) {
        vec3 p = g.closed + vec3(0, g.openHeight * g.t, 0);
        r.drawInstance(MESH_CUBE, glm::translate(mat4(1), p) * glm::scale(mat4(1), g.half * 2.0f), g.color, vec4(0.45f, 0.85f, 0, 14));
    }
    for (auto& p : mPlates) {
        float k = Saturate(p.load / p.threshold);
        vec3 col = p.solved ? vec3(0.1f, 0.85f, 0.2f) : glm::mix(vec3(0.85f, 0.1f, 0.08f), vec3(0.95f, 0.8f, 0.1f), k);
        r.drawInstance(MESH_CUBE, glm::translate(mat4(1), p.center) * glm::scale(mat4(1), vec3(p.half.x * 2, 0.06f, p.half.z * 2)), vec4(col, 1), vec4(0.4f, 0.3f, 0.6f, 0));
    }
    for (auto& s : mSwitches) {
        quat q = glm::rotation(vec3(0, 0, 1), glm::normalize(s.normal));
        mat4 base = glm::translate(mat4(1), s.pos) * glm::mat4_cast(q);
        r.drawInstance(MESH_CUBE, base * glm::scale(mat4(1), vec3(0.22f, 0.3f, 0.05f)), vec4(0.85f, 0.85f, 0.82f, 1), vec4(0.5f, 0, 0, 0));
        vec3 col = s.state ? vec3(0.1f, 0.9f, 0.2f) : vec3(0.9f, 0.15f, 0.1f);
        r.drawInstance(MESH_CUBE, base * glm::translate(mat4(1), vec3(0, (s.anim - 0.5f) * 0.12f, 0.04f)) * glm::scale(mat4(1), vec3(0.08f, 0.1f, 0.06f)), vec4(col, 1), vec4(0.3f, 0, 1.2f, 0));
    }
    for (auto& c : mCranes) {
        mat4 J = ToG(bi.GetWorldTransform(c.jib));
        float L = c.jibLength * 0.5f + 2.0f;
        const vec4 yel(0.95f, 0.72f, 0.06f, 1);
        // lattice jib: top and bottom chords plus diagonals
        for (int sx = -1; sx <= 1; sx += 2)
            for (int sy = -1; sy <= 1; sy += 2)
                r.drawInstance(MESH_CUBE, J * glm::translate(mat4(1), vec3(sx * 0.4f, sy * 0.4f, 0)) * glm::scale(mat4(1), vec3(0.1f, 0.1f, L * 2)), yel, vec4(0.45f, 0.6f, 0, 0));
        for (float z = -L; z < L; z += 1.2f) {
            mat4 d = J * glm::translate(mat4(1), vec3(0, 0, z + 0.6f)) * glm::mat4_cast(glm::angleAxis(0.785f, vec3(1, 0, 0))) * glm::scale(mat4(1), vec3(0.82f, 0.07f, 1.1f));
            r.drawInstance(MESH_CUBE, d, yel, vec4(0.45f, 0.6f, 0, 0), false);
        }
        // counterweight + cab
        r.drawInstance(MESH_CUBE, J * glm::translate(mat4(1), vec3(0, -0.2f, -L + 1.2f)) * glm::scale(mat4(1), vec3(1.6f, 1.4f, 2.0f)), vec4(0.4f, 0.4f, 0.42f, 1), vec4(0.8f, 0, 0, 1));
        for (auto& l : c.links) {
            RVec3 p; Quat q;
            bi.GetPositionAndRotation(l, p, q);
            vec3 cpos = ToG(Vec3(p));
            vec3 ax = ToG(q) * vec3(0, c.chainLen / 8 * 0.5f - 0.06f, 0);
            r.drawCapsule(cpos - ax, cpos + ax, 0.07f, vec4(0.25f, 0.25f, 0.27f, 1), vec4(0.4f, 1.0f, 0, 0));
        }
        vec3 bp = ToG(Vec3(bi.GetPosition(c.ball)));
        r.drawInstance(MESH_SPHERE, glm::translate(mat4(1), bp) * glm::mat4_cast(ToG(bi.GetRotation(c.ball))) * glm::scale(mat4(1), vec3(1.7f)), vec4(0.18f, 0.18f, 0.2f, 1), vec4(0.45f, 1.0f, 0, 5));
    }
}

void Interactions::collectLights(std::vector<PointLight>& out, float night, const vec3& cam) {
    for (auto& g : mLights) {
        if (!g.on) continue;
        float k = g.nightOnly ? SmoothStep(0.25f, 0.6f, night) : (0.35f + 0.65f * night);
        if (k <= 0.01f) continue;
        for (auto& v : g.lampVoxels) {
            vec3 p = VoxelWorld::voxelCenter(v);
            if (glm::distance2(p, cam) > 60.0f * 60.0f) continue;
            if (mWorld->get(v) != M_LIGHT) continue;   // lamp destroyed
            out.push_back({p - vec3(0, 0.4f, 0), g.radius, g.color * (1.6f * k)});
        }
    }
}
