#include "gameplay/Player.h"
#include "destruction/Destruction.h"
#include "engine/Audio.h"

#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Collision/Shape/RotatedTranslatedShape.h>
#include <Jolt/Physics/Body/BodyFilter.h>
#include <Jolt/Physics/Collision/ShapeFilter.h>

using namespace JPH;

void Player::init(PhysicsWorld* phys, const vec3& feetPos, float y) {
    mPhys = phys;
    yaw = y; pitch = 0;
    spawnPoint = feetPos;
    float half = 0.5f * HEIGHT - RADIUS;
    RefConst<Shape> capsule = RotatedTranslatedShapeSettings(Vec3(0, 0.5f * HEIGHT, 0), Quat::sIdentity(), new CapsuleShape(half, RADIUS)).Create().Get();
    RefConst<Shape> inner = RotatedTranslatedShapeSettings(Vec3(0, 0.5f * HEIGHT, 0), Quat::sIdentity(), new CapsuleShape(half * 0.9f, RADIUS * 0.9f)).Create().Get();
    Ref<CharacterVirtualSettings> s = new CharacterVirtualSettings();
    s->mShape = capsule;
    s->mInnerBodyShape = inner;
    s->mInnerBodyLayer = Layers::MOVING;
    s->mMaxSlopeAngle = DegreesToRadians(50.0f);
    s->mMass = 80.0f;
    s->mMaxStrength = 260.0f;     // how hard the player can push props
    s->mCharacterPadding = 0.02f;
    s->mPenetrationRecoverySpeed = 1.0f;
    s->mPredictiveContactDistance = 0.1f;
    s->mSupportingVolume = Plane(Vec3::sAxisY(), -RADIUS);
    s->mEnhancedInternalEdgeRemoval = true;
    mChar = new CharacterVirtual(s, RVec3(feetPos.x, feetPos.y, feetPos.z), Quat::sIdentity(), 0, &phys->sys());
    mInner = mChar->GetInnerBodyID();
    mFeet = feetPos;
}

void Player::shutdown() { mChar = nullptr; }

vec3 Player::forward() const {
    return vec3(std::sin(yaw) * std::cos(pitch), std::sin(pitch), std::cos(yaw) * std::cos(pitch));
}
vec3 Player::flatForward() const { return vec3(std::sin(yaw), 0, std::cos(yaw)); }
vec3 Player::right() const { return vec3(-std::cos(yaw), 0, std::sin(yaw)); }

void Player::look(float dYaw, float dPitch) {
    yaw += dYaw;
    pitch = glm::clamp(pitch + dPitch, -1.5f, 1.5f);
    if (yaw > 3.14159265f) yaw -= 6.2831853f;
    if (yaw < -3.14159265f) yaw += 6.2831853f;
}

void Player::teleport(const vec3& f) {
    mFeet = f;
    mVel = vec3(0);
    mChar->SetPosition(RVec3(f.x, f.y, f.z));
    mChar->SetLinearVelocity(Vec3::sZero());
    mPhys->bi().SetPosition(mInner, RVec3(f.x, f.y, f.z), EActivation::DontActivate);
}

void Player::park() {
    vec3 p(mFeet.x, -400.0f, mFeet.z);
    mChar->SetPosition(RVec3(p.x, p.y, p.z));
    mChar->SetLinearVelocity(Vec3::sZero());
    mPhys->bi().SetPosition(mInner, RVec3(p.x, p.y, p.z), EActivation::DontActivate);
}

void Player::damage(float amount) {
    health -= amount;
    hurtFlash = std::min(1.0f, hurtFlash + amount / 40.0f);
}

void Player::update(float dt, const vec2& move, bool jump, bool sprint, Destruction* destr) {
    hurtFlash = std::max(0.0f, hurtFlash - dt * 0.8f);
    if (health < 100.0f && health > 0) health = std::min(100.0f, health + dt * 4.0f);
    vec3 wishDir = flatForward() * move.y + right() * move.x;
    float wishLen = glm::length(wishDir);
    if (wishLen > 1.0f) wishDir /= wishLen;
    float speed = sprint ? speedSprint : speedWalk;

    if (noclip) {
        vec3 fly = forward() * move.y + right() * move.x + vec3(0, jump ? 1.0f : 0.0f, 0);
        mFeet += fly * speed * 2.0f * dt;
        teleport(mFeet);
        return;
    }

    mChar->UpdateGroundVelocity();
    Vec3 gravity = ToJ(mPhys->gravity());
    Vec3 curVel = mChar->GetLinearVelocity();
    Vec3 vertical = Vec3(0, curVel.GetY(), 0);
    Vec3 groundVel = mChar->GetGroundVelocity();
    bool grounded = mChar->GetGroundState() == CharacterBase::EGroundState::OnGround;
    Vec3 newVel;
    Vec3 desired = ToJ(wishDir * speed);
    if (grounded && (vertical.GetY() - groundVel.GetY()) < 0.1f) {
        newVel = groundVel;
        if (jump) {
            newVel += Vec3(0, jumpSpeed, 0);
            GAudio().play(SND_STEP_CONCRETE, mFeet, 0.5f, 0.8f);
        }
        newVel += desired;
    } else {
        // air control: keep momentum, steer gently
        Vec3 horiz(curVel.GetX(), 0, curVel.GetZ());
        horiz += (desired - horiz) * std::min(1.0f, dt * 2.0f);
        newVel = vertical + horiz;
    }
    newVel += gravity * dt;
    mChar->SetLinearVelocity(newVel);

    CharacterVirtual::ExtendedUpdateSettings eus;
    eus.mStickToFloorStepDown = Vec3(0, -0.4f, 0);
    eus.mWalkStairsStepUp = Vec3(0, 0.55f, 0);   // voxel steps are 0.25m; allow two-voxel steps
    IgnoreSingleBodyFilter bodyFilter(mInner);
    ShapeFilter shapeFilter;
    mChar->ExtendedUpdate(dt, gravity, eus,
                          mPhys->sys().GetDefaultBroadPhaseLayerFilter(Layers::MOVING),
                          mPhys->sys().GetDefaultLayerFilter(Layers::MOVING),
                          bodyFilter, shapeFilter, mPhys->temp());

    RVec3 p = mChar->GetPosition();
    mFeet = vec3((float)p.GetX(), (float)p.GetY(), (float)p.GetZ());
    mVel = ToG(mChar->GetLinearVelocity());
    bool wasGround = mOnGround;
    mOnGround = mChar->GetGroundState() == CharacterBase::EGroundState::OnGround;

    // landing + fall damage
    if (!mOnGround) { mAirTime += dt; mFallSpeed = std::max(mFallSpeed, -mVel.y); }
    if (mOnGround && !wasGround) {
        if (mAirTime > 0.25f) GAudio().play(SND_LAND, mFeet, Saturate(mFallSpeed / 10.0f), 1.0f);
        if (mFallSpeed > 13.0f) damage((mFallSpeed - 13.0f) * 9.0f);
        mAirTime = 0; mFallSpeed = 0;
    }
    if (mFeet.y < -20.0f) { teleport(spawnPoint); }

    // footsteps vary by the surface material under the player
    float hspeed = glm::length(vec2(mVel.x - groundVel.GetX(), mVel.z - groundVel.GetZ()));
    if (mOnGround && hspeed > 0.6f) {
        mStepAccum += hspeed * dt;
        mBobPhase += hspeed * dt * 2.3f;
        mBob = std::sin(mBobPhase * 2.0f) * 0.035f * Saturate(hspeed / 4.0f);
        float stride = sprint ? 0.95f : 0.75f;
        if (mStepAccum > stride) {
            mStepAccum = 0;
            uint8_t mat = M_CONCRETE;
            if (destr) mat = destr->materialNear(mFeet - vec3(0, 0.12f, 0), mPhys->tagOf(mChar->GetGroundBodyID()));
            SoundId snd = SND_STEP_CONCRETE;
            switch (MatInfo(mat).sound) {
            case SoundClass::Wood: snd = SND_STEP_WOOD; break;
            case SoundClass::Metal: snd = SND_STEP_METAL; break;
            case SoundClass::Dirt: snd = SND_STEP_DIRT; break;
            case SoundClass::Soft: snd = SND_STEP_SOFT; break;
            default: break;
            }
            GAudio().play(snd, mFeet, sprint ? 0.55f : 0.38f, GRng().range(0.9f, 1.1f));
        }
    } else {
        mBob *= std::max(0.0f, 1.0f - dt * 8.0f);
    }
}
