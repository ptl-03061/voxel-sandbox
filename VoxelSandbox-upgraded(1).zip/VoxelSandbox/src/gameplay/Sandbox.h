// Sandbox tools: physics hand (grab, throw, rotate, scale, duplicate, delete, freeze), sledgehammer,
// cannon, timed bombs, rockets and the object spawner.
#pragma once
#include "destruction/Destruction.h"
#include "physics/Constraints.h"
#include "gameplay/Npc.h"
#include "gameplay/Props.h"
#include "gameplay/Vehicle.h"

enum Tool { TOOL_HAND, TOOL_HAMMER, TOOL_CANNON, TOOL_BOMB, TOOL_ROCKET, TOOL_SPAWN,
            TOOL_ROPE, TOOL_UNROPE, TOOL_FREEZE, TOOL_WELD, TOOL_COUNT };
const char* ToolName(int t);

enum class SpawnKind { Prop, Vehicle, Npc, Bomb };
struct SpawnItem { std::string name, category; SpawnKind kind; int id; };

struct Projectile {
    int type = 0;            // 0 cannonball, 1 bomb, 2 rocket
    JPH::BodyID body;
    PhysTag tag;
    float life = 0, fuse = 0;
    bool explode = false, dead = false;
};

class Sandbox {
public:
    void setConstraints(ConstraintManager* c) { mConstraints = c; }
    void init(PhysicsWorld* phys, ObjectManager* objs, Destruction* destr, VehicleManager* veh, NpcManager* npcs, Particles* parts);
    void clear();

    int tool = TOOL_HAND;
    int spawnIndex = 0;
    std::vector<SpawnItem> catalog;
    std::vector<std::string> categories;

    // actions (from UI buttons)
    void useTool(const vec3& eye, const vec3& dir);       // primary fire
    bool grabToggle(const vec3& eye, const vec3& dir);
    void throwHeld(const vec3& dir);
    void rotateHeld(float dx, float dy);
    void scaleTarget(const vec3& eye, const vec3& dir, float factor);
    void duplicateTarget(const vec3& eye, const vec3& dir);
    void deleteTarget(const vec3& eye, const vec3& dir);
    void freezeTarget(const vec3& eye, const vec3& dir);
    void changeHoldDistance(float d) { mHoldDist = glm::clamp(mHoldDist + d, 1.2f, 14.0f); }
    void spawnSelected(const vec3& eye, const vec3& dir);
    void spawnItem(int index, const vec3& pos, float yaw);

    void prePhysics(float dt, const vec3& eye, const vec3& dir, float camYaw);
    void update(float dt);
    void render(Renderer& r);
    void onContact(PhysTag* a, PhysTag* b);

    bool holding() const { return !mHeld.IsInvalid(); }
    std::string targetInfo(const vec3& eye, const vec3& dir);
    int projectileCount() const { return (int)mProjectiles.size(); }
    float hammerCooldown() const { return mCooldown; }
    JPH::BodyID ignoreBody;   // player inner body

private:
    bool aim(const vec3& eye, const vec3& dir, float maxDist, RayHit& hit);
    void fireProjectile(int type, const vec3& eye, const vec3& dir);
    void release();

    PhysicsWorld* mPhys = nullptr;
    ObjectManager* mObjs = nullptr;
    Destruction* mDestr = nullptr;
    VehicleManager* mVeh = nullptr;
    NpcManager* mNpcs = nullptr;
    Particles* mParts = nullptr;
    ConstraintManager* mConstraints = nullptr;
    JPH::BodyID mWeldA;
    std::vector<std::unique_ptr<Projectile>> mProjectiles;
    JPH::BodyID mHeld;
    vec3 mGrabLocal{0};
    quat mRelRot{1, 0, 0, 0};
    float mHoldDist = 3.0f;
    float mCooldown = 0;
    vec3 mHoldTarget{0};
    vec3 mBeamFrom{0};
};
