// Library of destructible voxel props (furniture, crates, barrels, construction materials...).
#pragma once
#include "destruction/VoxelObject.h"

enum PropType {
    PROP_CRATE, PROP_BARREL, PROP_CHAIR, PROP_TABLE, PROP_SOFA, PROP_BED, PROP_SHELF, PROP_FRIDGE,
    PROP_GLASS_PANE, PROP_CONCRETE_BLOCK, PROP_BRICK_PILE, PROP_STEEL_BEAM, PROP_PLANK, PROP_PALLET,
    PROP_CONE, PROP_BENCH, PROP_TRASHCAN, PROP_WALL_SECTION, PROP_TV, PROP_LAMP, PROP_BOOKCASE,
    PROP_DESK, PROP_WOOD_TOWER, PROP_GLASS_TOWER, PROP_BIG_BALL, PROP_COUNT
};

struct PropDef {
    const char* name;
    const char* category;   // Furniture / Construction / Physics
};

const PropDef& GetPropDef(int type);
VoxelModel BuildProp(int type);
