// Interactive world objects: hinged breakable doors, elevators, sliding gates, switches, a weight puzzle,
// a crane with a wrecking ball on a physical chain, seesaws and destructible lamps.
#pragma once
#include "destruction/VoxelObject.h"
#include "destruction/VoxelWorld.h"
#include "engine/Renderer.h"

class Destruction;

enum SwitchAction { SW_ELEVATOR, SW_GATE, SW_LIGHTS, SW_CRANE, SW_CRANE_DROP };

struct Switch {
    vec3 pos, normal;
    std::string label;
    SwitchAction action;
    int target = 0;      // elevator / gate / light group index
    int param = 0;       // elevator floor
    bool state = false;
    float anim = 0;
};

struct Elevator {
    JPH::BodyID body;
    vec3 base;           // platform center at floor 0
    vec3 half;
    std::vector<float> floors;   // platform center heights
    int target = 0;
    float y = 0;
    float speed = 1.6f;
    uint32_t voice = 0;
    bool moving = false;
};

struct Gate {
    JPH::BodyID body;
    vec3 closed, half;
    float openHeight = 3.0f;
    float t = 0;          // 0 closed .. 1 open
    bool open = false;
    vec4 color{0.55f, 0.57f, 0.6f, 1};
    uint32_t voice = 0;
};

struct PressurePlate {
    vec3 center, half;
    float threshold = 300.0f;
    int gate = -1;
    float load = 0;
    bool solved = false;
    std::string name;
};

struct LightGroup {
    std::vector<ivec3> lampVoxels;   // M_LIGHT voxel positions (light dies if voxel destroyed)
    vec3 color{1.0f, 0.85f, 0.6f};
    float radius = 7.0f;
    bool on = true;
    bool nightOnly = false;
};

struct Crane {
    vec3 pivot;            // top of tower
    float jibLength = 16.0f;
    float angle = 0, speed = 0, targetSpeed = 0;
    bool running = false;
    JPH::BodyID jib, ball;
    std::vector<JPH::BodyID> links;
    std::vector<JPH::Ref<JPH::Constraint>> joints;
    float chainLen = 8.0f;
    bool dropped = false;
};

class Interactions {
public:
    void init(PhysicsWorld* phys, VoxelWorld* world, ObjectManager* objs);
    void clear();

    VoxelObject* addDoor(const vec3& hingeBottom, float yaw, int widthVox, int heightVox, uint8_t mat, bool glassWindow, float breakImpulse);
    int addElevator(const vec3& base, const vec3& half, const std::vector<float>& floors);
    int addGate(const vec3& closedCenter, const vec3& half, float openHeight);
    int addLightGroup(const LightGroup& g) { mLights.push_back(g); return (int)mLights.size() - 1; }
    int addSwitch(const Switch& s) { mSwitches.push_back(s); return (int)mSwitches.size() - 1; }
    int addPlate(const PressurePlate& p) { mPlates.push_back(p); return (int)mPlates.size() - 1; }
    void addCrane(const vec3& pivot, float jibLength, float startAngle, float chainLen = 13.0f);
    VoxelObject* addSeesaw(const vec3& pivot, float yaw);

    void prePhysics(float dt);
    void update(float dt, Destruction* destr);
    void render(Renderer& r);
    void collectLights(std::vector<PointLight>& out, float night, const vec3& cam);

    int findSwitch(const vec3& eye, const vec3& dir, float maxDist) const;
    void activate(int sw);
    // push a door near the given point; returns true if one was nudged
    bool useDoor(const vec3& eye, const vec3& dir);
    std::string plateStatus(const vec3& p) const;

    std::vector<Switch>& switches() { return mSwitches; }
    std::vector<Elevator>& elevators() { return mElevators; }
    std::vector<Gate>& gates() { return mGates; }
    std::vector<Crane>& cranes() { return mCranes; }
    PhysTag platformTag;
    int puzzlesSolved() const { int n = 0; for (auto& p : mPlates) n += p.solved; return n; }
    int puzzleCount() const { return (int)mPlates.size(); }

private:
    PhysicsWorld* mPhys = nullptr;
    VoxelWorld* mWorld = nullptr;
    ObjectManager* mObjs = nullptr;
    std::vector<Switch> mSwitches;
    std::vector<Elevator> mElevators;
    std::vector<Gate> mGates;
    std::vector<PressurePlate> mPlates;
    std::vector<LightGroup> mLights;
    std::vector<Crane> mCranes;
    std::vector<VoxelObject*> mDoors;
    std::vector<int> mDoorIds;
};
