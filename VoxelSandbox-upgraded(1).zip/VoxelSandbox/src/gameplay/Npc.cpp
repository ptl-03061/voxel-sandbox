#include "gameplay/Npc.h"
#include "engine/Audio.h"

#include <Jolt/Physics/Collision/Shape/CapsuleShape.h>
#include <Jolt/Physics/Constraints/HingeConstraint.h>
#include <Jolt/Physics/Constraints/SwingTwistConstraint.h>
#include <Jolt/Physics/Body/BodyLock.h>

using namespace JPH;

// part dimensions: capsule radius / half height of the cylinder section
static const float kRadius[NP_COUNT] = {0.13f, 0.15f, 0.12f, 0.055f, 0.05f, 0.055f, 0.05f, 0.075f, 0.065f, 0.075f, 0.065f};
static const float kHalf[NP_COUNT]   = {0.05f, 0.12f, 0.03f, 0.10f, 0.10f, 0.10f, 0.10f, 0.15f, 0.14f, 0.15f, 0.14f};
static constexpr float THIGH = 0.45f, SHIN = 0.40f, UARM = 0.30f, LARM = 0.30f;

static inline quat Rx(float a) { return glm::angleAxis(a, vec3(1, 0, 0)); }

void Npc::computePose(NpcPose& o, const vec3& root, float yaw, float w, float phase, float crouch, float lean, float armsUp) const {
    quat Q = glm::angleAxis(yaw, vec3(0, 1, 0));
    auto W = [&](const vec3& l) { return root + Q * l; };
    // legs
    float aL1 = -0.5f * w * std::sin(phase) - crouch * 1.45f;
    float aL2 = 0.9f * w * std::max(0.0f, std::cos(phase)) + crouch * 2.3f;
    float aR1 = -0.5f * w * std::sin(phase + 3.14159f) - crouch * 1.45f;
    float aR2 = 0.9f * w * std::max(0.0f, std::cos(phase + 3.14159f)) + crouch * 2.3f;
    float lenL = THIGH * std::cos(aL1) + SHIN * std::cos(aL1 + aL2);
    float lenR = THIGH * std::cos(aR1) + SHIN * std::cos(aR1 + aR2);
    float hipY = 0.06f + std::max(lenL, lenR);
    float totalLean = lean + crouch * 0.55f;
    quat Rl = Rx(totalLean);
    vec3 pelvis(0, hipY + 0.06f, 0);
    quat Rp = Rx(totalLean * 0.5f);
    vec3 j0 = pelvis + Rp * vec3(0, 0.06f, 0);
    vec3 torso = j0 + Rl * vec3(0, 0.26f, 0);
    vec3 j1 = torso + Rl * vec3(0, 0.30f, 0);
    vec3 head = j1 + Rl * vec3(0, 0.13f, 0);
    o.pos[NP_PELVIS] = W(pelvis); o.rot[NP_PELVIS] = Q * Rp;
    o.pos[NP_TORSO] = W(torso);   o.rot[NP_TORSO] = Q * Rl;
    o.pos[NP_HEAD] = W(head);     o.rot[NP_HEAD] = Q * Rl;
    o.joints[0] = W(j0); o.joints[1] = W(j1);
    // arms
    for (int side = 0; side < 2; ++side) {
        float sx = side == 0 ? 0.24f : -0.24f;
        float ph = side == 0 ? phase : phase + 3.14159f;
        float a1 = 0.45f * w * std::sin(ph) - armsUp * 2.4f + crouch * -0.6f;
        float a2 = -0.35f - 0.3f * w - armsUp * 0.4f;
        vec3 sh = torso + Rl * vec3(sx, 0.20f, 0);
        quat Ru = Rl * Rx(a1) * glm::angleAxis((side == 0 ? 1.0f : -1.0f) * (0.08f + armsUp * 0.5f), vec3(0, 0, 1));
        vec3 el = sh + Ru * vec3(0, -UARM, 0);
        quat Rf = Ru * Rx(a2);
        int up = side == 0 ? NP_UARM_L : NP_UARM_R, lo = up + 1;
        o.pos[up] = W(sh + Ru * vec3(0, -UARM * 0.5f, 0)); o.rot[up] = Q * Ru;
        o.pos[lo] = W(el + Rf * vec3(0, -LARM * 0.5f, 0)); o.rot[lo] = Q * Rf;
        o.joints[2 + side * 2] = W(sh); o.joints[3 + side * 2] = W(el);
    }
    // legs
    for (int side = 0; side < 2; ++side) {
        float a1 = side == 0 ? aL1 : aR1, a2 = side == 0 ? aL2 : aR2;
        vec3 hip(side == 0 ? 0.1f : -0.1f, hipY, 0);
        quat Rt = Rx(a1);
        vec3 knee = hip + Rt * vec3(0, -THIGH, 0);
        quat Rs = Rx(a1 + a2);
        int up = side == 0 ? NP_THIGH_L : NP_THIGH_R, lo = up + 1;
        o.pos[up] = W(hip + Rt * vec3(0, -THIGH * 0.5f, 0)); o.rot[up] = Q * Rt;
        o.pos[lo] = W(knee + Rs * vec3(0, -SHIN * 0.5f, 0)); o.rot[lo] = Q * Rs;
        o.joints[6 + side * 2] = W(hip); o.joints[7 + side * 2] = W(knee);
    }
}

bool Npc::create(PhysicsWorld* phys, GroupFilterTable* filter, int group, const vec3& feet, float yaw, const vec3& shirt) {
    mPhys = phys;
    mRoot = feet; mYaw = yaw; home = feet; mShirt = shirt;
    tag.type = TagType::RagdollPart; tag.ptr = this;
    for (int i = 0; i < NP_COUNT; ++i) { mRadius[i] = kRadius[i]; mHalf[i] = kHalf[i]; }
    NpcPose pose;
    computePose(pose, feet, yaw, 0, 0, 0, 0, 0);
    BodyInterface& bi = phys->bi();
    for (int i = 0; i < NP_COUNT; ++i) {
        BodyCreationSettings bs(new CapsuleShape(kHalf[i], kRadius[i]), RVec3(pose.pos[i].x, pose.pos[i].y, pose.pos[i].z), ToJ(pose.rot[i]), EMotionType::Kinematic, Layers::RAGDOLL);
        bs.mAllowDynamicOrKinematic = true;
        bs.mCollisionGroup = CollisionGroup(filter, (CollisionGroup::GroupID)group, (CollisionGroup::SubGroupID)i);
        bs.mFriction = 0.8f;
        bs.mRestitution = 0.05f;
        bs.mLinearDamping = 0.15f;
        bs.mAngularDamping = 0.9f;
        bs.mMotionQuality = EMotionQuality::LinearCast;
        bs.mUserData = (uint64_t)(uintptr_t)&tag;
        bs.mOverrideMassProperties = EOverrideMassProperties::CalculateInertia;
        static const float kMass[NP_COUNT] = {12, 22, 6, 2.5f, 1.8f, 2.5f, 1.8f, 8, 4.5f, 8, 4.5f};
        bs.mMassPropertiesOverride.mMass = kMass[i];
        mBodies[i] = bi.CreateAndAddBody(bs, EActivation::Activate);
        if (mBodies[i].IsInvalid()) { LOGE("NPC: out of bodies"); destroy(); return false; }
    }
    quat Q = glm::angleAxis(yaw, vec3(0, 1, 0));
    vec3 X = Q * vec3(1, 0, 0), Z = Q * vec3(0, 0, 1);
    auto body = [&](int i) -> Body* {
        BodyLockWrite l(phys->sys().GetBodyLockInterfaceNoLock(), mBodies[i]);
        return l.Succeeded() ? &l.GetBody() : nullptr;
    };
    struct J { int a, b; bool hinge; vec3 twist; float cone, plane, tmin, tmax; };
    const J joints[10] = {
        {NP_PELVIS, NP_TORSO, false, {0, 1, 0}, 0.5f, 0.5f, -0.35f, 0.35f},
        {NP_TORSO, NP_HEAD, false, {0, 1, 0}, 0.6f, 0.6f, -0.8f, 0.8f},
        {NP_TORSO, NP_UARM_L, false, {0, -1, 0}, 1.4f, 1.4f, -0.6f, 0.6f},
        {NP_UARM_L, NP_LARM_L, true, {}, 0, 0, -2.0f, 0.35f},
        {NP_TORSO, NP_UARM_R, false, {0, -1, 0}, 1.4f, 1.4f, -0.6f, 0.6f},
        {NP_UARM_R, NP_LARM_R, true, {}, 0, 0, -2.0f, 0.35f},
        {NP_PELVIS, NP_THIGH_L, false, {0, -1, 0}, 1.1f, 0.5f, -0.3f, 0.3f},
        {NP_THIGH_L, NP_SHIN_L, true, {}, 0, 0, -0.05f, 2.4f},
        {NP_PELVIS, NP_THIGH_R, false, {0, -1, 0}, 1.1f, 0.5f, -0.3f, 0.3f},
        {NP_THIGH_R, NP_SHIN_R, true, {}, 0, 0, -0.05f, 2.4f},
    };
    for (int j = 0; j < 10; ++j) {
        const J& d = joints[j];
        Body* a = body(d.a); Body* b = body(d.b);
        if (!a || !b) continue;
        RVec3 p(pose.joints[j].x, pose.joints[j].y, pose.joints[j].z);
        if (d.hinge) {
            HingeConstraintSettings hs;
            hs.mPoint1 = hs.mPoint2 = p;
            hs.mHingeAxis1 = hs.mHingeAxis2 = ToJ(X);
            hs.mNormalAxis1 = hs.mNormalAxis2 = Vec3(0, -1, 0);
            hs.mLimitsMin = d.tmin; hs.mLimitsMax = d.tmax;
            hs.mMaxFrictionTorque = 4.0f;
            mJoints[j] = hs.Create(*a, *b);
        } else {
            SwingTwistConstraintSettings ss;
            ss.mPosition1 = ss.mPosition2 = p;
            ss.mTwistAxis1 = ss.mTwistAxis2 = ToJ(d.twist);
            ss.mPlaneAxis1 = ss.mPlaneAxis2 = ToJ(Z);
            ss.mNormalHalfConeAngle = d.cone;
            ss.mPlaneHalfConeAngle = d.plane;
            ss.mTwistMinAngle = d.tmin; ss.mTwistMaxAngle = d.tmax;
            ss.mMaxFrictionTorque = 6.0f;
            mJoints[j] = ss.Create(*a, *b);
        }
        phys->sys().AddConstraint(mJoints[j]);
    }
    mValid = true;
    state = NpcState::Idle;
    mIdleTime = GRng().range(0.5f, 3.0f);
    return true;
}

void Npc::destroy() {
    if (!mPhys) return;
    for (auto& j : mJoints) if (j) { mPhys->sys().RemoveConstraint(j); j = nullptr; }
    for (auto& b : mBodies) if (!b.IsInvalid()) { mPhys->bi().RemoveBody(b); mPhys->bi().DestroyBody(b); b = BodyID(); }
    mValid = false;
}

bool Npc::ownsBody(BodyID id) const {
    for (auto& b : mBodies) if (b == id) return true;
    return false;
}

vec3 Npc::center() const {
    if (!mValid) return mRoot;
    return ToG(Vec3(mPhys->bi().GetPosition(mBodies[NP_PELVIS])));
}

void Npc::setMotion(bool dynamic) {
    if (dynamic == mDynamic) return;
    mDynamic = dynamic;
    for (auto& b : mBodies) mPhys->bi().SetMotionType(b, dynamic ? EMotionType::Dynamic : EMotionType::Kinematic, EActivation::Activate);
}

void Npc::driveKinematic(const NpcPose& p, float dt) {
    BodyInterface& bi = mPhys->bi();
    for (int i = 0; i < NP_COUNT; ++i) bi.MoveKinematic(mBodies[i], RVec3(p.pos[i].x, p.pos[i].y, p.pos[i].z), ToJ(glm::normalize(p.rot[i])), dt);
}

bool Npc::groundHeight(const vec3& at, float& y) const {
    RayHit h;
    if (!mPhys->raycast(at + vec3(0, 1.2f, 0), vec3(0, -1, 0), 3.2f, h, BodyID(), false)) return false;
    y = h.point.y;
    return true;
}

void Npc::pickTarget() {
    Rng& r = GRng();
    for (int i = 0; i < 6; ++i) {
        float a = r.range(0, 6.2831f), d = r.range(2.0f, wanderRadius);
        vec3 t = home + vec3(std::sin(a) * d, 0, std::cos(a) * d);
        float gy;
        if (groundHeight(vec3(t.x, home.y, t.z), gy) && std::fabs(gy - home.y) < 1.2f) { mTarget = vec3(t.x, gy, t.z); return; }
    }
    mTarget = home;
}

void Npc::makeRagdoll(const vec3& vel, const vec3&) {
    if (!mValid) return;
    BodyInterface& bi = mPhys->bi();
    bool was = mDynamic;
    setMotion(true);
    for (auto& b : mBodies) {
        Vec3 v = was ? bi.GetLinearVelocity(b) : Vec3::sZero();
        bi.SetLinearVelocity(b, v + ToJ(vel * GRng().range(0.85f, 1.15f)));
        bi.SetAngularVelocity(b, ToJ(GRng().unitVec() * 2.0f));
    }
    if (state != NpcState::Ragdoll) { ++knockdowns; GAudio().play(SND_BODY_HIT, center(), 0.8f, GRng().range(0.9f, 1.1f)); }
    state = NpcState::Ragdoll;
    mStateTime = 0; mRest = 0;
}

void Npc::hit(const vec3& point, const vec3& dir, float energy) {
    if (!mValid || mCooldown > 0) return;
    if (state == NpcState::Ragdoll) return;
    if (energy > 220.0f) {
        float v = std::min(std::sqrt(2.0f * energy / 75.0f) * 0.75f, 16.0f);
        vec3 d = glm::length2(dir) > 1e-6f ? glm::normalize(dir) : vec3(0, 0, 1);
        makeRagdoll(d * v + vec3(0, v * 0.25f, 0), point);
    } else if (energy > 40.0f && state != NpcState::Stagger && state != NpcState::Recover) {
        state = NpcState::Stagger;
        mStateTime = 0;
        vec3 d = glm::length2(dir) > 1e-6f ? glm::normalize(vec3(dir.x, 0, dir.z) + vec3(1e-4f)) : vec3(0);
        mStaggerVel = d * glm::clamp(energy / 60.0f, 0.8f, 2.5f);
        vec3 fwd(std::sin(mYaw), 0, std::cos(mYaw));
        mStaggerLean = glm::dot(fwd, d) > 0 ? 0.35f : -0.35f;
        mCooldown = 0.3f;
        GAudio().play(SND_SOFT_HIT, point, 0.5f, 1.1f);
    }
}

void Npc::explosion(const vec3& c, float radius, float power) {
    if (!mValid) return;
    vec3 p = center();
    float d = glm::distance(p, c);
    float range = radius * 2.8f;
    if (d > range) return;
    float f = 1.0f - d / range;
    vec3 dir = d > 0.01f ? (p - c) / d : vec3(0, 1, 0);
    float v = std::min(power * 15.0f * f + 3.0f, 22.0f);
    makeRagdoll(glm::normalize(dir + vec3(0, 0.6f, 0)) * v, c);
}

void Npc::prePhysics(float dt) {
    if (!mValid) return;
    mStateTime += dt;
    mCooldown = std::max(0.0f, mCooldown - dt);
    NpcPose pose;
    switch (state) {
    case NpcState::Idle: {
        mWalkAmt = MoveTowards(mWalkAmt, 0, dt * 2.0f);
        mPhase += dt * 4.0f * mWalkAmt;
        mIdleTime -= dt;
        if (mIdleTime <= 0) { pickTarget(); state = NpcState::Walk; mStateTime = 0; }
        float breathe = std::sin(mStateTime * 1.7f) * 0.02f;
        computePose(pose, mRoot, mYaw, mWalkAmt, mPhase, 0, breathe, 0);
        driveKinematic(pose, dt);
        break;
    }
    case NpcState::Walk: {
        vec3 to = mTarget - mRoot; to.y = 0;
        float dist = glm::length(to);
        if (dist < 0.4f || mStateTime > 25.0f) { state = NpcState::Idle; mIdleTime = GRng().range(1.0f, 4.0f); mStateTime = 0; }
        float want = std::atan2(to.x, to.z);
        float dy = want - mYaw;
        while (dy > 3.14159f) dy -= 6.28318f;
        while (dy < -3.14159f) dy += 6.28318f;
        mYaw += glm::clamp(dy, -dt * 2.5f, dt * 2.5f);
        float facing = std::cos(dy);
        mWalkAmt = MoveTowards(mWalkAmt, facing > 0.3f ? 1.0f : 0.3f, dt * 2.0f);
        float speed = 1.15f * mWalkAmt;
        vec3 fwd(std::sin(mYaw), 0, std::cos(mYaw));
        // obstacle and ledge checks
        RayHit h;
        if (mPhys->raycast(mRoot + vec3(0, 0.7f, 0), fwd, 0.6f, h, BodyID(), false)) {
            state = NpcState::Idle; mIdleTime = GRng().range(0.3f, 1.5f); mStateTime = 0;
            pickTarget();
        } else {
            vec3 next = mRoot + fwd * speed * dt;
            float gy;
            if (groundHeight(next, gy) && std::fabs(gy - mRoot.y) < 0.45f) {
                next.y = Lerp(mRoot.y, gy, std::min(1.0f, dt * 10.0f));
                mRoot = next;
            } else { state = NpcState::Idle; mIdleTime = 0.5f; mStateTime = 0; }
        }
        mPhase += dt * speed * 5.2f;
        computePose(pose, mRoot, mYaw, mWalkAmt, mPhase, 0, 0.05f * mWalkAmt, 0);
        driveKinematic(pose, dt);
        break;
    }
    case NpcState::Stagger: {
        float t = mStateTime / 0.9f;
        mRoot += mStaggerVel * dt * (1.0f - t);
        float gy;
        if (groundHeight(mRoot, gy)) mRoot.y = Lerp(mRoot.y, gy, std::min(1.0f, dt * 10.0f));
        else { makeRagdoll(mStaggerVel, mRoot); break; }   // stumbled off a ledge
        float wobble = std::sin(t * 3.14159f);
        mPhase += dt * 9.0f;
        computePose(pose, mRoot, mYaw, 0.6f * wobble, mPhase, 0.15f * wobble, mStaggerLean * wobble, 0.55f * wobble);
        driveKinematic(pose, dt);
        if (t >= 1.0f) { state = NpcState::Idle; mIdleTime = 1.0f; mStateTime = 0; }
        break;
    }
    case NpcState::Ragdoll: {
        BodyInterface& bi = mPhys->bi();
        float maxV = 0;
        for (auto& b : mBodies) maxV = std::max(maxV, bi.GetLinearVelocity(b).Length());
        mRest = maxV < 0.45f ? mRest + dt : 0.0f;
        vec3 pel = center();
        if (pel.y < -15.0f) {   // fell out of the world: respawn at home
            mRoot = home; setMotion(false); state = NpcState::Idle; mIdleTime = 2; mStateTime = 0;
            break;
        }
        if ((mRest > 1.4f && mStateTime > 2.0f) || mStateTime > 12.0f) {
            // capture pose and start getting up
            for (int i = 0; i < NP_COUNT; ++i) {
                RVec3 p; Quat q;
                bi.GetPositionAndRotation(mBodies[i], p, q);
                mFrom.pos[i] = ToG(Vec3(p)); mFrom.rot[i] = ToG(q);
            }
            vec3 head = mFrom.pos[NP_HEAD];
            vec3 dir = head - pel; dir.y = 0;
            if (glm::length(dir) > 0.2f) mYaw = std::atan2(dir.x, dir.z);
            float gy = pel.y - 0.2f;
            groundHeight(vec3(pel.x, pel.y + 0.5f, pel.z), gy);
            mRoot = vec3(pel.x, gy, pel.z);
            setMotion(false);
            state = NpcState::Recover;
            mStateTime = 0;
        }
        break;
    }
    case NpcState::Recover: {
        const float T1 = 0.7f, T2 = 1.2f;
        float t = mStateTime;
        if (t < T1) {
            NpcPose crouch;
            computePose(crouch, mRoot, mYaw, 0, 0, 1.0f, 0, 0.1f);
            float a = SmoothStep(0, 1, t / T1);
            for (int i = 0; i < NP_COUNT; ++i) {
                pose.pos[i] = glm::mix(mFrom.pos[i], crouch.pos[i], a);
                pose.rot[i] = glm::slerp(mFrom.rot[i], crouch.rot[i], a);
            }
        } else {
            float a = SmoothStep(0, 1, (t - T1) / T2);
            computePose(pose, mRoot, mYaw, 0, 0, 1.0f - a, 0, 0.1f * (1.0f - a));
        }
        driveKinematic(pose, dt);
        if (t > T1 + T2) { state = NpcState::Idle; mIdleTime = GRng().range(1.0f, 3.0f); mStateTime = 0; mWalkAmt = 0; mCooldown = 1.0f; }
        break;
    }
    }
}

void Npc::update(float) {}

void Npc::render(Renderer& r) {
    if (!mValid) return;
    BodyInterface& bi = mPhys->bi();
    const vec4 skin(0.95f, 0.72f, 0.12f, 1.0f);
    const vec4 shirt(mShirt, 1.0f);
    const vec4 pants(0.13f, 0.15f, 0.2f, 1.0f);
    const vec4 colors[NP_COUNT] = {pants, shirt, skin, shirt, skin, shirt, skin, pants, pants, pants, pants};
    vec3 headPos(0); quat headRot(1, 0, 0, 0);
    vec3 torsoPos(0); quat torsoRot(1, 0, 0, 0);
    for (int i = 0; i < NP_COUNT; ++i) {
        RVec3 p; Quat q;
        bi.GetPositionAndRotation(mBodies[i], p, q);
        vec3 c = ToG(Vec3(p)); quat g = ToG(q);
        vec3 ax = g * vec3(0, mHalf[i], 0);
        r.drawCapsule(c - ax, c + ax, mRadius[i], colors[i], vec4(i == NP_HEAD || i == NP_LARM_L || i == NP_LARM_R ? 0.35f : 0.8f, 0, 0, 0));
        if (i == NP_HEAD) { headPos = c; headRot = g; }
        if (i == NP_TORSO) { torsoPos = c; torsoRot = g; }
    }
    // visor and crash-test target markers
    mat4 hv = glm::translate(mat4(1), headPos + headRot * vec3(0, 0.03f, 0.1f)) * glm::mat4_cast(headRot) * glm::scale(mat4(1), vec3(0.18f, 0.06f, 0.05f));
    r.drawInstance(MESH_CUBE, hv, vec4(0.05f, 0.05f, 0.06f, 1), vec4(0.15f, 0.2f, 0, 0));
    for (int s = -1; s <= 1; s += 2) {
        mat4 m = glm::translate(mat4(1), torsoPos + torsoRot * vec3(0.152f * s, 0.05f, 0)) * glm::mat4_cast(torsoRot) *
                 glm::mat4_cast(glm::angleAxis(1.5708f, vec3(0, 0, 1))) * glm::scale(mat4(1), vec3(0.14f, 0.01f, 0.14f));
        r.drawInstance(MESH_CYLINDER, m, vec4(0.04f, 0.04f, 0.04f, 1), vec4(0.5f, 0, 0, 0), false);
    }
}

// ---------------------------------------------------------------- manager
void NpcManager::init(PhysicsWorld* phys) {
    mPhys = phys;
    mFilter = new GroupFilterTable(NP_COUNT);
    for (int i = 0; i < NP_COUNT; ++i)
        for (int j = i + 1; j < NP_COUNT; ++j) mFilter->DisableCollision(i, j);
}

void NpcManager::clear() {
    for (auto& n : mNpcs) n->destroy();
    mNpcs.clear();
}

Npc* NpcManager::spawn(const vec3& feet, float yaw) {
    static const vec3 shirts[] = {{0.15f, 0.35f, 0.75f}, {0.75f, 0.2f, 0.15f}, {0.2f, 0.6f, 0.3f}, {0.85f, 0.85f, 0.85f}, {0.5f, 0.25f, 0.6f}, {0.9f, 0.45f, 0.1f}};
    auto n = std::make_unique<Npc>();
    if (!n->create(mPhys, mFilter, mNextGroup, feet, yaw, shirts[mNextGroup % 6])) return nullptr;
    ++mNextGroup;
    mNpcs.push_back(std::move(n));
    return mNpcs.back().get();
}

void NpcManager::remove(Npc* n) {
    for (size_t i = 0; i < mNpcs.size(); ++i)
        if (mNpcs[i].get() == n) { n->destroy(); mNpcs.erase(mNpcs.begin() + i); return; }
}

void NpcManager::render(Renderer& r, const vec3& cam, float dist) {
    for (auto& n : mNpcs) {
        vec3 c = n->center();
        if (glm::distance(c, cam) > dist || !r.sphereVisible(c, 1.5f)) continue;
        n->render(r);
    }
}

int NpcManager::ragdollCount() const {
    int c = 0;
    for (auto& n : mNpcs) c += n->state == NpcState::Ragdoll;
    return c;
}
