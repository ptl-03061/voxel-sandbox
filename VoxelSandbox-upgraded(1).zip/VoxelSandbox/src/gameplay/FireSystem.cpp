#include "gameplay/FireSystem.h"
#include "destruction/Destruction.h"
#include "engine/Particles.h"
#include "engine/Audio.h"

float FireSystem::flammability(uint8_t m) {
    switch (m) {
    case M_PLANK: case M_WOOD: case M_BARK: case M_DARKWOOD: return 1.0f;
    case M_LEAVES: case M_FABRIC: case M_CARPET: return 0.9f;
    case M_PLASTIC: case M_ROOF: return 0.55f;
    case M_GRASS: return 0.5f;
    default: return 0.0f;
    }
}

void FireSystem::igniteAt(const vec3& c, float radius) {
    if (!mEnabled || !mWorld) return;
    ivec3 vc = VoxelWorld::toVoxel(c);
    int r = (int)std::ceil(radius / VOXEL_SIZE);
    for (int z = -r; z <= r; ++z) for (int y = -r; y <= r; ++y) for (int x = -r; x <= r; ++x) {
        if ((int)mCells.size() >= mMaxCells) return;
        ivec3 v = vc + ivec3(x, y, z);
        uint8_t m = mWorld->get(v);
        if (flammability(m) <= 0 || glm::distance(VoxelWorld::voxelCenter(v), c) > radius) continue;
        bool dup = false;
        for (auto& cell : mCells) if (cell.v == v) { dup = true; break; }
        if (!dup) mCells.push_back({v, GRng().range(3.0f, 6.0f)});
    }
}

void FireSystem::extinguishAt(const vec3& c, float radius) {
    for (auto it = mCells.begin(); it != mCells.end();) {
        if (glm::distance(VoxelWorld::voxelCenter(it->v), c) < radius) it = mCells.erase(it);
        else ++it;
    }
}

void FireSystem::update(float dt) {
    if (!mEnabled || mCells.empty() || !mWorld) return;
    mTick -= dt;
    bool doTick = mTick <= 0;
    if (doTick) mTick = 0.22f;
    Rng& r = GRng();
    for (auto it = mCells.begin(); it != mCells.end();) {
        Cell& cell = *it;
        vec3 p = VoxelWorld::voxelCenter(cell.v);
        if (mParts) {
            mParts->spawn(PType::Fire, p + r.unitVec() * 0.1f, vec3(0, 1.2f, 0) + r.unitVec() * 0.4f,
                          vec4(1.0f, r.range(0.4f, 0.65f), 0.12f, 0.85f), r.range(0.15f, 0.3f), r.range(0.3f, 0.6f));
            if (r.f01() < 0.25f)
                mParts->spawn(PType::Smoke, p, vec3(0, 1.0f, 0), vec4(0.25f, 0.24f, 0.23f, 0.3f), r.range(0.4f, 0.8f), r.range(2.0f, 4.0f));
        }
        if (!doTick) { ++it; continue; }
        cell.life -= 0.22f;
        if (cell.life <= 0) {
            if (mDestr) mDestr->onExternalRemoval(cell.v);
            it = mCells.erase(it);
            continue;
        }
        if ((int)mCells.size() < mMaxCells && r.f01() < 0.35f) {
            static const ivec3 N[6] = {{1,0,0},{-1,0,0},{0,1,0},{0,-1,0},{0,0,1},{0,0,-1}};
            ivec3 nv = cell.v + N[r.irange(0, 5)];
            uint8_t m = mWorld->get(nv);
            if (m && flammability(m) > 0 && r.f01() < flammability(m)) {
                bool dup = false;
                for (auto& c2 : mCells) if (c2.v == nv) { dup = true; break; }
                if (!dup) mCells.push_back({nv, r.range(3.0f, 6.0f)});
            }
        }
        if (mDestr) mDestr->addWeakness(cell.v + ivec3(0, -1, 0), 0.1f);
        ++it;
    }
}
