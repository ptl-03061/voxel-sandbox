// Stylized environmental fire: burns flammable voxels, spreads to neighbours, emits
// fire/smoke particles and feeds the structural stress system. Budget-capped, opt-in.
#pragma once
#include "core/Common.h"
#include "destruction/VoxelWorld.h"

class Destruction;
class Particles;

class FireSystem {
public:
    void init(VoxelWorld* world, Destruction* destr, Particles* parts) { mWorld = world; mDestr = destr; mParts = parts; }
    void clear() { mCells.clear(); }
    void setEnabled(bool e) { mEnabled = e; if (!e) mCells.clear(); }
    bool enabled() const { return mEnabled; }
    void setMaxCells(int n) { mMaxCells = n; }

    void igniteAt(const vec3& c, float radius);
    void extinguishAt(const vec3& c, float radius);
    void update(float dt);
    int burningCount() const { return (int)mCells.size(); }

private:
    struct Cell { ivec3 v; float life; };
    static float flammability(uint8_t m);
    VoxelWorld* mWorld = nullptr;
    Destruction* mDestr = nullptr;
    Particles* mParts = nullptr;
    std::vector<Cell> mCells;
    int mMaxCells = 24;
    bool mEnabled = true;
    float mTick = 0;
};
