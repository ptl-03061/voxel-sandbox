// Drivable vehicles built on Jolt's WheeledVehicleController (suspension, steering, engine, gearbox, tire friction).
#pragma once
#include "physics/PhysicsWorld.h"
#include "engine/Renderer.h"

#include <Jolt/Physics/Vehicle/VehicleConstraint.h>
#include <Jolt/Physics/Vehicle/VehicleCollisionTester.h>
#include <Jolt/Physics/Vehicle/WheeledVehicleController.h>
#include <Jolt/Physics/Constraints/SliderConstraint.h>
#include <Jolt/Physics/Collision/GroupFilterTable.h>

class Particles;

enum VehicleType { VEH_CAR, VEH_VAN, VEH_TRUCK, VEH_FORKLIFT, VEH_LOADER, VEH_COUNT };
const char* VehicleName(int t);

struct VehicleInput {
    float throttle = 0;   // -1..1 (negative = reverse)
    float steer = 0;      // -1..1 (positive = right)
    float brake = 0;
    bool handbrake = false;
    float fork = 0;       // -1..1 lift control (forklift / loader bucket)
};

struct VehicleBox { vec3 center, half; vec4 color; vec4 params; bool collide; };

class Vehicle {
public:
    bool create(PhysicsWorld* phys, VehicleType type, const vec3& pos, float yaw);
    void destroy();
    void update(float dt, const VehicleInput& in, bool occupied, Particles* parts);
    void render(Renderer& r, bool night);
    void applyDamage(float amount, const vec3& at);

    vec3 position() const;
    quat rotation() const;
    vec3 velocity() const;
    float speedKmh() const;
    vec3 seatWorld() const;
    vec3 exitPoint() const;
    bool owns(JPH::BodyID id) const { return id == body || id == forkBody; }
    float rpm() const;
    int gear() const;

    VehicleType type = VEH_CAR;
    JPH::BodyID body, forkBody;
    PhysTag tag;
    float health = 100.0f;
    bool wrecked = false;
    bool headlights = false;
    float camDistance = 6.0f, camHeight = 2.2f;
    float forkHeight = 0;
    float mass = 1200.0f;
    float destructionBoost = 1.0f;   // contact damage multiplier against voxels (loader)

private:
    PhysicsWorld* mPhys = nullptr;
    JPH::Ref<JPH::VehicleConstraint> mConstraint;
    JPH::Ref<JPH::VehicleCollisionTester> mTester;
    JPH::Ref<JPH::SliderConstraint> mForkSlider;
    JPH::Ref<JPH::GroupFilterTable> mGroup;
    std::vector<VehicleBox> mBoxes, mForkBoxes;
    std::vector<float> mWheelRadius, mWheelWidth;
    vec3 mSeat{0}, mHalf{1};
    float mComDrop = 0.3f;
    uint32_t mEngineVoice = 0, mSkidVoice = 0;
    float mEngineFade = 0;
    float mSmokeTimer = 0;
    float mMaxForkHeight = 2.4f;
};

class VehicleManager {
public:
    void init(PhysicsWorld* phys) { mPhys = phys; }
    void clear();
    Vehicle* spawn(VehicleType t, const vec3& pos, float yaw);
    void remove(Vehicle* v);
    void update(float dt, Vehicle* driven, const VehicleInput& in, Particles* parts);
    void render(Renderer& r, const vec3& cam, float dist, bool night);
    Vehicle* find(JPH::BodyID id);
    Vehicle* nearest(const vec3& p, float maxDist);
    std::vector<std::unique_ptr<Vehicle>>& vehicles() { return mVehicles; }
private:
    PhysicsWorld* mPhys = nullptr;
    std::vector<std::unique_ptr<Vehicle>> mVehicles;
};
