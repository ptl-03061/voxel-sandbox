#include "Game.h"
#include "gameplay/Props.h"
#include "ui/UI.h"

#include <Jolt/Physics/Body/BodyLock.h>
#include <chrono>

using namespace JPH;

static double NowMs() {  // wall clock for profiling (Platform::TimeSeconds may be simulated in the test harness)
    using namespace std::chrono;
    return duration<double, std::milli>(steady_clock::now().time_since_epoch()).count();
}

Game::Game() = default;
Game::~Game() = default;

bool Game::init(int width, int height) {
    mW = width; mH = height;
    settings.applyPreset(Q_MEDIUM);
    if (!settings.load(Platform::WritableDir() + "/settings.cfg")) LOGI("No saved settings, using defaults");
    if (!renderer.init()) { LOGE("Renderer init failed"); return false; }
    renderer.resize(width, height);
    GAudio().init();
    unsigned hw = std::thread::hardware_concurrency();
    int workers = (int)std::max(1u, std::min(hw, 8u) - 1);
    mJobs = std::make_unique<JobPool>(std::max(1, workers));
    if (!phys.init(std::max(1, workers))) { LOGE("Physics init failed"); return false; }
    mPhysInit = true;
    particles.init(settings.particleBudget);
    ui = std::make_unique<UI>(*this);
    if (!ui->init(width, height)) { LOGE("UI init failed"); return false; }
    applySettings();
    LOGI("Game initialized: %dx%d, %d worker threads", width, height, workers);
    return true;
}

void Game::shutdown() {
    if (mLoader.joinable()) mLoader.join();
    env.stopAmbience();
    destroyWorld();
    if (ui) ui->shutdown();
    ui.reset();
    if (mPhysInit) phys.shutdown();
    mPhysInit = false;
    renderer.shutdown();
}

void Game::resize(int w, int h) {
    mW = std::max(1, w); mH = std::max(1, h);
    renderer.resize(mW, mH);
    if (ui) ui->resize(mW, mH);
}

void Game::onPause() {
    paused = state == GameState::Playing ? true : paused;
    saveSettings();
    input.cancelAll();
}
void Game::onResume() { input.cancelAll(); }

void Game::applySettings() {
    Audio& a = GAudio();
    a.masterVolume = settings.masterVolume; a.sfxVolume = settings.sfxVolume;
    a.ambientVolume = settings.ambientVolume; a.uiVolume = settings.uiVolume;
    particles.setMax(settings.particleBudget);
    destr.settings.maxDebrisObjects = settings.maxDebris;
    destr.settings.maxFragmentsPerHit = settings.quality == Q_LOW ? 8 : settings.quality == Q_MEDIUM ? 14 : 20;
    destr.settings.particlesPerHit = settings.quality == Q_LOW ? 40 : settings.quality == Q_MEDIUM ? 80 : 120;
    mPhysHz = settings.quality == Q_LOW ? 30.0f : settings.quality == Q_MEDIUM ? 50.0f : 60.0f;
    if (!settings.dynamicResolution) renderer.dynamicScale = 1.0f;
}

void Game::saveSettings() { settings.save(Platform::WritableDir() + "/settings.cfg"); }

void Game::setGravityScale(float g) {
    gravityScale = g;
    phys.setGravity(vec3(0, -9.81f * g, 0));
    // wake everything so floating objects react
    BodyIDVector ids;
    phys.sys().GetBodies(ids);
    BodyInterface& bi = phys.bi();
    for (auto id : ids)
        if (bi.GetMotionType(id) == EMotionType::Dynamic) bi.ActivateBody(id);
}

// ------------------------------------------------------------------ loading
void Game::startLoading() {
    if (state == GameState::Loading) return;
    destroyWorld();
    state = GameState::Loading;
    paused = false;
    loadProgress = 0;
    loadStage = "Generating city";
    mLoadDone = false;
    mLoadProg = 0;
    world.init(&phys);
    objs.init(&phys);
    destr.init(&world, &objs, &phys, &particles);
    inter.init(&phys, &world, &objs);
    npcs.init(&phys);
    vehicles.init(&phys);
    sandbox.init(&phys, &objs, &destr, &vehicles, &npcs, &particles);
    constraints.init(&phys, &objs);
    machinery.init(&phys, &objs, &destr);
    fireSys.init(&world, &destr, &particles);
    saveSys.init(this);
    saveSys.hookDestruction();
    sandbox.setConstraints(&constraints);
    map = MapData();
    if (mLoader.joinable()) mLoader.join();
    // world generation + CPU meshing/collision shapes run on a background thread
    mLoader = std::thread([this] {
        double t0 = NowMs();
        MapBuilder::BuildVoxels(world, map, [this](float p) { mLoadProg = p * 0.35f; });
        double t1 = NowMs();
        world.buildAllCpu(*mJobs, [this](float p) { mLoadProg = 0.35f + p * 0.55f; });
        LOGI("World generated in %.0f ms, meshed in %.0f ms (%d chunks)", t1 - t0, NowMs() - t1, world.chunkCount());
        mLoadDone = true;
    });
}

void Game::finishLoading() {
    if (mLoader.joinable()) mLoader.join();
    double t0 = NowMs();
    world.uploadAllGpu();
    // dynamic map content
    for (auto& lg : map.lights) inter.addLightGroup(lg);
    for (auto& s : map.switches) inter.addSwitch(s);
    for (auto& e : map.elevators) inter.addElevator(e.base, e.half, e.floors);
    for (auto& g : map.gates) { int i = inter.addGate(g.center, g.half, g.openHeight); inter.gates()[i].color = g.color; }
    for (auto& p : map.plates) inter.addPlate(p);
    for (auto& c : map.cranes) inter.addCrane(c.pivot, c.jib, c.angle, c.chain);
    for (auto& s : map.seesaws) inter.addSeesaw(s.pivot, s.yaw);
    for (auto& d : map.doors) inter.addDoor(d.hinge, d.yaw, d.w, d.h, d.mat, d.window, d.breakImpulse);
    for (auto& p : map.props) {
        VoxelModel m = BuildProp(p.type);
        vec3 size = m.sizeMeters();
        quat rot = glm::angleAxis(p.yaw, vec3(0, 1, 0));
        vec3 corner = p.pos + vec3(0, 0.03f, 0) - rot * vec3(size.x * 0.5f, 0, size.z * 0.5f);
        VoxelObject* o = objs.create(std::move(m), corner, rot, OBJ_PROP, vec3(0), vec3(0), 1.0f, GetPropDef(p.type).name);
        if (o) phys.bi().DeactivateBody(o->body);   // start asleep: stable stacking, no jitter at load
    }
    for (auto& v : map.vehicles) vehicles.spawn((VehicleType)v.type, v.pos, v.yaw);
    for (auto& n : map.npcs) {
        Npc* npc = npcs.spawn(n.pos + vec3(0, 0.02f, 0), n.yaw);
        if (npc) { npc->home = n.pos; npc->wanderRadius = n.wander; }
    }
    player.init(&phys, map.spawn, map.spawnYaw);
    player.spawnPoint = map.spawn;
    sandbox.ignoreBody = player.innerBody();
    destr.onContact = [this](const ContactEvent& e, PhysTag* a, PhysTag* b, float en) { handleContact(e, a, b, en); };
    destr.onExplosion = [this](const vec3& c, float r, float p) {
        npcs.explosion(c, r, p);
        fireSys.igniteAt(c, r * 0.8f);
        machinery.onExplosion(c, r);
        if (!driving) {
            float d = glm::distance(player.feet() + vec3(0, 0.9f, 0), c);
            if (d < r * 2.2f) player.damage((1.0f - d / (r * 2.2f)) * 60.0f * p);
        } else {
            float d = glm::distance(driving->position(), c);
            if (d < r * 2.0f) driving->applyDamage((1.0f - d / (r * 2.0f)) * 50.0f * p, c);
        }
        for (auto& v : vehicles.vehicles()) {
            float d = glm::distance(v->position(), c);
            if (v.get() != driving && d < r * 2.0f) v->applyDamage((1.0f - d / (r * 2.0f)) * 50.0f * p, c);
        }
    };
    phys.sys().OptimizeBroadPhase();
    setGravityScale(1.0f);
    driving = nullptr;
    mAccum = 0;
    playTime = 0;
    env.timeOfDay = 9.5f;
    env.setWeather(Weather::Clear);
    // settle the world for a few steps so props come to rest before the player sees them
    for (int i = 0; i < 10; ++i) stepPhysics(1.0f / 60.0f);
    mContacts.clear();
    phys.takeContacts(mContacts);
    mContacts.clear();
    worldReady = true;
    state = GameState::Playing;
    LOGI("Map populated in %.0f ms: %d objects, %d vehicles, %d npcs", NowMs() - t0, objs.count(), (int)vehicles.vehicles().size(), (int)npcs.npcs().size());
    showToast("Welcome to Harbor Heights. Open SPAWN to create objects, pick a tool at the top.", 5.0f);
}

void Game::destroyWorld() {
    if (!worldReady && state != GameState::Loading) return;
    if (mLoader.joinable()) mLoader.join();
    env.stopAmbience();
    GAudio().stopAll();
    destr.onContact = nullptr;
    destr.onExplosion = nullptr;
    driving = nullptr;
    sandbox.clear();
    npcs.clear();
    vehicles.clear();
    inter.clear();
    constraints.clear();
    machinery.clear();
    fireSys.clear();
    objs.clear();
    player.shutdown();
    world.clear(&renderer);
    particles.clear();
    worldReady = false;
}

void Game::returnToMenu() {
    destroyWorld();
    state = GameState::MainMenu;
    paused = false;
}

// ------------------------------------------------------------------ actions
std::string Game::interactHint() {
    if (!worldReady) return "";
    if (driving) return "Exit";
    int sw = inter.findSwitch(mCamPos, mCamDir, 2.8f);
    if (sw >= 0) return inter.switches()[sw].label;
    Vehicle* v = vehicles.nearest(player.feet(), 3.6f);
    if (v && !v->wrecked) return std::string("Drive ") + VehicleName(v->type);
    RayHit hit;
    if (phys.raycast(mCamPos, mCamDir, 2.6f, hit, player.innerBody(), false) && hit.tag && hit.tag->type == TagType::VoxelObject) {
        auto* o = (VoxelObject*)hit.tag->ptr;
        if (o && (o->flags & OBJ_DOOR)) return "Open / close door";
    }
    return "";
}

void Game::interact() {
    if (!worldReady) return;
    if (driving) { enterOrExitVehicle(); return; }
    int sw = inter.findSwitch(mCamPos, mCamDir, 2.8f);
    if (sw >= 0) { inter.activate(sw); return; }
    Vehicle* v = vehicles.nearest(player.feet(), 3.6f);
    if (v && !v->wrecked) { enterOrExitVehicle(); return; }
    if (inter.useDoor(mCamPos, mCamDir)) return;
}

void Game::enterOrExitVehicle() {
    if (driving) {
        vec3 p = driving->exitPoint();
        // make sure the exit point is free; otherwise try the other side / roof
        RayHit h;
        if (phys.raycast(driving->position() + vec3(0, 0.5f, 0), glm::normalize(p - driving->position() + vec3(0, 1e-3f, 0)), glm::distance(p, driving->position()), h, driving->body, false))
            p = driving->position() + vec3(0, driving->camHeight + 0.4f, 0);
        player.teleport(p + vec3(0, 0.05f, 0));
        player.yaw = mCamYaw;
        player.pitch = 0;
        driving->headlights = driving->headlights;   // keep state
        ctl.veh = VehicleInput();
        driving = nullptr;
        GAudio().play(SND_DOOR, p, 0.6f, 1.2f);
        return;
    }
    Vehicle* v = vehicles.nearest(player.feet(), 3.6f);
    if (!v || v->wrecked) return;
    if (sandbox.holding()) sandbox.grabToggle(mCamPos, mCamDir);
    driving = v;
    player.park();
    mOrbitYaw = 0; mOrbitPitch = 0.22f; mOrbitTimer = 0;
    mChasePos = v->position() - (v->rotation() * vec3(0, 0, 1)) * v->camDistance + vec3(0, v->camHeight, 0);
    phys.bi().ActivateBody(v->body);
    GAudio().play(SND_DOOR, v->position(), 0.6f, 1.0f);
    showToast(std::string("Driving ") + VehicleName(v->type), 1.5f);
}

void Game::flipVehicle() {
    if (!driving) return;
    BodyInterface& bi = phys.bi();
    vec3 p = driving->position();
    vec3 f = driving->rotation() * vec3(0, 0, 1);
    float yaw = std::atan2(f.x, f.z);
    bi.SetPositionAndRotation(driving->body, RVec3(p.x, p.y + 1.2f, p.z), ToJ(glm::angleAxis(yaw, vec3(0, 1, 0))), EActivation::Activate);
    bi.SetLinearVelocity(driving->body, Vec3::sZero());
    bi.SetAngularVelocity(driving->body, Vec3::sZero());
}

void Game::respawnPlayer() {
    if (driving) enterOrExitVehicle();
    player.health = 100.0f;
    player.teleport(player.spawnPoint);
    player.yaw = map.spawnYaw;
}

void Game::teleportTo(int i) {
    if (i < 0 || i >= (int)map.landmarks.size()) return;
    if (driving) enterOrExitVehicle();
    player.teleport(map.landmarks[i].first + vec3(0, 0.1f, 0));
    showToast("Teleported to " + map.landmarks[i].second, 2.0f);
}

void Game::handleContact(const ContactEvent& e, PhysTag* a, PhysTag* b, float energy) {
    BodyInterface& bi = phys.bi();
    for (int side = 0; side < 2; ++side) {
        PhysTag* t = side == 0 ? a : b;
        PhysTag* o = side == 0 ? b : a;
        BodyID self = side == 0 ? e.a : e.b, other = side == 0 ? e.b : e.a;
        if (!t) continue;
        if (t->type == TagType::RagdollPart && t->ptr) {
            if (o && o->type == TagType::RagdollPart && o->ptr == t->ptr) continue;
            vec3 vo = ToG(bi.GetLinearVelocity(other)), vs = ToG(bi.GetLinearVelocity(self));
            vec3 dir = vo - vs;
            if (glm::length2(dir) < 0.01f) dir = side == 0 ? -e.normal : e.normal;
            if (o && (o->type == TagType::WorldChunk)) continue;   // falling onto the ground is handled by the ragdoll itself
            ((Npc*)t->ptr)->hit(e.point, dir, energy);
            if (energy > 220.0f) GAudio().play(SND_BODY_HIT, e.point, Saturate(energy / 3000.0f) * 0.8f + 0.2f, GRng().range(0.9f, 1.1f));
        } else if (t->type == TagType::Vehicle && t->ptr) {
            auto* v = (Vehicle*)t->ptr;
            if (energy > 8000.0f) v->applyDamage((energy - 8000.0f) / 1500.0f, e.point);
            // heavy machines (wheel loader bucket) chew through structures
            if (v->destructionBoost > 1.0f && o && (o->type == TagType::WorldChunk || o->type == TagType::VoxelObject)) {
                float sp = glm::length(ToG(bi.GetLinearVelocity(self)));
                if (sp > 1.2f && energy > 300.0f && GRng().f01() < 0.35f)
                    destr.damageAt(e.point, 0.3f * v->destructionBoost, 0.6f, ToG(bi.GetLinearVelocity(self)) * 0.3f, true, self);
            }
        } else if (t->type == TagType::Projectile) {
            sandbox.onContact(a, b);
        }
    }
}

// ------------------------------------------------------------------ simulation
void Game::stepPhysics(float h) {
    npcs.prePhysics(h);
    inter.prePhysics(h);
    machinery.prePhysics(h);
    sandbox.prePhysics(h, mCamPos, mCamDir, mCamYaw);
    double t0 = NowMs();
    phys.step(h, 1);
    perf.physMs += (float)(NowMs() - t0);
    ++perf.physSteps;
    mSimTime += h;
}

void Game::simulate(float dt) {
    float sdt = std::min(dt, 0.1f) * timeScale;
    // player movement (variable step; CharacterVirtual is robust to it) or vehicle driving
    if (driving) {
        vehicles.update(sdt, driving, ctl.veh, &particles);
        if (driving->wrecked && driving->health <= 0) {
            showToast("Vehicle wrecked", 2.0f);
            enterOrExitVehicle();
        }
    } else {
        vehicles.update(sdt, nullptr, VehicleInput(), &particles);
        player.update(sdt, ctl.move, ctl.jump, ctl.sprint, &destr);
        if (player.health <= 0) {
            showToast("You were knocked out. Respawning...", 3.0f);
            respawnPlayer();
        }
        if (player.feet().y < -20.0f) respawnPlayer();
    }
    // fixed step physics with a cap on catch-up steps (prevents spiral of death on slow devices)
    float h = 1.0f / mPhysHz;
    mAccum += sdt;
    int maxSteps = settings.quality == Q_LOW ? 2 : 3;
    int steps = 0;
    perf.physMs = 0; perf.physSteps = 0;
    while (mAccum >= h && steps < maxSteps) {
        stepPhysics(h);
        mAccum -= h;
        ++steps;
    }
    if (mAccum > h) mAccum = h;   // drop excess time instead of falling behind
    // contacts -> destruction, sounds, ragdolls, vehicle damage
    mContacts.clear();
    phys.takeContacts(mContacts);
    destr.processContacts(mContacts, mSimTime);
    destr.update(sdt);
    objs.update(sdt, settings.maxDebris);
    npcs.update(sdt);
    inter.update(sdt, &destr);
    constraints.update(sdt);
    machinery.update(sdt);
    fireSys.update(sdt);
    sandbox.update(sdt);
    particles.update(sdt, world, env.wind());
    env.update(dt, mCamPos, particles, world);
    int budget = settings.quality == Q_LOW ? 6 : settings.quality == Q_MEDIUM ? 10 : 16;
    world.updateDirty(budget);
    playTime += dt;
    mAutosave += dt;
    if (mAutosave > 60.0f) { mAutosave = 0; saveGame("auto"); }
}

void Game::updateCamera(float dt) {
    if (driving) {
        vec3 vp = driving->position();
        vec3 f = driving->rotation() * vec3(0, 0, 1);
        float vyaw = std::atan2(f.x, f.z);
        if (glm::length(ctl.look) > 1e-4f) {
            mOrbitYaw += ctl.look.x;
            mOrbitPitch = glm::clamp(mOrbitPitch - ctl.look.y, -0.2f, 1.1f);
            mOrbitTimer = 2.5f;
        } else if ((mOrbitTimer -= dt) <= 0) {
            mOrbitYaw *= std::exp(-dt * 2.0f);   // drift back behind the vehicle
        }
        float yaw = vyaw + mOrbitYaw;
        vec3 back(-std::sin(yaw), 0, -std::cos(yaw));
        float dist = driving->camDistance;
        vec3 target = vp + vec3(0, driving->camHeight * 0.55f, 0);
        vec3 desired = target + back * dist * std::cos(mOrbitPitch) + vec3(0, dist * std::sin(mOrbitPitch) + 0.6f, 0);
        // keep the camera out of walls
        RayHit h;
        vec3 d = desired - target;
        float len = glm::length(d);
        if (len > 0.01f && phys.raycast(target, d / len, len, h, driving->body, false)) desired = target + d / len * std::max(0.6f, h.dist - 0.3f);
        float k = 1.0f - std::exp(-dt * 10.0f);
        mChasePos = glm::mix(mChasePos, desired, k);
        mCamPos = mChasePos;
        mCamDir = glm::normalize(target + vec3(0, 0.4f, 0) - mCamPos);
        mCamYaw = std::atan2(mCamDir.x, mCamDir.z);
        mCamPitch = std::asin(glm::clamp(mCamDir.y, -1.0f, 1.0f));
    } else {
        player.look(ctl.look.x, ctl.look.y);
        mCamPos = player.eye();
        mCamDir = player.forward();
        mCamYaw = player.yaw;
        mCamPitch = player.pitch;
    }
    GAudio().setListener(mCamPos, mCamDir, vec3(0, 1, 0));
}

void Game::updateDynamicResolution(float dt) {
    if (!settings.dynamicResolution) { renderer.dynamicScale = 1.0f; return; }
    mDynTimer += dt;
    if (mDynTimer < 0.5f) return;
    mDynTimer = 0;
    float target = 1000.0f / (float)std::max(30, settings.fpsLimit);
    if (perf.frameMs > target * 1.15f) renderer.dynamicScale = std::max(0.6f, renderer.dynamicScale - 0.05f);
    else if (perf.frameMs < target * 0.85f) renderer.dynamicScale = std::min(1.0f, renderer.dynamicScale + 0.025f);
}

void Game::render() {
    FrameParams fp;
    float aspect = (float)mW / (float)mH;
    float far = settings.viewDistance + 40.0f;
    fp.proj = glm::perspective(glm::radians(settings.fov), aspect, 0.08f, far);
    fp.view = glm::lookAt(mCamPos, mCamPos + mCamDir, vec3(0, 1, 0));
    fp.camPos = mCamPos;
    fp.nearZ = 0.08f; fp.farZ = far;
    fp.time = mSimTime;
    env.fill(fp);
    fp.damageVignette = driving ? 0.0f : Saturate(player.hurtFlash);
    RenderSettings rs;
    static const int shadowSizes[] = {0, 1024, 2048, 3072};
    rs.shadows = settings.shadowQuality > 0;
    rs.shadowSize = shadowSizes[glm::clamp(settings.shadowQuality, 0, 3)];
    rs.shadowDistance = settings.shadowQuality >= 3 ? 70.0f : settings.shadowQuality == 2 ? 55.0f : 40.0f;
    rs.ssao = settings.ssao;
    rs.renderScale = settings.renderScale;
    rs.viewDistance = settings.viewDistance;
    renderer.begin(fp, rs);
    world.render(renderer, mCamPos, settings.viewDistance * 0.55f, settings.viewDistance, settings.quality != Q_LOW);
    objs.render(renderer, mCamPos, settings.viewDistance);
    npcs.render(renderer, mCamPos, std::min(settings.viewDistance, 90.0f));
    vehicles.render(renderer, mCamPos, settings.viewDistance, env.night() > 0.4f);
    inter.render(renderer);
    constraints.render(renderer, mCamPos, settings.viewDistance);
    machinery.render(renderer, mCamPos);
    sandbox.render(renderer);
    particles.render(renderer, mCamPos);
    // lights: interactive groups + vehicle headlights, nearest N
    mLightBuf.clear();
    inter.collectLights(mLightBuf, env.night(), mCamPos);
    std::sort(mLightBuf.begin(), mLightBuf.end(), [this](const PointLight& a, const PointLight& b) {
        return glm::distance2(a.pos, mCamPos) < glm::distance2(b.pos, mCamPos);
    });
    int maxLights = settings.quality == Q_LOW ? 4 : 8;
    for (int i = 0; i < (int)mLightBuf.size() && i < maxLights; ++i) renderer.addLight(mLightBuf[i]);
    renderer.render();
}

void Game::frame(float dt) {
    double t0 = NowMs();
    input.beginFrame();
    ctl = Controls();
    if (ui) ui->beginFrame(dt);      // HUD hit-testing fills ctl
    if (state == GameState::Loading) {
        loadProgress = mLoadProg;
        if (mLoadDone) {
            // show the final stage for one frame before the blocking GPU upload
            if (mFinishFrames++ >= 2) { mFinishFrames = 0; finishLoading(); }
            else { loadStage = "Uploading meshes and building physics"; loadProgress = 0.95f; }
        }
    }
    if (state == GameState::Playing && worldReady) {
        double tu = NowMs();
        if (!paused) simulate(dt);
        else { GAudio().update(); }
        updateCamera(dt);
        perf.updateMs = (float)(NowMs() - tu);
        double tr = NowMs();
        render();
        perf.renderMs = (float)(NowMs() - tr);
        updateDynamicResolution(dt);
    } else {
        // menu background: clear to a gradient (the UI draws on top)
        glViewport(0, 0, mW, mH);
        glClearColor(0.06f, 0.07f, 0.09f, 1);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    }
    if (ui) ui->render(dt);
    GAudio().update();
    input.endFrame();
    if (toastTime > 0) toastTime -= dt;
    perf.frameMs = (float)(NowMs() - t0) * 0.1f + perf.frameMs * 0.9f;
    mFpsAccum += dt; ++mFpsFrames;
    if (mFpsAccum >= 0.5f) { perf.fps = mFpsFrames / mFpsAccum; mFpsAccum = 0; mFpsFrames = 0; }
}

// ------------------------------------------------------------------ saves
static std::string SavePathFor(const char* slot) { return Platform::WritableDir() + "/save_" + slot + ".dat"; }

void Game::saveGame(const char* slot) {
    std::string err;
    showToast(saveSys.save(SavePathFor(slot), err) ? std::string("Saved (") + slot + ")" : "Save failed: " + err, 2.0f);
}

void Game::loadGame(const char* slot) {
    std::string err;
    bool ok = saveSys.load(SavePathFor(slot), err);
    showToast(ok ? std::string("Loaded (") + slot + ")" : "Load failed: " + err, 2.5f);
}

bool Game::hasSaveGame(const char* slot) { return saveSys.hasSave(SavePathFor(slot)); }
