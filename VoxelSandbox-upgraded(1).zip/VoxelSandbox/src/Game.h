// Game orchestrator: owns all systems, runs the fixed-step simulation, camera, loading and state machine.
#pragma once
#include "core/Input.h"
#include "core/Jobs.h"
#include "core/Settings.h"
#include "destruction/Destruction.h"
#include "engine/Audio.h"
#include "engine/Particles.h"
#include "engine/Renderer.h"
#include "gameplay/Interactions.h"
#include "gameplay/Npc.h"
#include "gameplay/Player.h"
#include "gameplay/Sandbox.h"
#include "gameplay/FireSystem.h"
#include "gameplay/Machinery.h"
#include "physics/Constraints.h"
#include "save/SaveSystem.h"
#include "gameplay/Vehicle.h"
#include "world/Environment.h"
#include "world/MapBuilder.h"

#include <atomic>
#include <thread>

enum class GameState { MainMenu, Loading, Playing };

struct Controls {
    vec2 move{0};          // joystick (x right, y forward)
    vec2 look{0};          // radians this frame
    bool jump = false, sprint = false;
    VehicleInput veh;
};

class UI;

class Game {
public:
    Game();
    ~Game();
    bool init(int width, int height);   // GL context must be current
    void shutdown();
    void resize(int w, int h);
    void frame(float dt);               // update + render one frame
    void onPause();                     // app went to background
    void onResume();

    // actions used by the UI and the test harness
    void startLoading();
    void returnToMenu();
    void interact();
    void enterOrExitVehicle();
    void flipVehicle();
    void respawnPlayer();
    void teleportTo(int landmark);
    void applySettings();
    void saveSettings();
    void setGravityScale(float g);
    void saveGame(const char* slot = "auto");
    void loadGame(const char* slot = "auto");
    bool hasSaveGame(const char* slot = "auto");
    std::string interactHint();          // label for the context button ("" = nothing)
    vec3 camPos() const { return mCamPos; }
    vec3 camDir() const { return mCamDir; }
    float camYaw() const { return mCamYaw; }

    Input input;
    Settings settings;
    Controls ctl;
    Renderer renderer;
    Particles particles;
    PhysicsWorld phys;
    VoxelWorld world;
    ObjectManager objs;
    Destruction destr;
    Interactions inter;
    NpcManager npcs;
    VehicleManager vehicles;
    Sandbox sandbox;
    ConstraintManager constraints;
    Machinery machinery;
    FireSystem fireSys;
    SaveSystem saveSys;
    Player player;
    Environment env;
    MapData map;
    std::unique_ptr<UI> ui;

    GameState state = GameState::MainMenu;
    bool paused = false;
    Vehicle* driving = nullptr;
    float gravityScale = 1.0f;
    float timeScale = 1.0f;
    float loadProgress = 0;
    std::string loadStage;
    bool worldReady = false;
    float playTime = 0;

    struct Perf { float fps = 60, frameMs = 16, physMs = 0, renderMs = 0, updateMs = 0; int physSteps = 0; } perf;
    std::string toast; float toastTime = 0;
    void showToast(const std::string& s, float t = 2.5f) { toast = s; toastTime = t; }

private:
    void finishLoading();
    void destroyWorld();
    void simulate(float dt);
    void stepPhysics(float h);
    void updateCamera(float dt);
    void render();
    void handleContact(const ContactEvent& e, PhysTag* a, PhysTag* b, float energy);
    void updateDynamicResolution(float dt);

    std::unique_ptr<JobPool> mJobs;
    std::thread mLoader;
    std::atomic<bool> mLoadDone{false};
    std::atomic<float> mLoadProg{0};
    std::vector<ContactEvent> mContacts;
    float mAccum = 0;
    float mSimTime = 0;
    vec3 mCamPos{0}, mCamDir{0, 0, -1};
    float mCamYaw = 0, mCamPitch = 0;
    float mOrbitYaw = 0, mOrbitPitch = 0.25f, mOrbitTimer = 0;
    vec3 mChasePos{0};
    float mFpsAccum = 0; int mFpsFrames = 0;
    float mDynTimer = 0;
    int mW = 1, mH = 1;
    bool mPhysInit = false;
    int mFinishFrames = 0;
    float mPhysHz = 50;
    std::vector<PointLight> mLightBuf;
    float mAutosave = 0;
};
