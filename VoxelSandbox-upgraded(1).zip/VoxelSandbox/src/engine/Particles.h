// Pooled particle system: voxel debris cubes, dust, smoke, sparks, fire, glass shards, rain.
#pragma once
#include "core/Common.h"
#include "engine/Renderer.h"

class VoxelWorld;

enum class PType : uint8_t { Cube, Smoke, Dust, Spark, Fire, Shard, Rain, Splash, Flash };

struct Particle {
    vec3 pos, vel;
    vec4 color;
    float size, life, maxLife, rot, spin;
    PType type;
    bool resting;
};

class Particles {
public:
    void init(int maxParticles) { mMax = maxParticles; mPool.reserve(maxParticles); }
    void setMax(int m) { mMax = m; }
    void spawn(PType t, const vec3& p, const vec3& v, const vec4& color, float size, float life);
    void update(float dt, const VoxelWorld& world, const vec3& wind);
    void render(Renderer& r, const vec3& camPos);
    int count() const { return (int)mPool.size(); }
    void clear() { mPool.clear(); }
private:
    std::vector<Particle> mPool;
    int mMax = 2000;
};
