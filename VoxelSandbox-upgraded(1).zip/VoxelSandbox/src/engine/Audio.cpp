#include "engine/Audio.h"

Audio& GAudio() { static Audio a; return a; }

namespace {
constexpr float SR = (float)Audio::RATE;
constexpr float TAU = 6.2831853f;

struct Biquad {
    float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
    void bandpass(float f, float q) {
        float w = TAU * f / SR, al = std::sin(w) / (2 * q), c = std::cos(w), a0 = 1 + al;
        b0 = al / a0; b1 = 0; b2 = -al / a0; a1 = -2 * c / a0; a2 = (1 - al) / a0;
    }
    void lowpass(float f, float q = 0.707f) {
        float w = TAU * f / SR, al = std::sin(w) / (2 * q), c = std::cos(w), a0 = 1 + al;
        b0 = (1 - c) / 2 / a0; b1 = (1 - c) / a0; b2 = b0; a1 = -2 * c / a0; a2 = (1 - al) / a0;
    }
    void highpass(float f, float q = 0.707f) {
        float w = TAU * f / SR, al = std::sin(w) / (2 * q), c = std::cos(w), a0 = 1 + al;
        b0 = (1 + c) / 2 / a0; b1 = -(1 + c) / a0; b2 = b0; a1 = -2 * c / a0; a2 = (1 - al) / a0;
    }
    float run(float x) { float y = b0 * x + z1; z1 = b1 * x - a1 * y + z2; z2 = b2 * x - a2 * y; return y; }
};

Rng gSynth(12345);
float noise() { return gSynth.range(-1.f, 1.f); }
std::vector<float> buf(float seconds) { return std::vector<float>((size_t)(seconds * SR), 0.0f); }
void normalize(std::vector<float>& b, float peak = 0.9f) {
    float m = 1e-6f; for (float s : b) m = std::max(m, std::fabs(s));
    for (float& s : b) s *= peak / m;
}
// add a decaying resonant mode
void addMode(std::vector<float>& b, size_t start, float freq, float amp, float decay) {
    float ph = gSynth.range(0, TAU);
    for (size_t i = start; i < b.size(); ++i) {
        float t = (i - start) / SR;
        float e = std::exp(-t / decay);
        if (e < 1e-4f) break;
        b[i] += std::sin(ph + TAU * freq * t) * amp * e;
    }
}
void addNoiseBurst(std::vector<float>& b, size_t start, float dur, float amp, Biquad f, float attack = 0.002f) {
    size_t n = (size_t)(dur * SR);
    for (size_t i = 0; i < n && start + i < b.size(); ++i) {
        float t = i / SR;
        float e = std::min(1.0f, t / attack) * std::exp(-t / (dur * 0.3f));
        b[start + i] += f.run(noise()) * amp * e;
    }
}
// seamless loop: crossfade tail into head
void makeLoop(std::vector<float>& b, float fadeSec) {
    size_t f = (size_t)(fadeSec * SR);
    if (b.size() < f * 2) return;
    size_t n = b.size() - f;
    for (size_t i = 0; i < f; ++i) { float a = (float)i / f; b[i] = b[i] * a + b[n + i] * (1 - a); }
    b.resize(n);
}
}

void Audio::synthesize() {
    auto& B = mBuffers;
    { // wood hit: knocky resonances
        auto b = buf(0.35f);
        for (float f : {210.f, 420.f, 690.f, 1150.f}) addMode(b, 0, f * gSynth.range(0.95f, 1.05f), 1.0f / (f / 200), 0.05f);
        Biquad bp; bp.bandpass(900, 1.2f); addNoiseBurst(b, 0, 0.03f, 0.6f, bp);
        normalize(b); B[SND_WOOD_HIT].data = b;
    }
    { // wood break: splintering crackles
        auto b = buf(0.9f);
        for (int k = 0; k < 28; ++k) {
            size_t s = (size_t)(gSynth.range(0, 0.55f) * SR * (k < 6 ? 0.2f : 1.0f));
            Biquad bp; bp.bandpass(gSynth.range(600, 3200), 2.0f);
            addNoiseBurst(b, s, gSynth.range(0.01f, 0.05f), gSynth.range(0.3f, 1.0f), bp, 0.0005f);
        }
        for (float f : {140.f, 260.f, 480.f}) addMode(b, 0, f, 0.6f, 0.09f);
        normalize(b); B[SND_WOOD_BREAK].data = b;
    }
    { // glass hit: pings
        auto b = buf(0.6f);
        for (int k = 0; k < 4; ++k) addMode(b, 0, gSynth.range(2500, 6000), 0.4f, gSynth.range(0.08f, 0.2f));
        normalize(b, 0.7f); B[SND_GLASS_HIT].data = b;
    }
    { // glass break: shower of shards
        auto b = buf(1.4f);
        Biquad hp; hp.highpass(3000); addNoiseBurst(b, 0, 0.12f, 1.0f, hp, 0.0005f);
        for (int k = 0; k < 70; ++k) {
            size_t s = (size_t)(std::pow(gSynth.f01(), 2.0f) * 0.9f * SR);
            addMode(b, s, gSynth.range(2200, 9000), gSynth.range(0.1f, 0.5f), gSynth.range(0.02f, 0.12f));
        }
        normalize(b); B[SND_GLASS_BREAK].data = b;
    }
    { // metal hit: inharmonic partials
        auto b = buf(1.2f);
        float f0 = 340;
        float ratios[] = {1.0f, 2.76f, 5.40f, 8.93f, 13.3f};
        for (int i = 0; i < 5; ++i) addMode(b, 0, f0 * ratios[i], 1.0f / (i + 1), 0.35f / (1 + i * 0.4f));
        Biquad bp; bp.bandpass(3000, 1.0f); addNoiseBurst(b, 0, 0.015f, 0.8f, bp, 0.0003f);
        normalize(b, 0.8f); B[SND_METAL_HIT].data = b;
    }
    { // heavy metal clang
        auto b = buf(2.0f);
        float f0 = 110;
        float ratios[] = {1.0f, 2.32f, 4.25f, 6.63f, 9.38f, 12.1f};
        for (int i = 0; i < 6; ++i) addMode(b, 0, f0 * ratios[i], 1.0f / (i + 1), 0.8f / (1 + i * 0.3f));
        Biquad lp; lp.lowpass(800); addNoiseBurst(b, 0, 0.08f, 1.0f, lp);
        normalize(b); B[SND_METAL_HEAVY].data = b;
    }
    { // concrete hit: dull thump
        auto b = buf(0.4f);
        Biquad lp; lp.lowpass(700); addNoiseBurst(b, 0, 0.18f, 1.0f, lp, 0.001f);
        addMode(b, 0, 85, 0.8f, 0.07f);
        normalize(b); B[SND_CONCRETE_HIT].data = b;
    }
    { // concrete break: crumble
        auto b = buf(1.3f);
        Biquad lp; lp.lowpass(1200); addNoiseBurst(b, 0, 0.25f, 1.0f, lp, 0.001f);
        addMode(b, 0, 60, 1.0f, 0.15f);
        for (int k = 0; k < 40; ++k) {
            size_t s = (size_t)(gSynth.range(0.02f, 1.0f) * SR);
            Biquad bp; bp.bandpass(gSynth.range(400, 2500), 1.5f);
            addNoiseBurst(b, s, gSynth.range(0.01f, 0.04f), gSynth.range(0.1f, 0.45f), bp, 0.0005f);
        }
        normalize(b); B[SND_CONCRETE_BREAK].data = b;
    }
    { // structural collapse rumble
        auto b = buf(3.5f);
        Biquad lp; lp.lowpass(220, 0.9f);
        for (size_t i = 0; i < b.size(); ++i) {
            float t = i / SR;
            float env = std::min(1.0f, t / 0.15f) * std::exp(-t / 1.4f) * (0.7f + 0.3f * std::sin(t * 13.0f + std::sin(t * 3.0f) * 4.0f));
            b[i] = lp.run(noise()) * env * 2.0f;
        }
        for (int k = 0; k < 90; ++k) {
            size_t s = (size_t)(gSynth.range(0.0f, 2.8f) * SR);
            Biquad bp; bp.bandpass(gSynth.range(300, 2200), 1.4f);
            addNoiseBurst(b, s, gSynth.range(0.01f, 0.06f), gSynth.range(0.05f, 0.3f), bp, 0.0005f);
        }
        normalize(b); B[SND_COLLAPSE].data = b;
    }
    { auto b = buf(0.3f); Biquad lp; lp.lowpass(450); addNoiseBurst(b, 0, 0.15f, 1.0f, lp, 0.002f); normalize(b, 0.7f); B[SND_DIRT_HIT].data = b; }
    { auto b = buf(0.25f); Biquad lp; lp.lowpass(300); addNoiseBurst(b, 0, 0.1f, 1.0f, lp, 0.003f); addMode(b, 0, 120, 0.4f, 0.04f); normalize(b, 0.6f); B[SND_SOFT_HIT].data = b; }
    { auto b = buf(0.3f); Biquad lp; lp.lowpass(500); addNoiseBurst(b, 0, 0.12f, 1.0f, lp, 0.002f); addMode(b, 0, 95, 0.9f, 0.05f); normalize(b, 0.7f); B[SND_BODY_HIT].data = b; }
    { // explosion
        auto b = buf(3.0f);
        Biquad lp; lp.lowpass(3000);
        for (size_t i = 0; i < b.size(); ++i) {
            float t = i / SR;
            float crack = std::exp(-t / 0.04f);
            float boom = std::sin(TAU * (45.0f * t - 12.0f * t * t)) * std::exp(-t / 0.5f);
            b[i] = lp.run(noise()) * (crack * 1.2f + std::exp(-t / 0.9f) * 0.35f) + boom * 1.1f;
        }
        Biquad lp2; lp2.lowpass(160);
        for (size_t i = 0; i < b.size(); ++i) { float t = i / SR; b[i] += lp2.run(noise()) * std::exp(-t / 1.2f) * 2.0f; }
        normalize(b, 0.95f); B[SND_EXPLOSION].data = b;
    }
    { // footsteps
        auto mk = [&](SoundId id, float lpF, float modeF, float modeAmp, float dur) {
            auto b = buf(dur + 0.05f);
            Biquad lp; lp.lowpass(lpF); addNoiseBurst(b, 0, dur, 0.7f, lp, 0.001f);
            if (modeAmp > 0) addMode(b, 0, modeF, modeAmp, dur * 0.4f);
            normalize(b, 0.5f); B[id].data = b;
        };
        mk(SND_STEP_CONCRETE, 2200, 140, 0.3f, 0.08f);
        mk(SND_STEP_WOOD, 900, 180, 0.8f, 0.1f);
        mk(SND_STEP_METAL, 4000, 520, 0.6f, 0.12f);
        mk(SND_STEP_DIRT, 1400, 0, 0, 0.1f);
        mk(SND_STEP_SOFT, 500, 0, 0, 0.08f);
        mk(SND_LAND, 600, 90, 0.8f, 0.15f);
    }
    { auto b = buf(0.06f); addMode(b, 0, 1600, 1.0f, 0.012f); addMode(b, 0, 3200, 0.3f, 0.008f); normalize(b, 0.5f); B[SND_UI_CLICK].data = b; }
    { auto b = buf(0.08f); addMode(b, 0, 900, 1.0f, 0.02f); normalize(b, 0.5f); B[SND_UI_BACK].data = b; }
    { // whoosh
        auto b = buf(0.35f);
        Biquad bp;
        for (size_t i = 0; i < b.size(); ++i) {
            float t = i / SR;
            if (i % 64 == 0) bp.bandpass(400 + 2000 * (t / 0.35f), 1.5f);
            b[i] = bp.run(noise()) * std::sin(3.14159f * t / 0.35f);
        }
        normalize(b, 0.5f); B[SND_THROW].data = b; B[SND_SWING].data = b;
    }
    { auto b = buf(0.2f); for (size_t i = 0; i < b.size(); ++i) { float t = i / SR; b[i] = std::sin(TAU * (300 * t + 1500 * t * t)) * std::exp(-t / 0.06f); } normalize(b, 0.5f); B[SND_SPAWN].data = b; }
    { // horn
        auto b = buf(1.0f);
        for (size_t i = 0; i < b.size(); ++i) {
            float t = i / SR;
            float s = 0;
            for (int h = 1; h < 8; h += 2) s += std::sin(TAU * 392 * h * t) / h + std::sin(TAU * 494 * h * t) / h;
            b[i] = s;
        }
        makeLoop(b, 0.0f); normalize(b, 0.5f); B[SND_HORN].data = b;
    }
    { auto b = buf(0.5f); for (float f : {120.f, 240.f, 410.f}) addMode(b, 0, f, 0.7f, 0.1f); Biquad bp; bp.bandpass(700, 1); addNoiseBurst(b, 0, 0.05f, 0.5f, bp); normalize(b, 0.6f); B[SND_DOOR].data = b; }
    { auto b = buf(0.08f); addMode(b, 0, 2400, 1.0f, 0.006f); addMode(b, (size_t)(0.03f * SR), 1800, 0.8f, 0.006f); normalize(b, 0.5f); B[SND_SWITCH].data = b; }
    { // thunder
        auto b = buf(5.0f);
        Biquad lp; lp.lowpass(300, 0.8f);
        Biquad lp2; lp2.lowpass(2500);
        for (size_t i = 0; i < b.size(); ++i) {
            float t = i / SR;
            float env = std::exp(-t / 1.6f) * (0.6f + 0.4f * std::sin(t * 7.0f + std::sin(t * 2.0f) * 3.0f));
            b[i] = lp.run(noise()) * env * 2.5f + lp2.run(noise()) * std::exp(-t / 0.08f);
        }
        normalize(b, 0.9f); B[SND_THUNDER].data = b;
    }
    { // engine loop: 1s at 30Hz firing frequency, harmonics integer -> seamless
        auto b = buf(1.0f);
        Biquad lp; lp.lowpass(900);
        for (size_t i = 0; i < b.size(); ++i) {
            float t = i / SR;
            float s = 0;
            for (int h = 1; h <= 12; ++h) s += std::sin(TAU * 30 * h * t + h * 0.7f) / (h * 0.8f);
            float pulse = std::pow(0.5f + 0.5f * std::sin(TAU * 30 * t), 6.0f);
            b[i] = lp.run(s * 0.3f + noise() * 0.15f * pulse) + s * 0.08f;
        }
        normalize(b, 0.6f); B[SND_ENGINE].data = b;
    }
    { // wind ambience
        auto b = buf(9.0f);
        Biquad lp; lp.lowpass(350);
        for (size_t i = 0; i < b.size(); ++i) { float t = i / SR; b[i] = lp.run(noise()) * (0.6f + 0.4f * std::sin(t * 0.7f) * std::sin(t * 0.23f + 1)); }
        makeLoop(b, 1.0f); normalize(b, 0.4f); B[SND_AMB_WIND].data = b;
    }
    { // birds
        auto b = buf(10.0f);
        for (int k = 0; k < 18; ++k) {
            size_t s = (size_t)(gSynth.range(0, 9.0f) * SR);
            float f0 = gSynth.range(2500, 4500), sweep = gSynth.range(-1500, 2500);
            int chirps = gSynth.irange(2, 5);
            for (int c = 0; c < chirps; ++c) {
                size_t cs = s + (size_t)(c * 0.11f * SR);
                for (size_t i = 0; i < (size_t)(0.07f * SR) && cs + i < b.size(); ++i) {
                    float t = i / SR;
                    b[cs + i] += std::sin(TAU * (f0 * t + sweep * t * t * 7)) * std::sin(3.14159f * t / 0.07f) * 0.3f;
                }
            }
        }
        normalize(b, 0.25f); B[SND_AMB_BIRDS].data = b;
    }
    { // night crickets
        auto b = buf(6.0f);
        for (size_t i = 0; i < b.size(); ++i) {
            float t = i / SR;
            float gate = std::pow(std::max(0.0f, std::sin(TAU * 18 * t)), 4.0f) * (std::sin(TAU * 0.5f * t) > -0.2f ? 1.0f : 0.0f);
            b[i] = std::sin(TAU * 4400 * t) * gate * 0.2f + std::sin(TAU * 3900 * t + 1) * std::pow(std::max(0.0f, std::sin(TAU * 13 * t + 2)), 6.0f) * 0.12f;
        }
        normalize(b, 0.2f); B[SND_AMB_NIGHT].data = b;
    }
    { // rain
        auto b = buf(6.0f);
        Biquad hp; hp.highpass(900); Biquad lp; lp.lowpass(6000);
        for (size_t i = 0; i < b.size(); ++i) b[i] = lp.run(hp.run(noise())) * 0.5f;
        for (int k = 0; k < 400; ++k) addMode(b, (size_t)(gSynth.range(0, 5.8f) * SR), gSynth.range(1500, 5000), 0.15f, 0.01f);
        makeLoop(b, 0.5f); normalize(b, 0.45f); B[SND_AMB_RAIN].data = b;
    }
    { auto b = buf(0.5f); Biquad lp; lp.lowpass(400); addNoiseBurst(b, 0, 0.2f, 1.0f, lp, 0.0005f); addMode(b, 0, 70, 1.0f, 0.1f); normalize(b, 0.8f); B[SND_CANNON].data = b; }
    { auto b = buf(1.0f); for (size_t i = 0; i < b.size(); ++i) { float t = i / SR; b[i] = std::sin(TAU * 100 * t) * 0.5f + std::sin(TAU * 200 * t) * 0.25f + std::sin(TAU * 300 * t) * 0.1f; } normalize(b, 0.3f); B[SND_HUM].data = b; }
    { auto b = buf(2.0f); Biquad bp; bp.bandpass(1100, 3.0f); for (size_t i = 0; i < b.size(); ++i) b[i] = bp.run(noise()); makeLoop(b, 0.3f); normalize(b, 0.4f); B[SND_SKID].data = b; }
}

void Audio::init() {
    synthesize();
    LOGI("Audio: synthesized %d sounds", (int)SND_COUNT);
}

void Audio::computeGains(Voice& v) {
    float cat = v.cat == SoundCat::Ambient ? ambientVolume : (v.cat == SoundCat::Ui ? uiVolume : sfxVolume);
    float g = v.volume * cat * masterVolume;
    if (!v.spatial) { v.gainL = v.gainR = g; return; }
    vec3 d = v.pos - mLPos;
    float dist = glm::length(d);
    float att = 1.0f / (1.0f + std::pow(std::max(0.0f, dist - 1.5f) / 7.0f, 2.0f));
    float pan = dist > 0.01f ? glm::dot(d / dist, mLRight) : 0.0f;
    float behind = dist > 0.01f ? glm::dot(d / dist, mLFwd) : 1.0f;
    float muffle = behind < 0 ? 0.85f : 1.0f;
    float l = std::sqrt(0.5f * (1 - pan * 0.8f)), r = std::sqrt(0.5f * (1 + pan * 0.8f));
    v.gainL = g * att * l * 1.41f * muffle;
    v.gainR = g * att * r * 1.41f * muffle;
}

uint32_t Audio::play(SoundId id, const vec3& pos, float volume, float pitch, bool spatial, bool loop, SoundCat cat) {
    if (id < 0 || id >= SND_COUNT || mBuffers[id].data.empty()) return 0;
    std::lock_guard<std::mutex> l(mMutex);
    if (spatial && !loop && glm::distance(pos, mLPos) > 90.0f) return 0;
    int slot = -1;
    float quietest = 1e9f;
    for (int i = 0; i < MAX_VOICES; ++i) {
        if (!mVoices[i].active) { slot = i; break; }
        if (!mVoices[i].loop) {
            float g = mVoices[i].gainL + mVoices[i].gainR;
            if (g < quietest) { quietest = g; slot = i; }
        }
    }
    if (slot < 0) return 0;
    Voice& v = mVoices[slot];
    v = Voice();
    v.handle = mNextHandle++;
    if (mNextHandle == 0) mNextHandle = 1;
    v.buf = id; v.cursor = 0; v.pitch = pitch; v.volume = volume; v.pos = pos;
    v.spatial = spatial; v.loop = loop; v.active = true; v.cat = cat;
    computeGains(v);
    v.curL = v.gainL; v.curR = v.gainR;
    return v.handle;
}

void Audio::setVoice(uint32_t h, const vec3& pos, float volume, float pitch) {
    std::lock_guard<std::mutex> l(mMutex);
    for (auto& v : mVoices) if (v.active && v.handle == h) { v.pos = pos; v.volume = volume; v.pitch = pitch; computeGains(v); return; }
}

void Audio::stop(uint32_t h) {
    std::lock_guard<std::mutex> l(mMutex);
    for (auto& v : mVoices) if (v.active && v.handle == h) v.active = false;
}

bool Audio::playing(uint32_t h) {
    std::lock_guard<std::mutex> l(mMutex);
    for (auto& v : mVoices) if (v.active && v.handle == h) return true;
    return false;
}

void Audio::stopAll() {
    std::lock_guard<std::mutex> l(mMutex);
    for (auto& v : mVoices) v.active = false;
}

int Audio::activeVoices() {
    std::lock_guard<std::mutex> l(mMutex);
    int n = 0; for (auto& v : mVoices) n += v.active; return n;
}

void Audio::setListener(const vec3& pos, const vec3& fwd, const vec3& up) {
    std::lock_guard<std::mutex> l(mMutex);
    mLPos = pos; mLFwd = glm::normalize(fwd); mLRight = glm::normalize(glm::cross(mLFwd, up));
}

void Audio::update() {
    std::lock_guard<std::mutex> l(mMutex);
    for (auto& v : mVoices) if (v.active) computeGains(v);
}

void Audio::mix(float* out, int frames) {
    std::memset(out, 0, sizeof(float) * frames * 2);
    std::lock_guard<std::mutex> l(mMutex);
    for (auto& v : mVoices) {
        if (!v.active) continue;
        const auto& d = mBuffers[v.buf].data;
        const size_t n = d.size();
        float dl = (v.gainL - v.curL) / frames, dr = (v.gainR - v.curR) / frames;
        for (int i = 0; i < frames; ++i) {
            size_t i0 = (size_t)v.cursor;
            if (i0 >= n) {
                if (v.loop) { v.cursor -= n; i0 = (size_t)v.cursor; }
                else { v.active = false; break; }
            }
            size_t i1 = i0 + 1 < n ? i0 + 1 : (v.loop ? 0 : i0);
            float f = (float)(v.cursor - i0);
            float s = d[i0] + (d[i1] - d[i0]) * f;
            v.curL += dl; v.curR += dr;
            out[i * 2] += s * v.curL;
            out[i * 2 + 1] += s * v.curR;
            v.cursor += v.pitch;
        }
        v.curL = v.gainL; v.curR = v.gainR;
    }
    // soft clip
    for (int i = 0; i < frames * 2; ++i) { float x = out[i]; out[i] = x / (1.0f + std::fabs(x) * 0.6f); }
}
