#include "engine/Particles.h"
#include "destruction/VoxelWorld.h"

void Particles::spawn(PType t, const vec3& p, const vec3& v, const vec4& color, float size, float life) {
    if ((int)mPool.size() >= mMax) {
        // recycle the oldest particle of lower importance
        size_t victim = 0; float best = 1e9f;
        for (size_t i = 0; i < mPool.size(); i += 7) { float l = mPool[i].life; if (l < best) { best = l; victim = i; } }
        mPool[victim] = mPool.back(); mPool.pop_back();
    }
    Particle q;
    q.pos = p; q.vel = v; q.color = color; q.size = size; q.life = life; q.maxLife = life;
    q.rot = GRng().range(0, 6.28f); q.spin = GRng().range(-3, 3); q.type = t; q.resting = false;
    mPool.push_back(q);
}

void Particles::update(float dt, const VoxelWorld& world, const vec3& wind) {
    for (size_t i = 0; i < mPool.size();) {
        Particle& p = mPool[i];
        p.life -= dt;
        if (p.life <= 0) { mPool[i] = mPool.back(); mPool.pop_back(); continue; }
        switch (p.type) {
        case PType::Cube: case PType::Shard: {
            if (!p.resting) {
                p.vel.y -= 9.81f * dt;
                p.vel *= 1.0f - 0.2f * dt;
                vec3 np = p.pos + p.vel * dt;
                ivec3 v = VoxelWorld::toVoxel(np);
                if (IsSolid(world.get(v))) {
                    ivec3 old = VoxelWorld::toVoxel(p.pos);
                    // reflect on the axis we crossed
                    for (int a = 0; a < 3; ++a) if (old[a] != v[a]) p.vel[a] *= -0.3f;
                    p.vel *= 0.6f;
                    if (glm::length2(p.vel) < 0.4f) { p.resting = true; p.vel = vec3(0); }
                    np = p.pos;
                }
                p.pos = np;
                p.rot += p.spin * dt;
            } else if (!IsSolid(world.get(VoxelWorld::toVoxel(p.pos - vec3(0, p.size, 0))))) {
                p.resting = false;
            }
            break;
        }
        case PType::Smoke: case PType::Dust:
            p.vel += (wind * 0.4f - p.vel * 0.6f) * dt + vec3(0, p.type == PType::Smoke ? 0.6f : 0.05f, 0) * dt;
            p.pos += p.vel * dt;
            p.size += dt * (p.type == PType::Smoke ? 0.9f : 0.5f);
            break;
        case PType::Fire: case PType::Flash:
            p.pos += p.vel * dt; p.vel *= 1.0f - 2.0f * dt; p.vel.y += 1.5f * dt; p.size += dt * 0.8f;
            break;
        case PType::Spark:
            p.vel.y -= 9.81f * dt; p.pos += p.vel * dt;
            if (IsSolid(world.get(VoxelWorld::toVoxel(p.pos)))) p.life = std::min(p.life, 0.05f);
            break;
        case PType::Rain: {
            p.pos += (p.vel + wind * 0.3f) * dt;
            if (p.pos.y < 0 || IsSolid(world.get(VoxelWorld::toVoxel(p.pos)))) p.life = 0;
            break;
        }
        case PType::Splash:
            p.vel.y -= 9.81f * dt; p.pos += p.vel * dt;
            break;
        }
        ++i;
    }
}

void Particles::render(Renderer& r, const vec3& camPos) {
    for (const auto& p : mPool) {
        float t = p.life / p.maxLife;
        switch (p.type) {
        case PType::Cube: {
            if (glm::distance2(p.pos, camPos) > 80.0f * 80.0f) break;
            float s = p.size * std::min(1.0f, t * 3.0f);
            mat4 m = glm::translate(mat4(1), p.pos) * glm::rotate(mat4(1), p.rot, glm::normalize(vec3(0.3f, 1, 0.5f))) * glm::scale(mat4(1), vec3(s));
            r.drawInstance(MESH_CUBE, m, p.color, vec4(0.8f, 0, 0, 0), false);
            break;
        }
        case PType::Shard: {
            float s = p.size * std::min(1.0f, t * 3.0f);
            mat4 m = glm::translate(mat4(1), p.pos) * glm::rotate(mat4(1), p.rot, glm::normalize(vec3(1, 0.4f, 0.2f))) * glm::scale(mat4(1), vec3(s, s * 0.15f, s * 0.7f));
            r.drawInstance(MESH_CUBE, m, p.color, vec4(0.05f, 0.2f, 0, 0), false);
            break;
        }
        case PType::Smoke: case PType::Dust: {
            vec4 c = p.color; c.a *= std::min(1.0f, t * 2.0f) * std::min(1.0f, (1 - t) * 6.0f + 0.2f);
            r.drawParticle(p.pos, p.size, c, 0, p.rot);
            break;
        }
        case PType::Fire: case PType::Flash: {
            vec4 c = p.color; c.a *= t;
            r.drawParticle(p.pos, p.size, c, 0, p.rot, true);
            break;
        }
        case PType::Spark: {
            vec4 c = p.color; c.a *= t;
            r.drawParticle(p.pos, p.size, c, 2, 0, true);
            break;
        }
        case PType::Rain:
            r.drawParticle(p.pos, p.size, p.color, 1);
            break;
        case PType::Splash:
            r.drawParticle(p.pos, p.size, vec4(p.color.r, p.color.g, p.color.b, p.color.a * t), 0);
            break;
        }
    }
}
