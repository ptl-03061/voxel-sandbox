// OpenGL ES 3.0 renderer: voxel meshes, instanced primitives, particles, shadows, sky, post-processing.
#pragma once
#include "core/Common.h"
#include "destruction/Mesher.h"

#ifdef __ANDROID__
#include <GLES3/gl3.h>
#else
#include <GLES3/gl3.h>
#endif

struct GpuMesh {
    GLuint vao = 0, vbo = 0, ibo = 0;
    int opaqueCount = 0, glassCount = 0;
    bool empty() const { return opaqueCount == 0 && glassCount == 0; }
    void upload(const VoxMeshData& d);
    void release();
};

struct OcclusionState {
    GLuint query = 0;
    bool pending = false;
    bool visible = true;
    int lastTestFrame = -100;
};

enum MeshId { MESH_CUBE = 0, MESH_SPHERE, MESH_CYLINDER, MESH_CONE, MESH_COUNT };

struct PointLight { vec3 pos; float radius; vec3 color; };

struct ShaderProgram {
    GLuint id = 0;
    std::vector<std::pair<std::string, GLint>> cache;
    GLint loc(const char* name);
};

struct RenderSettings {
    int shadowSize = 2048;
    float shadowDistance = 60.0f;
    bool shadows = true;
    bool ssao = false;
    float renderScale = 1.0f;
    float viewDistance = 140.0f;
};

struct FrameParams {
    mat4 view, proj;
    vec3 camPos;
    float nearZ = 0.1f, farZ = 300.0f;
    vec3 sunDir{0.3f, 0.8f, 0.2f};
    vec3 sunColor{1, 0.95f, 0.85f};
    vec3 skyColor{0.35f, 0.55f, 0.85f};
    vec3 horizonColor{0.7f, 0.75f, 0.8f};
    vec3 groundColor{0.25f, 0.22f, 0.2f};
    vec3 fogColor{0.6f, 0.65f, 0.7f};
    float fogDensity = 0.006f;
    float fogHeight = 3.0f;
    float wetness = 0;
    float night = 0;
    float time = 0;
    float cloudCover = 0.3f;
    float emissiveScale = 1.0f;
    float flash = 0;
    float damageVignette = 0;
};

class Renderer {
public:
    bool init();
    void shutdown();
    void resize(int w, int h);
    int width() const { return mWidth; }
    int height() const { return mHeight; }

    void begin(const FrameParams& fp, const RenderSettings& rs);
    // voxel mesh: model transform, voxel size, voxel offset (for world chunks)
    void drawVoxel(const GpuMesh* m, const mat4& model, float voxelSize, const vec3& offset, const AABB& bounds,
                   OcclusionState* occ = nullptr, vec4 tint = vec4(1, 1, 1, 0), bool shadow = true);
    void drawInstance(int mesh, const mat4& model, const vec4& color, const vec4& params = vec4(0.6f, 0, 0, 0), bool shadow = true);
    void drawTransparent(int mesh, const mat4& model, const vec4& color, const vec4& params = vec4(0.3f, 0, 0.5f, 0));
    // capsule along local Y between two points, built from a cylinder and two spheres
    void drawCapsule(const vec3& a, const vec3& b, float radius, const vec4& color, const vec4& params = vec4(0.6f, 0, 0, 0));
    void drawParticle(const vec3& pos, float size, const vec4& color, int type = 0, float rot = 0, bool additive = false);
    void addLight(const PointLight& l);
    void render();

    const Frustum& frustum() const { return mFrustum; }
    bool sphereVisible(const vec3& c, float r) const { return mFrustum.testSphere(c, r); }

    struct Stats { int drawCalls = 0, voxelDraws = 0, culledOcclusion = 0, instances = 0, particles = 0, tris = 0; } stats;
    float dynamicScale = 1.0f;

private:
    bool loadPrograms();
    void createMeshes();
    void createTextures();
    void createShadowMap(int size);
    void createTargets();
    void setCommonUniforms(ShaderProgram& p);
    void renderShadows();
    void renderScene(bool glass);
    void flushInstances(ShaderProgram& p, bool shadowPass);
    void renderParticles();
    void renderOcclusionQueries();
    void renderPost();

    int mWidth = 1, mHeight = 1;
    int mTargetW = 0, mTargetH = 0;
    int mFrame = 0;
    FrameParams mFP;
    RenderSettings mRS;
    mat4 mViewProj, mLightVP;
    Frustum mFrustum, mLightFrustum;

    ShaderProgram mVoxel, mInstProg, mShadow, mSky, mParticle, mPost, mBox;
    GLuint mDetailTex = 0, mNormalTex = 0;
    GLuint mShadowTex = 0, mShadowFbo = 0;
    int mShadowSize = 0;
    GLuint mSceneFbo = 0, mSceneColor = 0, mSceneDepth = 0;
    GLuint mEmptyVao = 0;
    GLuint mInstVbo = 0;
    GLuint mParticleVao = 0, mParticleQuad = 0, mParticleInst = 0;
    GLuint mBoxVao = 0;

    struct MeshGeo { GLuint vao = 0, vbo = 0, ibo = 0; int count = 0; };
    MeshGeo mMeshes[MESH_COUNT];

    struct VoxelItem { const GpuMesh* mesh; mat4 model; float vs; vec3 offset; AABB bounds; OcclusionState* occ; vec4 tint; bool shadow; bool skip; };
    std::vector<VoxelItem> mVoxelItems;
    struct InstData { mat4 m; vec4 color; vec4 params; };
    std::vector<InstData> mInst[MESH_COUNT];
    std::vector<InstData> mInstShadow[MESH_COUNT];
    std::vector<InstData> mInstTransparent[MESH_COUNT];
    struct PartData { vec4 posSize; vec4 color; vec4 extra; };
    std::vector<PartData> mParticles, mParticlesAdd;
    std::vector<PointLight> mLights;
    std::vector<OcclusionState*> mQueryList;
public:
    // must be called before an OcclusionState is destroyed (drops pending queries, frees the GL query)
    void forgetOcclusion(OcclusionState* o);
private:
};
