#include "engine/Renderer.h"

void GenerateMaterialTextures(int size, std::vector<uint8_t>& detail, std::vector<uint8_t>& normal);

// ---------------------------------------------------------------- GpuMesh
void GpuMesh::upload(const VoxMeshData& d) {
    opaqueCount = (int)d.opaque.size();
    glassCount = (int)d.glass.size();
    if (empty()) { release(); return; }
    if (!vao) { glGenVertexArrays(1, &vao); glGenBuffers(1, &vbo); glGenBuffers(1, &ibo); }
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, d.verts.size() * sizeof(VoxVertex), d.verts.data(), GL_DYNAMIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, (d.opaque.size() + d.glass.size()) * 4, nullptr, GL_DYNAMIC_DRAW);
    if (!d.opaque.empty()) glBufferSubData(GL_ELEMENT_ARRAY_BUFFER, 0, d.opaque.size() * 4, d.opaque.data());
    if (!d.glass.empty()) glBufferSubData(GL_ELEMENT_ARRAY_BUFFER, d.opaque.size() * 4, d.glass.size() * 4, d.glass.data());
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 4, GL_SHORT, GL_FALSE, sizeof(VoxVertex), (void*)0);
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 4, GL_UNSIGNED_BYTE, GL_FALSE, sizeof(VoxVertex), (void*)8);
    glBindVertexArray(0);
}

void GpuMesh::release() {
    if (vao) { glDeleteVertexArrays(1, &vao); glDeleteBuffers(1, &vbo); glDeleteBuffers(1, &ibo); }
    vao = vbo = ibo = 0;
    opaqueCount = glassCount = 0;
}

GLint ShaderProgram::loc(const char* name) {
    for (auto& c : cache) if (c.first == name) return c.second;
    GLint l = glGetUniformLocation(id, name);
    cache.emplace_back(name, l);
    return l;
}

// ---------------------------------------------------------------- shaders
static GLuint Compile(GLenum type, const std::string& src, const char* name) {
    GLuint s = glCreateShader(type);
    const char* c = src.c_str();
    glShaderSource(s, 1, &c, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char log[4096]; glGetShaderInfoLog(s, sizeof(log), nullptr, log);
        LOGE("Shader compile error in %s:\n%s", name, log);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

static bool BuildProgram(ShaderProgram& p, const char* vsFile, const char* fsFile, bool common) {
    std::string header = "#version 300 es\nprecision highp float;\nprecision highp int;\n";
    std::string vs = Platform::ReadAssetText(std::string("shaders/") + vsFile);
    std::string fs = Platform::ReadAssetText(std::string("shaders/") + fsFile);
    if (vs.empty() || fs.empty()) { LOGE("Missing shader %s / %s", vsFile, fsFile); return false; }
    std::string fsSrc = std::string("#version 300 es\n") + (common ? Platform::ReadAssetText("shaders/common.glsl") : std::string("precision highp float;\n")) + fs;
    GLuint v = Compile(GL_VERTEX_SHADER, header + vs, vsFile);
    GLuint f = Compile(GL_FRAGMENT_SHADER, fsSrc, fsFile);
    if (!v || !f) return false;
    p.id = glCreateProgram();
    glAttachShader(p.id, v); glAttachShader(p.id, f);
    glLinkProgram(p.id);
    glDeleteShader(v); glDeleteShader(f);
    GLint ok = 0;
    glGetProgramiv(p.id, GL_LINK_STATUS, &ok);
    if (!ok) {
        char log[4096]; glGetProgramInfoLog(p.id, sizeof(log), nullptr, log);
        LOGE("Program link error %s/%s:\n%s", vsFile, fsFile, log);
        return false;
    }
    return true;
}

bool Renderer::loadPrograms() {
    bool ok = true;
    ok &= BuildProgram(mVoxel, "voxel.vert", "voxel.frag", true);
    ok &= BuildProgram(mInstProg, "inst.vert", "inst.frag", true);
    ok &= BuildProgram(mShadow, "shadow.vert", "depth.frag", false);
    ok &= BuildProgram(mSky, "sky.vert", "sky.frag", true);
    ok &= BuildProgram(mParticle, "particle.vert", "particle.frag", false);
    ok &= BuildProgram(mPost, "post.vert", "post.frag", false);
    ok &= BuildProgram(mBox, "box.vert", "depth.frag", false);
    return ok;
}

// ---------------------------------------------------------------- primitive meshes
struct PV { vec3 p, n; };
static void BuildGeo(GLuint& vao, GLuint& vbo, GLuint& ibo, const std::vector<PV>& v, const std::vector<uint16_t>& idx, GLuint instVbo) {
    glGenVertexArrays(1, &vao); glGenBuffers(1, &vbo); glGenBuffers(1, &ibo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, v.size() * sizeof(PV), v.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(PV), (void*)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(PV), (void*)12);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, idx.size() * 2, idx.data(), GL_STATIC_DRAW);
    glBindBuffer(GL_ARRAY_BUFFER, instVbo);
    const int stride = sizeof(mat4) + 2 * sizeof(vec4);
    for (int i = 0; i < 6; ++i) {
        glEnableVertexAttribArray(2 + i);
        glVertexAttribPointer(2 + i, 4, GL_FLOAT, GL_FALSE, stride, (void*)(intptr_t)(i * 16));
        glVertexAttribDivisor(2 + i, 1);
    }
    glBindVertexArray(0);
}

void Renderer::createMeshes() {
    glGenBuffers(1, &mInstVbo);
    glBindBuffer(GL_ARRAY_BUFFER, mInstVbo);
    glBufferData(GL_ARRAY_BUFFER, 1024, nullptr, GL_STREAM_DRAW);
    // cube
    {
        std::vector<PV> v; std::vector<uint16_t> i;
        for (int f = 0; f < 6; ++f) {
            int d = f / 2; float s = (f & 1) ? -1.f : 1.f;
            vec3 n(0); n[d] = s;
            vec3 u(0), w(0); u[(d + 1) % 3] = 1; w[(d + 2) % 3] = 1;
            uint16_t b = (uint16_t)v.size();
            vec3 c = n * 0.5f;
            v.push_back({c - u * 0.5f - w * 0.5f, n}); v.push_back({c + u * 0.5f - w * 0.5f, n});
            v.push_back({c + u * 0.5f + w * 0.5f, n}); v.push_back({c - u * 0.5f + w * 0.5f, n});
            if (s > 0) { uint16_t q[] = {0, 1, 2, 0, 2, 3}; for (auto k : q) i.push_back(b + k); }
            else { uint16_t q[] = {0, 2, 1, 0, 3, 2}; for (auto k : q) i.push_back(b + k); }
        }
        auto& m = mMeshes[MESH_CUBE]; BuildGeo(m.vao, m.vbo, m.ibo, v, i, mInstVbo); m.count = (int)i.size();
    }
    // sphere (radius 0.5)
    {
        std::vector<PV> v; std::vector<uint16_t> i;
        const int R = 12, S = 16;
        for (int r = 0; r <= R; ++r)
            for (int s = 0; s <= S; ++s) {
                float th = r * 3.14159f / R, ph = s * 2 * 3.14159f / S;
                vec3 n(std::sin(th) * std::cos(ph), std::cos(th), std::sin(th) * std::sin(ph));
                v.push_back({n * 0.5f, n});
            }
        for (int r = 0; r < R; ++r)
            for (int s = 0; s < S; ++s) {
                uint16_t a = r * (S + 1) + s, b = a + S + 1;
                i.push_back(a); i.push_back(a + 1); i.push_back(b);
                i.push_back(a + 1); i.push_back(b + 1); i.push_back(b);
            }
        auto& m = mMeshes[MESH_SPHERE]; BuildGeo(m.vao, m.vbo, m.ibo, v, i, mInstVbo); m.count = (int)i.size();
    }
    // cylinder (radius 0.5, height 1, axis Y) and cone
    for (int type = 0; type < 2; ++type) {
        std::vector<PV> v; std::vector<uint16_t> i;
        const int S = 18;
        float topR = type == 0 ? 0.5f : 0.0f;
        for (int s = 0; s <= S; ++s) {
            float a = s * 2 * 3.14159f / S;
            vec3 d(std::cos(a), 0, std::sin(a));
            vec3 n = glm::normalize(vec3(d.x, type == 0 ? 0.f : 0.5f, d.z));
            v.push_back({d * 0.5f + vec3(0, -0.5f, 0), n});
            v.push_back({d * topR + vec3(0, 0.5f, 0), n});
        }
        for (int s = 0; s < S; ++s) {
            uint16_t a = s * 2;
            i.push_back(a); i.push_back(a + 1); i.push_back(a + 2);
            i.push_back(a + 1); i.push_back(a + 3); i.push_back(a + 2);
        }
        for (int cap = 0; cap < 2; ++cap) {
            if (type == 1 && cap == 1) break;
            float y = cap ? 0.5f : -0.5f;
            vec3 n(0, cap ? 1.f : -1.f, 0);
            uint16_t c = (uint16_t)v.size();
            v.push_back({vec3(0, y, 0), n});
            for (int s = 0; s <= S; ++s) {
                float a = s * 2 * 3.14159f / S;
                v.push_back({vec3(std::cos(a) * 0.5f, y, std::sin(a) * 0.5f), n});
            }
            for (int s = 0; s < S; ++s) {
                if (cap) { i.push_back(c); i.push_back(c + 2 + s); i.push_back(c + 1 + s); }
                else { i.push_back(c); i.push_back(c + 1 + s); i.push_back(c + 2 + s); }
            }
        }
        auto& m = mMeshes[type == 0 ? MESH_CYLINDER : MESH_CONE]; BuildGeo(m.vao, m.vbo, m.ibo, v, i, mInstVbo); m.count = (int)i.size();
    }
    // particles
    {
        float quad[] = {-1, -1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1};
        glGenVertexArrays(1, &mParticleVao); glGenBuffers(1, &mParticleQuad); glGenBuffers(1, &mParticleInst);
        glBindVertexArray(mParticleVao);
        glBindBuffer(GL_ARRAY_BUFFER, mParticleQuad);
        glBufferData(GL_ARRAY_BUFFER, sizeof(quad), quad, GL_STATIC_DRAW);
        glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 8, (void*)0);
        glBindBuffer(GL_ARRAY_BUFFER, mParticleInst);
        glBufferData(GL_ARRAY_BUFFER, 1024, nullptr, GL_STREAM_DRAW);
        for (int k = 0; k < 3; ++k) {
            glEnableVertexAttribArray(1 + k);
            glVertexAttribPointer(1 + k, 4, GL_FLOAT, GL_FALSE, 48, (void*)(intptr_t)(k * 16));
            glVertexAttribDivisor(1 + k, 1);
        }
        glBindVertexArray(0);
    }
    glGenVertexArrays(1, &mEmptyVao);
    mBoxVao = mMeshes[MESH_CUBE].vao;
}

void Renderer::createTextures() {
    const int S = 128;
    std::vector<uint8_t> det, nor;
    GenerateMaterialTextures(S, det, nor);
    auto make = [&](GLuint& tex, const std::vector<uint8_t>& data) {
        glGenTextures(1, &tex);
        glBindTexture(GL_TEXTURE_2D_ARRAY, tex);
        glTexImage3D(GL_TEXTURE_2D_ARRAY, 0, GL_RGBA8, S, S, TL_COUNT, 0, GL_RGBA, GL_UNSIGNED_BYTE, data.data());
        glGenerateMipmap(GL_TEXTURE_2D_ARRAY);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);
    };
    make(mDetailTex, det);
    make(mNormalTex, nor);
}

void Renderer::createShadowMap(int size) {
    if (mShadowTex && mShadowSize == size) return;
    if (mShadowTex) { glDeleteTextures(1, &mShadowTex); glDeleteFramebuffers(1, &mShadowFbo); }
    mShadowSize = size;
    glGenTextures(1, &mShadowTex);
    glBindTexture(GL_TEXTURE_2D, mShadowTex);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, size, size, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_MODE, GL_COMPARE_REF_TO_TEXTURE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_COMPARE_FUNC, GL_LEQUAL);
    glGenFramebuffers(1, &mShadowFbo);
    glBindFramebuffer(GL_FRAMEBUFFER, mShadowFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, mShadowTex, 0);
    GLenum none = GL_NONE;
    glDrawBuffers(1, &none);
    glReadBuffer(GL_NONE);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) LOGE("Shadow framebuffer incomplete");
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

void Renderer::createTargets() {
    if (mTargetW == mWidth && mTargetH == mHeight && mSceneFbo) return;
    if (mSceneFbo) { glDeleteFramebuffers(1, &mSceneFbo); glDeleteTextures(1, &mSceneColor); glDeleteTextures(1, &mSceneDepth); }
    mTargetW = mWidth; mTargetH = mHeight;
    glGenTextures(1, &mSceneColor);
    glBindTexture(GL_TEXTURE_2D, mSceneColor);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, mTargetW, mTargetH, 0, GL_RGBA, GL_UNSIGNED_BYTE, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenTextures(1, &mSceneDepth);
    glBindTexture(GL_TEXTURE_2D, mSceneDepth);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT24, mTargetW, mTargetH, 0, GL_DEPTH_COMPONENT, GL_UNSIGNED_INT, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenFramebuffers(1, &mSceneFbo);
    glBindFramebuffer(GL_FRAMEBUFFER, mSceneFbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, mSceneColor, 0);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, mSceneDepth, 0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) LOGE("Scene framebuffer incomplete");
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
}

bool Renderer::init() {
    if (!loadPrograms()) return false;
    createMeshes();
    createTextures();
    createShadowMap(2048);
    LOGI("Renderer: %s / %s", (const char*)glGetString(GL_RENDERER), (const char*)glGetString(GL_VERSION));
    return true;
}

void Renderer::shutdown() {
    // GL context teardown releases all objects.
}

void Renderer::resize(int w, int h) {
    mWidth = std::max(1, w); mHeight = std::max(1, h);
    createTargets();
}

// ---------------------------------------------------------------- submission
void Renderer::begin(const FrameParams& fp, const RenderSettings& rs) {
    mFP = fp; mRS = rs;
    mViewProj = fp.proj * fp.view;
    mFrustum.fromMatrix(mViewProj);
    mVoxelItems.clear();
    for (int i = 0; i < MESH_COUNT; ++i) { mInst[i].clear(); mInstShadow[i].clear(); mInstTransparent[i].clear(); }
    mParticles.clear(); mParticlesAdd.clear();
    mLights.clear();
    stats = Stats();
    createShadowMap(rs.shadowSize);

    // fit an orthographic shadow volume around the camera, snapped to texels to avoid shimmering
    mat4 invView = glm::inverse(fp.view);
    vec3 fwd = -vec3(invView[2]);
    float r = rs.shadowDistance * 0.55f;
    vec3 center = fp.camPos + fwd * (rs.shadowDistance * 0.4f);
    vec3 L = glm::normalize(fp.sunDir);
    vec3 up = std::fabs(L.y) > 0.95f ? vec3(1, 0, 0) : vec3(0, 1, 0);
    mat4 lv = glm::lookAt(vec3(0), -L, up);
    vec3 lc = vec3(lv * vec4(center, 1));
    float texel = 2 * r / rs.shadowSize;
    lc.x = std::floor(lc.x / texel) * texel; lc.y = std::floor(lc.y / texel) * texel;
    vec3 snapped = vec3(glm::inverse(lv) * vec4(lc, 1));
    mat4 lightView = glm::lookAt(snapped + L * 120.0f, snapped, up);
    mat4 lightProj = glm::ortho(-r, r, -r, r, 1.0f, 260.0f);
    mLightVP = lightProj * lightView;
    mLightFrustum.fromMatrix(mLightVP);
}

void Renderer::drawVoxel(const GpuMesh* m, const mat4& model, float vs, const vec3& offset, const AABB& bounds, OcclusionState* occ, vec4 tint, bool shadow) {
    if (!m || m->empty()) return;
    bool inView = mFrustum.testAABB(bounds.mn, bounds.mx);
    bool inShadow = shadow && mRS.shadows && mLightFrustum.testAABB(bounds.mn, bounds.mx) &&
                    glm::distance(bounds.center(), mFP.camPos) < mRS.shadowDistance * 1.2f + glm::length(bounds.extent());
    if (!inView && !inShadow) return;
    VoxelItem it{m, model, vs, offset, bounds, occ, tint, inShadow, !inView};
    mVoxelItems.push_back(it);
}

void Renderer::drawInstance(int mesh, const mat4& model, const vec4& color, const vec4& params, bool shadow) {
    vec3 p = vec3(model[3]);
    float rad = std::max(glm::length(vec3(model[0])), std::max(glm::length(vec3(model[1])), glm::length(vec3(model[2])))) * 0.9f;
    if (mFrustum.testSphere(p, rad)) mInst[mesh].push_back({model, color, params});
    if (shadow && mRS.shadows && glm::distance(p, mFP.camPos) < mRS.shadowDistance) mInstShadow[mesh].push_back({model, color, params});
}

void Renderer::drawTransparent(int mesh, const mat4& model, const vec4& color, const vec4& params) {
    mInstTransparent[mesh].push_back({model, color, params});
}

void Renderer::drawCapsule(const vec3& a, const vec3& b, float radius, const vec4& color, const vec4& params) {
    vec3 d = b - a;
    float len = glm::length(d);
    vec3 y = len > 1e-4f ? d / len : vec3(0, 1, 0);
    vec3 x = std::fabs(y.y) < 0.9f ? glm::normalize(glm::cross(y, vec3(0, 1, 0))) : vec3(1, 0, 0);
    vec3 z = glm::cross(x, y);
    mat4 m(1);
    m[0] = vec4(x * radius * 2.0f, 0); m[1] = vec4(y * len, 0); m[2] = vec4(z * radius * 2.0f, 0); m[3] = vec4((a + b) * 0.5f, 1);
    drawInstance(MESH_CYLINDER, m, color, params);
    mat4 s = glm::scale(glm::translate(mat4(1), a), vec3(radius * 2));
    drawInstance(MESH_SPHERE, s, color, params);
    s = glm::scale(glm::translate(mat4(1), b), vec3(radius * 2));
    drawInstance(MESH_SPHERE, s, color, params);
}

void Renderer::drawParticle(const vec3& pos, float size, const vec4& color, int type, float rot, bool additive) {
    if (!mFrustum.testSphere(pos, size * (type == 1 ? 14.f : 1.f))) return;
    (additive ? mParticlesAdd : mParticles).push_back({vec4(pos, size), color, vec4((float)type, rot, 0, 0)});
}

void Renderer::addLight(const PointLight& l) { mLights.push_back(l); }

// ---------------------------------------------------------------- rendering
void Renderer::setCommonUniforms(ShaderProgram& p) {
    glUniform3fv(p.loc("uSunDir"), 1, glm::value_ptr(glm::normalize(mFP.sunDir)));
    glUniform3fv(p.loc("uSunColor"), 1, glm::value_ptr(mFP.sunColor));
    glUniform3fv(p.loc("uSkyColor"), 1, glm::value_ptr(mFP.skyColor));
    glUniform3fv(p.loc("uHorizonColor"), 1, glm::value_ptr(mFP.horizonColor));
    glUniform3fv(p.loc("uGroundColor"), 1, glm::value_ptr(mFP.groundColor));
    glUniform3fv(p.loc("uFogColor"), 1, glm::value_ptr(mFP.fogColor));
    glUniform1f(p.loc("uFogDensity"), mFP.fogDensity);
    glUniform1f(p.loc("uFogHeight"), mFP.fogHeight);
    glUniform3fv(p.loc("uCamPos"), 1, glm::value_ptr(mFP.camPos));
    glUniformMatrix4fv(p.loc("uLightVP"), 1, GL_FALSE, glm::value_ptr(mLightVP));
    glUniformMatrix4fv(p.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(mViewProj));
    glUniform1f(p.loc("uShadowTexel"), 1.0f / mShadowSize);
    glUniform1f(p.loc("uShadowEnabled"), mRS.shadows ? 1.f : 0.f);
    glUniform1f(p.loc("uWetness"), mFP.wetness);
    glUniform1f(p.loc("uNight"), mFP.night);
    glUniform1f(p.loc("uTime"), mFP.time);
    glUniform1f(p.loc("uEmissiveScale"), mFP.emissiveScale);
    // choose the 8 lights closest to the camera
    std::sort(mLights.begin(), mLights.end(), [&](const PointLight& a, const PointLight& b) {
        return glm::distance2(a.pos, mFP.camPos) - a.radius * a.radius < glm::distance2(b.pos, mFP.camPos) - b.radius * b.radius;
    });
    int n = std::min<int>(8, (int)mLights.size());
    vec4 lp[8], lcol[8];
    for (int i = 0; i < n; ++i) { lp[i] = vec4(mLights[i].pos, mLights[i].radius); lcol[i] = vec4(mLights[i].color, 1); }
    glUniform1i(p.loc("uNumLights"), n);
    if (n) { glUniform4fv(p.loc("uLightPos"), n, &lp[0].x); glUniform4fv(p.loc("uLightColor"), n, &lcol[0].x); }
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, mShadowTex);
    glUniform1i(p.loc("uShadowMap"), 0);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D_ARRAY, mDetailTex);
    glUniform1i(p.loc("uDetailTex"), 1);
    glActiveTexture(GL_TEXTURE2); glBindTexture(GL_TEXTURE_2D_ARRAY, mNormalTex);
    glUniform1i(p.loc("uNormalTex"), 2);
}

void Renderer::flushInstances(ShaderProgram& p, bool shadowPass) {
    (void)p;
    for (int m = 0; m < MESH_COUNT; ++m) {
        auto& list = shadowPass ? mInstShadow[m] : mInst[m];
        if (list.empty()) continue;
        glBindBuffer(GL_ARRAY_BUFFER, mInstVbo);
        glBufferData(GL_ARRAY_BUFFER, list.size() * sizeof(InstData), list.data(), GL_STREAM_DRAW);
        glBindVertexArray(mMeshes[m].vao);
        glDrawElementsInstanced(GL_TRIANGLES, mMeshes[m].count, GL_UNSIGNED_SHORT, nullptr, (GLsizei)list.size());
        stats.drawCalls++;
        if (!shadowPass) stats.instances += (int)list.size();
    }
}

void Renderer::renderShadows() {
    glBindFramebuffer(GL_FRAMEBUFFER, mShadowFbo);
    glViewport(0, 0, mShadowSize, mShadowSize);
    glClear(GL_DEPTH_BUFFER_BIT);
    if (!mRS.shadows) return;
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
    glEnable(GL_POLYGON_OFFSET_FILL);
    glPolygonOffset(1.5f, 3.0f);
    glDisable(GL_CULL_FACE);
    glUseProgram(mShadow.id);
    glUniformMatrix4fv(mShadow.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(mLightVP));
    glUniform1f(mShadow.loc("uInstanced"), 0.f);
    for (auto& it : mVoxelItems) {
        if (!it.shadow || it.mesh->opaqueCount == 0) continue;
        glUniformMatrix4fv(mShadow.loc("uModel"), 1, GL_FALSE, glm::value_ptr(it.model));
        glUniform1f(mShadow.loc("uVoxelSize"), it.vs);
        glUniform3fv(mShadow.loc("uOffset"), 1, glm::value_ptr(it.offset));
        glBindVertexArray(it.mesh->vao);
        glDrawElements(GL_TRIANGLES, it.mesh->opaqueCount, GL_UNSIGNED_INT, nullptr);
        stats.drawCalls++;
    }
    glUniform1f(mShadow.loc("uInstanced"), 1.f);
    flushInstances(mShadow, true);
    glDisable(GL_POLYGON_OFFSET_FILL);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
}

void Renderer::renderScene(bool glass) {
    if (!glass) {
        glUseProgram(mVoxel.id);
        setCommonUniforms(mVoxel);
        // material table
        static vec4 mc[40], mp[40];
        for (int i = 0; i < M_COUNT; ++i) {
            const auto& mi = MatInfo((uint8_t)i);
            mc[i] = vec4(mi.color, mi.colorJitter);
            mp[i] = vec4(mi.roughness, mi.metallic, mi.emissive, (float)mi.texLayer);
        }
        glUniform4fv(mVoxel.loc("uMatColor"), M_COUNT, &mc[0].x);
        glUniform4fv(mVoxel.loc("uMatParams"), M_COUNT, &mp[0].x);
    } else {
        glUseProgram(mVoxel.id);
    }
    glUniform1f(mVoxel.loc("uGlassPass"), glass ? 1.f : 0.f);
    for (auto& it : mVoxelItems) {
        if (it.skip) continue;
        int count = glass ? it.mesh->glassCount : it.mesh->opaqueCount;
        if (!count) continue;
        if (!glass && it.occ && !it.occ->visible && !it.bounds.contains(mFP.camPos)) { stats.culledOcclusion++; continue; }
        glUniformMatrix4fv(mVoxel.loc("uModel"), 1, GL_FALSE, glm::value_ptr(it.model));
        glUniform1f(mVoxel.loc("uVoxelSize"), it.vs);
        glUniform3fv(mVoxel.loc("uOffset"), 1, glm::value_ptr(it.offset));
        glUniform4fv(mVoxel.loc("uTint"), 1, glm::value_ptr(it.tint));
        glBindVertexArray(it.mesh->vao);
        glDrawElements(GL_TRIANGLES, count, GL_UNSIGNED_INT, (void*)(intptr_t)(glass ? it.mesh->opaqueCount * 4 : 0));
        stats.drawCalls++; stats.voxelDraws++; stats.tris += count / 3;
    }
    if (!glass) {
        glUseProgram(mInstProg.id);
        setCommonUniforms(mInstProg);
        flushInstances(mInstProg, false);
    }
}

void Renderer::renderOcclusionQueries() {
    // Issue occlusion queries for world chunks; results are consumed next frame.
    glUseProgram(mBox.id);
    glUniformMatrix4fv(mBox.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(mViewProj));
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE);
    glDepthMask(GL_FALSE);
    glDisable(GL_CULL_FACE);
    glBindVertexArray(mBoxVao);
    int issued = 0;
    for (auto& it : mVoxelItems) {
        if (!it.occ || it.skip) continue;
        OcclusionState* o = it.occ;
        if (o->pending) continue;
        // visible chunks are re-tested less often; hidden chunks every frame
        if (o->visible && (mFrame - o->lastTestFrame) < 6) continue;
        if (it.bounds.contains(mFP.camPos)) { o->visible = true; continue; }
        if (!o->query) glGenQueries(1, &o->query);
        vec3 pad(0.3f);
        glUniform3fv(mBox.loc("uMin"), 1, glm::value_ptr(it.bounds.mn - pad));
        glUniform3fv(mBox.loc("uMax"), 1, glm::value_ptr(it.bounds.mx + pad));
        glBeginQuery(GL_ANY_SAMPLES_PASSED_CONSERVATIVE, o->query);
        glDrawElements(GL_TRIANGLES, mMeshes[MESH_CUBE].count, GL_UNSIGNED_SHORT, nullptr);
        glEndQuery(GL_ANY_SAMPLES_PASSED_CONSERVATIVE);
        o->pending = true;
        o->lastTestFrame = mFrame;
        mQueryList.push_back(o);
        if (++issued > 160) break;
    }
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE);
    glDepthMask(GL_TRUE);
    glEnable(GL_CULL_FACE);
}

void Renderer::renderParticles() {
    if (mParticles.empty() && mParticlesAdd.empty()) return;
    glUseProgram(mParticle.id);
    mat4 inv = glm::inverse(mFP.view);
    glUniformMatrix4fv(mParticle.loc("uViewProj"), 1, GL_FALSE, glm::value_ptr(mViewProj));
    glUniform3fv(mParticle.loc("uCamRight"), 1, glm::value_ptr(vec3(inv[0])));
    glUniform3fv(mParticle.loc("uCamUp"), 1, glm::value_ptr(vec3(inv[1])));
    glUniform3fv(mParticle.loc("uCamPos"), 1, glm::value_ptr(mFP.camPos));
    glBindVertexArray(mParticleVao);
    glDepthMask(GL_FALSE);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    for (int pass = 0; pass < 2; ++pass) {
        auto& list = pass ? mParticlesAdd : mParticles;
        if (list.empty()) continue;
        if (pass) glBlendFunc(GL_SRC_ALPHA, GL_ONE); else glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glBindBuffer(GL_ARRAY_BUFFER, mParticleInst);
        glBufferData(GL_ARRAY_BUFFER, list.size() * sizeof(PartData), list.data(), GL_STREAM_DRAW);
        glDrawArraysInstanced(GL_TRIANGLES, 0, 6, (GLsizei)list.size());
        stats.drawCalls++; stats.particles += (int)list.size();
    }
    glDisable(GL_BLEND);
    glDepthMask(GL_TRUE);
    glEnable(GL_CULL_FACE);
}

void Renderer::renderPost() {
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glViewport(0, 0, mWidth, mHeight);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_CULL_FACE);
    glUseProgram(mPost.id);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, mSceneColor);
    glUniform1i(mPost.loc("uColor"), 0);
    glActiveTexture(GL_TEXTURE1); glBindTexture(GL_TEXTURE_2D, mSceneDepth);
    glUniform1i(mPost.loc("uDepth"), 1);
    float s = mRS.renderScale * dynamicScale;
    int vw = std::max(1, (int)(mWidth * s)), vh = std::max(1, (int)(mHeight * s));
    glUniform2f(mPost.loc("uScale"), (float)vw / mTargetW, (float)vh / mTargetH);
    glUniform2f(mPost.loc("uTexel"), 1.0f / mTargetW, 1.0f / mTargetH);
    glUniform1f(mPost.loc("uSSAO"), mRS.ssao ? 1.f : 0.f);
    glUniform1f(mPost.loc("uNear"), mFP.nearZ);
    glUniform1f(mPost.loc("uFar"), mFP.farZ);
    glUniform1f(mPost.loc("uFlash"), mFP.flash);
    glUniform1f(mPost.loc("uDamageVignette"), mFP.damageVignette);
    glBindVertexArray(mEmptyVao);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    stats.drawCalls++;
}

void Renderer::forgetOcclusion(OcclusionState* o) {
    if (!o) return;
    for (size_t i = 0; i < mQueryList.size();) {
        if (mQueryList[i] == o) { mQueryList[i] = mQueryList.back(); mQueryList.pop_back(); }
        else ++i;
    }
    for (auto& it : mVoxelItems) if (it.occ == o) it.occ = nullptr;
    if (o->query) { glDeleteQueries(1, &o->query); o->query = 0; }
    o->pending = false; o->visible = true;
}

void Renderer::render() {
    ++mFrame;
    // collect finished occlusion queries
    for (size_t i = 0; i < mQueryList.size();) {
        OcclusionState* o = mQueryList[i];
        GLuint avail = 0;
        glGetQueryObjectuiv(o->query, GL_QUERY_RESULT_AVAILABLE, &avail);
        if (avail) {
            GLuint res = 0;
            glGetQueryObjectuiv(o->query, GL_QUERY_RESULT, &res);
            o->visible = res != 0;
            o->pending = false;
            mQueryList[i] = mQueryList.back(); mQueryList.pop_back();
        } else if (mFrame - o->lastTestFrame > 8) {
            o->pending = false; o->visible = true;
            mQueryList[i] = mQueryList.back(); mQueryList.pop_back();
        } else ++i;
    }

    renderShadows();

    float s = mRS.renderScale * dynamicScale;
    int vw = std::max(1, (int)(mWidth * s)), vh = std::max(1, (int)(mHeight * s));
    glBindFramebuffer(GL_FRAMEBUFFER, mSceneFbo);
    glViewport(0, 0, vw, vh);
    glClearColor(mFP.fogColor.r, mFP.fogColor.g, mFP.fogColor.b, 1);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glDisable(GL_BLEND);
    renderScene(false);

    // sky fills pixels with no geometry
    glDepthMask(GL_FALSE);
    glUseProgram(mSky.id);
    setCommonUniforms(mSky);
    glUniformMatrix4fv(mSky.loc("uInvViewProj"), 1, GL_FALSE, glm::value_ptr(glm::inverse(mViewProj)));
    glUniform1f(mSky.loc("uCloudCover"), mFP.cloudCover);
    glBindVertexArray(mEmptyVao);
    glDisable(GL_CULL_FACE);
    glDrawArrays(GL_TRIANGLES, 0, 3);
    glEnable(GL_CULL_FACE);
    glDepthMask(GL_TRUE);

    renderOcclusionQueries();

    // transparent voxels (glass) and transparent instances
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDepthMask(GL_FALSE);
    renderScene(true);
    bool anyT = false;
    for (int m = 0; m < MESH_COUNT; ++m) anyT |= !mInstTransparent[m].empty();
    if (anyT) {
        glUseProgram(mInstProg.id);
        setCommonUniforms(mInstProg);
        for (int m = 0; m < MESH_COUNT; ++m) std::swap(mInst[m], mInstTransparent[m]);
        flushInstances(mInstProg, false);
        for (int m = 0; m < MESH_COUNT; ++m) std::swap(mInst[m], mInstTransparent[m]);
    }
    glDepthMask(GL_TRUE);
    glDisable(GL_BLEND);
    renderParticles();

    renderPost();
    glBindVertexArray(0);
}
