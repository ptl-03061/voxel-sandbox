// Software audio mixer with 3D spatialization and a procedurally synthesized sound bank.
#pragma once
#include "core/Common.h"
#include <mutex>

enum SoundId {
    SND_WOOD_HIT, SND_WOOD_BREAK, SND_GLASS_HIT, SND_GLASS_BREAK, SND_METAL_HIT, SND_METAL_HEAVY,
    SND_CONCRETE_HIT, SND_CONCRETE_BREAK, SND_COLLAPSE, SND_DIRT_HIT, SND_SOFT_HIT, SND_EXPLOSION,
    SND_STEP_CONCRETE, SND_STEP_WOOD, SND_STEP_METAL, SND_STEP_DIRT, SND_STEP_SOFT,
    SND_UI_CLICK, SND_UI_BACK, SND_LAND, SND_THROW, SND_SPAWN, SND_HORN, SND_DOOR, SND_SWITCH,
    SND_THUNDER, SND_ENGINE, SND_AMB_WIND, SND_AMB_BIRDS, SND_AMB_NIGHT, SND_AMB_RAIN, SND_SWING,
    SND_CANNON, SND_HUM, SND_SKID, SND_BODY_HIT, SND_COUNT
};

enum class SoundCat : uint8_t { Sfx, Ambient, Ui };

class Audio {
public:
    static constexpr int RATE = 48000;
    void init();
    // returns a voice handle (0 = failed)
    uint32_t play(SoundId id, const vec3& pos, float volume = 1.0f, float pitch = 1.0f, bool spatial = true, bool loop = false, SoundCat cat = SoundCat::Sfx);
    uint32_t play2D(SoundId id, float volume = 1.0f, float pitch = 1.0f, SoundCat cat = SoundCat::Ui) { return play(id, vec3(0), volume, pitch, false, false, cat); }
    void setVoice(uint32_t h, const vec3& pos, float volume, float pitch);
    void stop(uint32_t h);
    bool playing(uint32_t h);
    void setListener(const vec3& pos, const vec3& fwd, const vec3& up);
    void update();   // recompute spatial gains (main thread)
    void mix(float* stereoOut, int frames);  // audio thread
    void stopAll();

    float masterVolume = 0.9f, sfxVolume = 1.0f, ambientVolume = 0.7f, uiVolume = 0.8f;
    int activeVoices();
    bool hasDevice = false;

private:
    struct Buffer { std::vector<float> data; };
    struct Voice {
        uint32_t handle = 0;
        int buf = -1;
        double cursor = 0;
        float pitch = 1, volume = 1;
        float gainL = 0, gainR = 0, curL = 0, curR = 0;
        vec3 pos{0};
        bool spatial = false, loop = false, active = false;
        SoundCat cat = SoundCat::Sfx;
    };
    void synthesize();
    Buffer mBuffers[SND_COUNT];
    static constexpr int MAX_VOICES = 48;
    Voice mVoices[MAX_VOICES];
    uint32_t mNextHandle = 1;
    vec3 mLPos{0}, mLFwd{0, 0, -1}, mLRight{1, 0, 0};
    std::mutex mMutex;
    void computeGains(Voice& v);
};

Audio& GAudio();
