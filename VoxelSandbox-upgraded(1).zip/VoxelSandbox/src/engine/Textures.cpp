// Procedural PBR detail textures: albedo modulation + roughness, and tangent-space normal maps.
// Generated at startup so the game needs no external texture files (all content is original).
#include "destruction/Voxel.h"

namespace {
int gSize = 128;

float vhash(int x, int y, int seed) {
    x = ((x % gSize) + gSize) % gSize; y = ((y % gSize) + gSize) % gSize;
    return Hash01(Hash3i(x, y, seed));
}
// tileable value noise, period = gSize / cell
float vnoise(float x, float y, int cell, int seed) {
    float fx = x / cell, fy = y / cell;
    int ix = (int)std::floor(fx), iy = (int)std::floor(fy);
    float tx = fx - ix, ty = fy - iy;
    int per = gSize / cell;
    auto h = [&](int a, int b) { a = ((a % per) + per) % per; b = ((b % per) + per) % per; return Hash01(Hash3i(a, b, seed)); };
    float u = tx * tx * (3 - 2 * tx), v = ty * ty * (3 - 2 * ty);
    return Lerp(Lerp(h(ix, iy), h(ix + 1, iy), u), Lerp(h(ix, iy + 1), h(ix + 1, iy + 1), u), v);
}
float fbm(float x, float y, int seed, int oct = 4, int cell = 32) {
    float s = 0, a = 0.5f, n = 0;
    for (int i = 0; i < oct && cell >= 1; ++i) { s += a * vnoise(x, y, cell, seed + i * 31); n += a; a *= 0.5f; cell /= 2; }
    return s / n;
}

struct Texel { float h; vec3 alb; float rough; };

Texel Sample(int layer, int x, int y) {
    const float S = (float)gSize; // texture covers 1 meter
    float u = x / S, v = y / S;
    Texel t{0.5f, vec3(1.0f), 0.5f};
    switch (layer) {
    case TL_FLAT: {
        float n = fbm((float)x, (float)y, 7, 3, 16);
        t.h = 0.5f; t.alb = vec3(0.97f + 0.06f * n); t.rough = 0.5f + (n - 0.5f) * 0.1f; break;
    }
    case TL_CONCRETE: {
        float n = fbm((float)x, (float)y, 11, 5, 32);
        float pit = vhash(x, y, 3) > 0.985f ? -0.4f : 0.f;
        t.h = 0.5f + (n - 0.5f) * 0.5f + pit; t.alb = vec3(0.9f + 0.2f * n + pit * 0.3f); t.rough = 0.55f + n * 0.1f; break;
    }
    case TL_PLASTER: {
        float n = fbm((float)x, (float)y, 13, 4, 16);
        t.h = 0.5f + (n - 0.5f) * 0.25f; t.alb = vec3(0.95f + 0.08f * n); t.rough = 0.5f; break;
    }
    case TL_BRICK: {
        float rowH = 1.0f / 12.0f, brickW = 1.0f / 4.0f;
        int row = (int)std::floor(v / rowH);
        float uu = u + (row & 1) * brickW * 0.5f;
        float bx = std::fmod(uu, brickW) / brickW, by = std::fmod(v, rowH) / rowH;
        float mortar = (bx < 0.05f || bx > 0.95f || by < 0.1f || by > 0.9f) ? 1.f : 0.f;
        int bid = row * 8 + (int)std::floor(uu / brickW);
        float bv = Hash01(HashU32(bid * 977 + 13));
        float n = fbm((float)x, (float)y, 17, 3, 8);
        t.h = mortar > 0 ? 0.2f : 0.65f + n * 0.2f;
        t.alb = mortar > 0 ? vec3(1.45f, 1.45f, 1.4f) : vec3(0.85f + 0.3f * bv, 0.85f + 0.2f * bv, 0.9f + 0.1f * bv) * (0.9f + 0.2f * n);
        t.rough = mortar > 0 ? 0.6f : 0.5f; break;
    }
    case TL_WOOD: case TL_BARK: {
        float n = fbm((float)x * 0.25f, (float)y * 4.0f, 19, 4, 32);
        float rings = 0.5f + 0.5f * std::sin((v * 40.0f + n * 8.0f) * 3.14159f);
        if (layer == TL_BARK) {
            float f = fbm((float)x * 3.0f, (float)y * 0.4f, 23, 4, 32);
            float fiss = SmoothStep(0.45f, 0.55f, f);
            t.h = 0.3f + fiss * 0.5f; t.alb = vec3(0.7f + fiss * 0.5f); t.rough = 0.5f;
        } else {
            t.h = 0.45f + rings * 0.1f; t.alb = vec3(0.85f + rings * 0.25f, 0.85f + rings * 0.22f, 0.85f + rings * 0.18f); t.rough = 0.5f - rings * 0.06f;
        }
        break;
    }
    case TL_PLANK: {
        float bw = 0.125f;
        float bx = std::fmod(u, bw) / bw;
        int board = (int)std::floor(u / bw);
        float off = Hash01(HashU32(board * 31 + 5));
        float gap = (bx < 0.04f || bx > 0.96f) ? 1.f : 0.f;
        float joint = std::fabs(std::fmod(v + off, 0.5f)) < 0.006f ? 1.f : 0.f;
        float n = fbm((float)x * 4.0f, (float)y * 0.3f, 29, 4, 32);
        float tone = 0.85f + off * 0.3f;
        t.h = (gap + joint) > 0 ? 0.15f : 0.55f + n * 0.1f;
        t.alb = vec3(tone + n * 0.2f) * ((gap + joint) > 0 ? 0.5f : 1.0f);
        t.rough = 0.45f + n * 0.1f; break;
    }
    case TL_METAL: {
        float n = fbm((float)x * 0.1f, (float)y * 6.0f, 37, 3, 32);
        float sc = vhash(x, y, 41);
        t.h = 0.5f + (n - 0.5f) * 0.08f; t.alb = vec3(0.92f + 0.12f * n); t.rough = 0.42f + n * 0.25f + (sc > 0.99f ? 0.2f : 0.f); break;
    }
    case TL_CORRUGATED: {
        float r = 0.5f + 0.5f * std::sin(u * 3.14159f * 2.0f * 10.0f);
        float n = fbm((float)x, (float)y, 43, 4, 32);
        t.h = 0.2f + r * 0.6f; t.alb = vec3(0.85f + 0.2f * r) * (0.92f + 0.16f * n); t.rough = 0.45f + n * 0.25f; break;
    }
    case TL_ASPHALT: {
        float n = fbm((float)x, (float)y, 47, 4, 16);
        float sp = vhash(x, y, 53);
        float stone = sp > 0.93f ? 0.3f : (sp < 0.05f ? -0.2f : 0.f);
        t.h = 0.5f + (n - 0.5f) * 0.3f + stone * 0.5f; t.alb = vec3(0.85f + n * 0.3f + stone); t.rough = 0.55f + n * 0.1f; break;
    }
    case TL_GRASS: {
        float n = fbm((float)x, (float)y, 59, 4, 32);
        float bl = vhash(x, y / 3, 61);
        t.h = 0.4f + bl * 0.4f; t.alb = vec3(0.75f + n * 0.5f + bl * 0.15f, 0.85f + n * 0.35f + bl * 0.2f, 0.7f + n * 0.3f); t.rough = 0.55f; break;
    }
    case TL_DIRT: {
        float n = fbm((float)x, (float)y, 67, 5, 32);
        float pb = vhash(x / 2, y / 2, 71) > 0.95f ? 0.25f : 0.f;
        t.h = 0.4f + n * 0.3f + pb; t.alb = vec3(0.8f + n * 0.4f + pb); t.rough = 0.55f; break;
    }
    case TL_TILE: {
        float ts = 0.25f;
        float tx = std::fmod(u, ts) / ts, ty = std::fmod(v, ts) / ts;
        float grout = (tx < 0.04f || tx > 0.96f || ty < 0.04f || ty > 0.96f) ? 1.f : 0.f;
        float n = fbm((float)x, (float)y, 73, 3, 16);
        t.h = grout > 0 ? 0.25f : 0.6f; t.alb = grout > 0 ? vec3(0.6f) : vec3(0.97f + 0.06f * n); t.rough = grout > 0 ? 0.8f : 0.25f; break;
    }
    case TL_ROOF: {
        float rowH = 1.0f / 6.0f;
        int row = (int)std::floor(v / rowH);
        float by = std::fmod(v, rowH) / rowH;
        float uu = u + (row & 1) * 0.0833f;
        float bx = std::fmod(uu, 0.1666f) / 0.1666f;
        float scal = std::sqrt(std::max(0.f, 1.f - (bx - 0.5f) * (bx - 0.5f) * 4.f));
        float n = fbm((float)x, (float)y, 79, 3, 16);
        t.h = by * 0.6f * scal + 0.2f; t.alb = vec3(0.8f + 0.35f * by + n * 0.1f); t.rough = 0.5f; break;
    }
    case TL_FABRIC: {
        float wx = std::sin(x * 3.14159f / 2.0f), wy = std::sin(y * 3.14159f / 2.0f);
        float weave = ((x / 2 + y / 2) & 1) ? wx : wy;
        float n = fbm((float)x, (float)y, 83, 3, 16);
        t.h = 0.5f + weave * 0.15f; t.alb = vec3(0.9f + weave * 0.08f + n * 0.12f); t.rough = 0.55f; break;
    }
    case TL_LEAVES: {
        float n = fbm((float)x, (float)y, 89, 4, 16);
        float c = vnoise((float)x, (float)y, 8, 97);
        t.h = 0.3f + c * 0.5f; t.alb = vec3(0.6f + c * 0.8f, 0.7f + c * 0.6f + n * 0.2f, 0.55f + c * 0.4f); t.rough = 0.6f; break;
    }
    default: break;
    }
    return t;
}
}

void GenerateMaterialTextures(int size, std::vector<uint8_t>& detail, std::vector<uint8_t>& normal) {
    gSize = size;
    detail.assign((size_t)size * size * 4 * TL_COUNT, 0);
    normal.assign((size_t)size * size * 4 * TL_COUNT, 0);
    std::vector<float> hmap((size_t)size * size);
    for (int l = 0; l < TL_COUNT; ++l) {
        uint8_t* d = &detail[(size_t)l * size * size * 4];
        uint8_t* nm = &normal[(size_t)l * size * size * 4];
        for (int y = 0; y < size; ++y)
            for (int x = 0; x < size; ++x) {
                Texel t = Sample(l, x, y);
                hmap[(size_t)y * size + x] = t.h;
                size_t i = ((size_t)y * size + x) * 4;
                vec3 a = glm::clamp(t.alb * 0.5f, vec3(0.0f), vec3(1.0f));
                d[i + 0] = (uint8_t)(a.r * 255); d[i + 1] = (uint8_t)(a.g * 255); d[i + 2] = (uint8_t)(a.b * 255);
                d[i + 3] = (uint8_t)(Clamp01(t.rough) * 255);
            }
        float strength = (l == TL_FLAT) ? 0.5f : 4.0f;
        for (int y = 0; y < size; ++y)
            for (int x = 0; x < size; ++x) {
                auto H = [&](int xx, int yy) { xx = (xx + size) % size; yy = (yy + size) % size; return hmap[(size_t)yy * size + xx]; };
                float dx = (H(x + 1, y) - H(x - 1, y)) * strength;
                float dy = (H(x, y + 1) - H(x, y - 1)) * strength;
                vec3 n = glm::normalize(vec3(-dx, -dy, 1.0f));
                size_t i = ((size_t)y * size + x) * 4;
                nm[i + 0] = (uint8_t)((n.x * 0.5f + 0.5f) * 255); nm[i + 1] = (uint8_t)((n.y * 0.5f + 0.5f) * 255);
                nm[i + 2] = (uint8_t)((n.z * 0.5f + 0.5f) * 255); nm[i + 3] = 255;
            }
    }
}
