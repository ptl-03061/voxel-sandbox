#include "core/Settings.h"
#include <cstdio>
#include <map>

void Settings::applyPreset(int q) {
    quality = q;
    switch (q) {
    case Q_LOW:
        renderScale = 0.65f; shadowQuality = 1; ssao = false; viewDistance = 85.0f; maxDebris = 80; particleBudget = 700; fpsLimit = 30; break;
    case Q_MEDIUM:
        renderScale = 0.85f; shadowQuality = 2; ssao = false; viewDistance = 115.0f; maxDebris = 160; particleBudget = 1500; fpsLimit = 60; break;
    case Q_HIGH:
        renderScale = 1.0f; shadowQuality = 3; ssao = true; viewDistance = 150.0f; maxDebris = 260; particleBudget = 2600; fpsLimit = 60; break;
    default:   // Q_ULTRA
        renderScale = 1.0f; shadowQuality = 3; ssao = true; viewDistance = 200.0f; maxDebris = 400; particleBudget = 4000; fpsLimit = 60; break;
    }
}

bool Settings::save(const std::string& path) const {
    FILE* f = fopen(path.c_str(), "w");
    if (!f) return false;
    fprintf(f, "quality=%d\nrenderScale=%f\ndynamicResolution=%d\nfpsLimit=%d\nshadowQuality=%d\nssao=%d\nviewDistance=%f\n",
            quality, renderScale, dynamicResolution, fpsLimit, shadowQuality, ssao, viewDistance);
    fprintf(f, "maxDebris=%d\nparticleBudget=%d\nlookSensitivity=%f\ninvertY=%d\njoystickX=%f\njoystickY=%f\nbuttonScale=%f\nuiScale=%f\n",
            maxDebris, particleBudget, lookSensitivity, invertY, joystickX, joystickY, buttonScale, uiScale);
    fprintf(f, "masterVolume=%f\nsfxVolume=%f\nambientVolume=%f\nuiVolume=%f\nshowFps=%d\nshowDebug=%d\nfov=%f\n",
            masterVolume, sfxVolume, ambientVolume, uiVolume, showFps, showDebug, fov);
    fclose(f);
    return true;
}

bool Settings::load(const std::string& path) {
    FILE* f = fopen(path.c_str(), "r");
    if (!f) return false;
    std::map<std::string, double> kv;
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        char* eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        kv[line] = atof(eq + 1);
    }
    fclose(f);
    auto gi = [&](const char* k, int& v) { auto it = kv.find(k); if (it != kv.end()) v = (int)it->second; };
    auto gf = [&](const char* k, float& v) { auto it = kv.find(k); if (it != kv.end()) v = (float)it->second; };
    auto gb = [&](const char* k, bool& v) { auto it = kv.find(k); if (it != kv.end()) v = it->second != 0; };
    gi("quality", quality); gf("renderScale", renderScale); gb("dynamicResolution", dynamicResolution);
    gi("fpsLimit", fpsLimit); gi("shadowQuality", shadowQuality); gb("ssao", ssao); gf("viewDistance", viewDistance);
    gi("maxDebris", maxDebris); gi("particleBudget", particleBudget); gf("lookSensitivity", lookSensitivity);
    gb("invertY", invertY); gf("joystickX", joystickX); gf("joystickY", joystickY); gf("buttonScale", buttonScale);
    gf("uiScale", uiScale); gf("masterVolume", masterVolume); gf("sfxVolume", sfxVolume);
    gf("ambientVolume", ambientVolume); gf("uiVolume", uiVolume); gb("showFps", showFps); gb("showDebug", showDebug); gf("fov", fov);
    quality = glm::clamp(quality, 0, 3);
    renderScale = glm::clamp(renderScale, 0.4f, 1.0f);
    fpsLimit = fpsLimit <= 30 ? 30 : (fpsLimit <= 45 ? 45 : 60);
    shadowQuality = glm::clamp(shadowQuality, 0, 3);
    viewDistance = glm::clamp(viewDistance, 50.0f, 200.0f);
    maxDebris = glm::clamp(maxDebris, 30, 400);
    particleBudget = glm::clamp(particleBudget, 300, 4000);
    buttonScale = glm::clamp(buttonScale, 0.6f, 1.6f);
    joystickX = glm::clamp(joystickX, 0.08f, 0.4f);
    joystickY = glm::clamp(joystickY, 0.4f, 0.9f);
    fov = glm::clamp(fov, 55.0f, 95.0f);
    return true;
}
