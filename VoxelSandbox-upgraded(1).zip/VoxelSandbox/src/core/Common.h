// Common types, math aliases, logging and small utilities shared by every module.
#pragma once

#ifndef GLM_FORCE_RADIANS
#define GLM_FORCE_RADIANS
#endif
#ifndef GLM_ENABLE_EXPERIMENTAL
#define GLM_ENABLE_EXPERIMENTAL
#endif
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/quaternion.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/norm.hpp>

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <functional>
#include <memory>
#include <string>
#include <vector>

using glm::vec2;
using glm::vec3;
using glm::vec4;
using glm::ivec2;
using glm::ivec3;
using glm::mat3;
using glm::mat4;
using glm::quat;

void LogInfo(const char* fmt, ...);
void LogError(const char* fmt, ...);

#define LOGI(...) LogInfo(__VA_ARGS__)
#define LOGE(...) LogError(__VA_ARGS__)

// Fast deterministic hashing used for per-voxel variation and procedural content.
inline uint32_t HashU32(uint32_t x) {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16;
    return x;
}
inline uint32_t Hash3i(int x, int y, int z) {
    return HashU32((uint32_t)x * 73856093U ^ HashU32((uint32_t)y * 19349663U ^ HashU32((uint32_t)z * 83492791U)));
}
inline float Hash01(uint32_t h) { return (HashU32(h) & 0xFFFFFF) / 16777216.0f; }

// Thread-local xorshift RNG.
struct Rng {
    uint64_t s;
    explicit Rng(uint64_t seed = 0x9E3779B97F4A7C15ULL) : s(seed ? seed : 1) {}
    uint32_t next() { s ^= s << 13; s ^= s >> 7; s ^= s << 17; return (uint32_t)(s >> 11); }
    float f01() { return (next() & 0xFFFFFF) / 16777216.0f; }
    float range(float a, float b) { return a + (b - a) * f01(); }
    int irange(int a, int b) { return a + (int)(next() % (uint32_t)(b - a + 1)); }
    vec3 unitVec() {
        for (;;) {
            vec3 v(range(-1, 1), range(-1, 1), range(-1, 1));
            float l = glm::length2(v);
            if (l > 0.01f && l <= 1.0f) return v / std::sqrt(l);
        }
    }
};
Rng& GRng();

inline float Clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
inline float Saturate(float v) { return Clamp01(v); }
template <class T> inline T Lerp(T a, T b, float t) { return a + (b - a) * t; }
inline float SmoothStep(float a, float b, float x) { float t = Clamp01((x - a) / (b - a)); return t * t * (3 - 2 * t); }
inline float MoveTowards(float c, float t, float d) { if (std::fabs(t - c) <= d) return t; return c + (t > c ? d : -d); }

struct AABB {
    vec3 mn{1e30f}, mx{-1e30f};
    void add(const vec3& p) { mn = glm::min(mn, p); mx = glm::max(mx, p); }
    vec3 center() const { return (mn + mx) * 0.5f; }
    vec3 extent() const { return (mx - mn) * 0.5f; }
    bool contains(const vec3& p) const { return p.x >= mn.x && p.y >= mn.y && p.z >= mn.z && p.x <= mx.x && p.y <= mx.y && p.z <= mx.z; }
};

struct Frustum {
    vec4 planes[6];
    void fromMatrix(const mat4& m) {
        mat4 t = glm::transpose(m);
        planes[0] = t[3] + t[0]; planes[1] = t[3] - t[0];
        planes[2] = t[3] + t[1]; planes[3] = t[3] - t[1];
        planes[4] = t[3] + t[2]; planes[5] = t[3] - t[2];
        for (auto& p : planes) p /= glm::length(vec3(p));
    }
    bool testAABB(const vec3& mn, const vec3& mx) const {
        for (const auto& p : planes) {
            vec3 v(p.x > 0 ? mx.x : mn.x, p.y > 0 ? mx.y : mn.y, p.z > 0 ? mx.z : mn.z);
            if (glm::dot(vec3(p), v) + p.w < 0) return false;
        }
        return true;
    }
    bool testSphere(const vec3& c, float r) const {
        for (const auto& p : planes) if (glm::dot(vec3(p), c) + p.w < -r) return false;
        return true;
    }
};

// Platform services implemented separately for Android and desktop.
namespace Platform {
bool ReadAsset(const std::string& path, std::vector<uint8_t>& out);
std::string ReadAssetText(const std::string& path);
std::string WritableDir();
double TimeSeconds();
void RequestQuit();
}
