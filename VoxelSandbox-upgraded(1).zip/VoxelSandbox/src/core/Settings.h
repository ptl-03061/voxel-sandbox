// Persistent user settings (graphics, controls, audio). Stored as key=value text in the app's files dir.
#pragma once
#include "core/Common.h"

enum Quality { Q_LOW = 0, Q_MEDIUM = 1, Q_HIGH = 2, Q_ULTRA = 3 };

struct Settings {
    int quality = Q_MEDIUM;
    float renderScale = 0.85f;       // resolution scale
    bool dynamicResolution = true;
    int fpsLimit = 60;               // 30 / 45 / 60
    int shadowQuality = 1;           // 0 off, 1 low (1024), 2 medium (2048), 3 high (3072)
    bool ssao = false;
    float viewDistance = 120.0f;
    int maxDebris = 160;
    int particleBudget = 1500;
    float lookSensitivity = 1.0f;
    bool invertY = false;
    float joystickX = 0.14f;         // joystick center (fraction of screen)
    float joystickY = 0.70f;
    float buttonScale = 1.0f;
    float uiScale = 1.0f;
    float masterVolume = 0.9f, sfxVolume = 1.0f, ambientVolume = 0.7f, uiVolume = 0.8f;
    bool showFps = true;
    bool showDebug = false;
    float fov = 70.0f;

    void applyPreset(int q);
    bool load(const std::string& path);
    bool save(const std::string& path) const;
};
