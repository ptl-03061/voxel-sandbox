// Multi-touch input state fed by the platform layer (Android touch events or desktop scripted input).
#pragma once
#include "core/Common.h"
#include <mutex>

struct TouchPoint {
    int id = -1;
    vec2 pos{0}, start{0}, prev{0};
    bool down = false, began = false, ended = false;
    double t0 = 0;
    int owner = 0;          // which UI control captured this pointer (0 = none)
};

class Input {
public:
    static constexpr int MAX_TOUCH = 10;
    // platform callbacks (any thread -> queued)
    void touchDown(int id, float x, float y);
    void touchMove(int id, float x, float y);
    void touchUp(int id, float x, float y);
    void cancelAll();
    // keyboard/gamepad style debug input (desktop harness)
    vec2 keyMove{0};
    vec2 keyLook{0};
    bool keyJump = false;

    // main thread
    void beginFrame();   // applies queued events
    void endFrame();     // clears began/ended flags, removes ended touches
    TouchPoint touches[MAX_TOUCH];
    int activeCount() const;
    bool backPressed = false;

private:
    struct Ev { int type, id; float x, y; };
    std::mutex mMutex;
    std::vector<Ev> mQueue;
    void apply(const Ev& e);
};
