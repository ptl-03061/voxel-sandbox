// Minimal worker thread pool used for asynchronous world generation and chunk meshing.
#pragma once
#include <atomic>
#include <condition_variable>
#include <deque>
#include <functional>
#include <mutex>
#include <thread>
#include <vector>

class JobPool {
public:
    explicit JobPool(int threads) {
        if (threads < 1) threads = 1;
        for (int i = 0; i < threads; ++i) mThreads.emplace_back([this] { worker(); });
    }
    ~JobPool() {
        { std::lock_guard<std::mutex> l(mMutex); mQuit = true; }
        mCv.notify_all();
        for (auto& t : mThreads) t.join();
    }
    void submit(std::function<void()> fn) {
        { std::lock_guard<std::mutex> l(mMutex); mQueue.push_back(std::move(fn)); ++mPending; }
        mCv.notify_one();
    }
    void waitIdle() {
        std::unique_lock<std::mutex> l(mMutex);
        mDoneCv.wait(l, [this] { return mPending == 0; });
    }
    int pending() { std::lock_guard<std::mutex> l(mMutex); return mPending; }
    // Runs fn(i) for i in [0,n) across workers and the calling thread, then waits.
    void parallelFor(int n, const std::function<void(int)>& fn) {
        std::atomic<int> next{0};
        std::atomic<int> done{0};
        int workers = (int)mThreads.size();
        auto body = [&]() {
            for (;;) { int i = next.fetch_add(1); if (i >= n) break; fn(i); }
            done.fetch_add(1);
        };
        for (int w = 0; w < workers; ++w) submit(body);
        body();
        while (done.load() < workers + 1) std::this_thread::yield();
    }
    int threadCount() const { return (int)mThreads.size(); }

private:
    void worker() {
        for (;;) {
            std::function<void()> job;
            {
                std::unique_lock<std::mutex> l(mMutex);
                mCv.wait(l, [this] { return mQuit || !mQueue.empty(); });
                if (mQuit && mQueue.empty()) return;
                job = std::move(mQueue.front());
                mQueue.pop_front();
            }
            job();
            {
                std::lock_guard<std::mutex> l(mMutex);
                if (--mPending == 0) mDoneCv.notify_all();
            }
        }
    }
    std::vector<std::thread> mThreads;
    std::deque<std::function<void()>> mQueue;
    std::mutex mMutex;
    std::condition_variable mCv, mDoneCv;
    int mPending = 0;
    bool mQuit = false;
};
