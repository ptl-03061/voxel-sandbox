#include "core/Input.h"

void Input::touchDown(int id, float x, float y) { std::lock_guard<std::mutex> l(mMutex); mQueue.push_back({0, id, x, y}); }
void Input::touchMove(int id, float x, float y) { std::lock_guard<std::mutex> l(mMutex); mQueue.push_back({1, id, x, y}); }
void Input::touchUp(int id, float x, float y) { std::lock_guard<std::mutex> l(mMutex); mQueue.push_back({2, id, x, y}); }
void Input::cancelAll() { std::lock_guard<std::mutex> l(mMutex); mQueue.push_back({3, -1, 0, 0}); }

int Input::activeCount() const { int n = 0; for (auto& t : touches) n += t.down; return n; }

void Input::apply(const Ev& e) {
    if (e.type == 3) {
        for (auto& t : touches) if (t.down) { t.down = false; t.ended = true; }
        return;
    }
    TouchPoint* tp = nullptr;
    for (auto& t : touches) if (t.id == e.id && (t.down || t.began)) { tp = &t; break; }
    if (e.type == 0) {
        if (!tp) for (auto& t : touches) if (!t.down && !t.ended) { tp = &t; break; }
        if (!tp) return;
        *tp = TouchPoint();
        tp->id = e.id; tp->pos = tp->start = tp->prev = vec2(e.x, e.y);
        tp->down = true; tp->began = true; tp->t0 = Platform::TimeSeconds();
    } else if (tp) {
        tp->pos = vec2(e.x, e.y);
        if (e.type == 2) { tp->down = false; tp->ended = true; }
    }
}

void Input::beginFrame() {
    std::vector<Ev> q;
    { std::lock_guard<std::mutex> l(mMutex); q.swap(mQueue); }
    // a pointer that goes down and up within one frame must still register as a tap:
    // apply events but never let an "up" erase a "began" from the same frame.
    for (auto& e : q) apply(e);
}

void Input::endFrame() {
    for (auto& t : touches) {
        t.prev = t.pos;
        t.began = false;
        if (t.ended) { t.ended = false; t.id = -1; t.owner = 0; }
    }
    backPressed = false;
}
