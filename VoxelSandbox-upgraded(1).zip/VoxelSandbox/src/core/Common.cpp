#include "core/Common.h"
#include <atomic>

Rng& GRng() {
    static std::atomic<uint64_t> seeds{0x2545F4914F6CDD1DULL};
    thread_local Rng r(seeds.fetch_add(0x9E3779B97F4A7C15ULL));
    return r;
}
