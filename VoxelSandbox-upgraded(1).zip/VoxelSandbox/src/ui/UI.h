// Touch UI: main menu, loading screen, gameplay HUD (virtual joystick, look area, buttons), vehicle HUD,
// pause / settings / spawn / teleport panels. Menus use Dear ImGui driven by touch; the HUD is custom.
#pragma once
#include "core/Common.h"
#include <functional>

class Game;
struct ImFont;

class UI {
public:
    explicit UI(Game& g) : G(g) {}
    bool init(int w, int h);
    void shutdown();
    void resize(int w, int h);
    void beginFrame(float dt);     // touch -> HUD controls / ImGui events
    void render(float dt);         // draws HUD + panels
    void renderLoadingOnly();      // immediate loading screen frame (before blocking work)
    bool panelOpen() const { return mPanel != P_NONE; }

    enum Panel { P_NONE, P_PAUSE, P_SETTINGS, P_SPAWN, P_MAP, P_HELP, P_WORLD };
    void openPanel(Panel p);
    Panel panel() const { return mPanel; }

    // test harness hooks
    struct Btn {
        int id;
        vec2 c, half;        // center + half extents (circle uses half.x as radius)
        bool circle;
        std::string label;
        int kind;            // 0 tap, 1 hold, 2 toggle (tap with highlight)
        bool active;
        std::function<void()> onTap;
        bool down = false;
    };
    const std::vector<Btn>& buttons() const { return mBtns; }
    vec2 joystickCenter() const;
    float joystickRadius() const;

private:
    void buildFonts();
    void layoutHud();
    void processHud(float dt);
    void feedImGui();
    void drawHud();
    void drawMainMenu();
    void drawLoading();
    void drawPause();
    void drawSettings();
    void drawSpawn();
    void drawMap();
    void drawHelp();
    void drawWorld();
    bool bigButton(const char* label, float w = 0, float h = 0);
    void hudText(const vec2& p, const std::string& s, float size, unsigned col, bool center = false);
    Btn* findBtn(int id);
    bool held(int id);

    Game& G;
    int mW = 1, mH = 1;
    float mS = 1.0f;          // UI pixel scale (screen height / 720)
    float mFontPx = 26;
    float mBuiltFontPx = 0;
    ImFont* mFont = nullptr;
    ImFont* mBigFont = nullptr;
    Panel mPanel = P_NONE;
    Panel mReturnPanel = P_NONE;
    std::vector<Btn> mBtns;
    std::vector<uint8_t> mFontData, mFontDataBig;
    bool mSprint = false;
    bool mRotateMode = false;
    vec2 mJoyBase{0}, mJoyKnob{0};
    bool mJoyActive = false;
    std::string mHint;
    std::string mTargetInfo;
    float mInfoTimer = 0;
    float mRepeat = 0;
    int mCategory = 0;
    // ImGui touch emulation
    int mImTouch = -1;
    int mImPressDelay = 0;
    bool mImScrolling = false;
    void* mImScrollWindow = nullptr;
    vec2 mImLast{0};
    bool mInit = false;
    float mHoldDistRepeat = 0;
};
