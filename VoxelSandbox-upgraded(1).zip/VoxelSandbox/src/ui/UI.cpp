#include "ui/UI.h"
#include "Game.h"

#include "imgui.h"
#include "imgui_internal.h"
#include "imgui_impl_opengl3.h"

namespace {
enum BtnId {
    B_JUMP = 1, B_ACTION, B_THROW, B_INTERACT, B_SPRINT, B_PAUSE, B_SPAWNMENU, B_ROTATE, B_DIST_UP, B_DIST_DN,
    B_SCALE_UP, B_SCALE_DN, B_DUP, B_DEL, B_FREEZE, B_GAS, B_BRAKE, B_HANDBRAKE, B_FORK_UP, B_FORK_DN,
    B_LIGHTS, B_HORN, B_FLIP, B_EXIT, B_TOOL0 = 100
};
const unsigned COL_BTN = IM_COL32(20, 24, 30, 120);
const unsigned COL_BTN_DOWN = IM_COL32(255, 190, 60, 170);
const unsigned COL_BTN_ACTIVE = IM_COL32(60, 150, 255, 150);
const unsigned COL_EDGE = IM_COL32(255, 255, 255, 120);
const unsigned COL_TEXT = IM_COL32(255, 255, 255, 235);
inline ImVec2 V(const vec2& v) { return ImVec2(v.x, v.y); }
}

bool UI::init(int w, int h) {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
    io.ConfigInputTrickleEventQueue = true;
    ImGui::StyleColorsDark();
    if (!ImGui_ImplOpenGL3_Init("#version 300 es")) return false;
    Platform::ReadAsset("fonts/Roboto-Medium.ttf", mFontData);
    if (mFontData.empty()) LOGE("UI font missing, falling back to the built-in font");
    mInit = true;
    resize(w, h);
    buildFonts();
    return true;
}

void UI::shutdown() {
    if (!mInit) return;
    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    mInit = false;
}

void UI::resize(int w, int h) {
    mW = std::max(1, w); mH = std::max(1, h);
    mS = std::min(mH / 720.0f, mW / 1280.0f * 1.25f);
    mS = std::max(0.6f, mS);
    mFontPx = std::round(26.0f * mS * G.settings.uiScale);
}

void UI::buildFonts() {
    ImGuiIO& io = ImGui::GetIO();
    io.Fonts->Clear();
    ImFontConfig cfg;
    cfg.FontDataOwnedByAtlas = false;
    if (!mFontData.empty()) {
        mFont = io.Fonts->AddFontFromMemoryTTF(mFontData.data(), (int)mFontData.size(), mFontPx, &cfg);
        mBigFont = io.Fonts->AddFontFromMemoryTTF(mFontData.data(), (int)mFontData.size(), mFontPx * 2.2f, &cfg);
    } else {
        ImFontConfig c2; c2.SizePixels = mFontPx;
        mFont = io.Fonts->AddFontDefault(&c2);
        c2.SizePixels = mFontPx * 2;
        mBigFont = io.Fonts->AddFontDefault(&c2);
    }
    io.Fonts->Build();
    ImGui_ImplOpenGL3_DestroyFontsTexture();
    ImGui_ImplOpenGL3_CreateFontsTexture();
    mBuiltFontPx = mFontPx;
    ImGuiStyle& st = ImGui::GetStyle();
    st = ImGuiStyle();
    ImGui::StyleColorsDark(&st);
    st.WindowRounding = 10; st.FrameRounding = 8; st.GrabRounding = 8; st.ScrollbarRounding = 8;
    st.WindowPadding = ImVec2(16, 14); st.FramePadding = ImVec2(12, 10); st.ItemSpacing = ImVec2(12, 12);
    st.ScrollbarSize = 22; st.GrabMinSize = 30;
    st.Colors[ImGuiCol_WindowBg] = ImVec4(0.07f, 0.08f, 0.1f, 0.94f);
    st.Colors[ImGuiCol_Button] = ImVec4(0.18f, 0.22f, 0.28f, 1);
    st.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.25f, 0.32f, 0.42f, 1);
    st.Colors[ImGuiCol_ButtonActive] = ImVec4(0.95f, 0.65f, 0.2f, 1);
    st.Colors[ImGuiCol_SliderGrab] = ImVec4(0.95f, 0.65f, 0.2f, 1);
    st.Colors[ImGuiCol_SliderGrabActive] = ImVec4(1.0f, 0.75f, 0.3f, 1);
    st.Colors[ImGuiCol_FrameBg] = ImVec4(0.14f, 0.16f, 0.2f, 1);
    st.Colors[ImGuiCol_CheckMark] = ImVec4(0.95f, 0.65f, 0.2f, 1);
    st.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.95f, 0.65f, 0.2f, 1);
    st.Colors[ImGuiCol_Header] = ImVec4(0.2f, 0.25f, 0.32f, 1);
    float k = mS * G.settings.uiScale;
    st.ScaleAllSizes(std::max(0.75f, k));
}

void UI::openPanel(Panel p) {
    mPanel = p;
    G.paused = (p == P_PAUSE || p == P_SETTINGS || p == P_MAP || p == P_HELP || p == P_WORLD) && G.state == GameState::Playing;
    if (p != P_NONE) G.input.cancelAll();
    if (p == P_NONE) G.paused = false;
}

vec2 UI::joystickCenter() const { return vec2(G.settings.joystickX * mW, G.settings.joystickY * mH); }
float UI::joystickRadius() const { return 105.0f * mS * G.settings.buttonScale; }

UI::Btn* UI::findBtn(int id) {
    for (auto& b : mBtns) if (b.id == id) return &b;
    return nullptr;
}
bool UI::held(int id) { Btn* b = findBtn(id); return b && b->down; }

// ------------------------------------------------------------------ HUD layout
void UI::layoutHud() {
    mBtns.clear();
    float s = mS * G.settings.buttonScale;
    float W = (float)mW, H = (float)mH;
    auto circ = [&](int id, vec2 c, float r, const std::string& l, int kind, bool active, std::function<void()> f = nullptr) {
        Btn b; b.id = id; b.c = c; b.half = vec2(r); b.circle = true; b.label = l; b.kind = kind; b.active = active; b.onTap = std::move(f);
        mBtns.push_back(b);
    };
    auto rect = [&](int id, vec2 c, vec2 half, const std::string& l, int kind, bool active, std::function<void()> f = nullptr) {
        Btn b; b.id = id; b.c = c; b.half = half; b.circle = false; b.label = l; b.kind = kind; b.active = active; b.onTap = std::move(f);
        mBtns.push_back(b);
    };
    Game& g = G;
    float topY = 38 * mS;
    rect(B_PAUSE, vec2(60 * mS, topY), vec2(50, 26) * mS, "II", 0, false, [this] { openPanel(P_PAUSE); });
    if (!g.driving) {
        // tool bar
        float tw = 74 * mS, gap = 8 * mS;
        float x0 = W * 0.5f - (TOOL_COUNT * (tw * 2 + gap)) * 0.5f + tw;
        static const char* shortNames[] = {"Hand", "Hammer", "Cannon", "Bomb", "Rocket", "Spawn"};
        for (int t = 0; t < TOOL_COUNT; ++t)
            rect(B_TOOL0 + t, vec2(x0 + t * (tw * 2 + gap), topY), vec2(tw, 26 * mS), shortNames[t], 2, g.sandbox.tool == t, [this, t] {
                if (G.sandbox.holding()) G.sandbox.grabToggle(G.camPos(), G.camDir());
                G.sandbox.tool = t; mRotateMode = false;
            });
        rect(B_SPAWNMENU, vec2(W - 80 * mS, topY), vec2(70, 26) * mS, "SPAWN", 0, false, [this] { openPanel(P_SPAWN); });
        // movement side
        vec2 jc = joystickCenter();
        circ(B_SPRINT, jc + vec2(0, -joystickRadius() - 62 * s), 40 * s, "Run", 2, mSprint, [this] { mSprint = !mSprint; });
        // action side
        circ(B_JUMP, vec2(W - 100 * s, H - 100 * s), 64 * s, "Jump", 1, false);
        int tool = g.sandbox.tool;
        std::string act = tool == TOOL_HAND ? (g.sandbox.holding() ? "Drop" : "Grab") : tool == TOOL_HAMMER ? "Smash" : tool == TOOL_CANNON ? "Fire" :
                          tool == TOOL_BOMB ? "Place" : tool == TOOL_ROCKET ? "Launch" :
                          tool == TOOL_ROPE ? "Tie" : tool == TOOL_UNROPE ? "Cut" :
                          tool == TOOL_FREEZE ? "Toggle" : tool == TOOL_WELD ? "Weld" : "Spawn";
        circ(B_ACTION, vec2(W - 250 * s, H - 150 * s), 66 * s, act, tool == TOOL_HAMMER ? 1 : 0, false, [this, tool] {
            if (tool == TOOL_HAND) G.sandbox.grabToggle(G.camPos(), G.camDir());
            else if (tool == TOOL_SPAWN) G.sandbox.spawnSelected(G.camPos(), G.camDir());
            else if (tool == TOOL_ROPE || tool == TOOL_UNROPE || tool == TOOL_FREEZE || tool == TOOL_WELD) G.sandbox.useTool(G.camPos(), G.camDir());
            else G.sandbox.useTool(G.camPos(), G.camDir());
        });
        if (!mHint.empty())
            circ(B_INTERACT, vec2(W - 110 * s, H - 270 * s), 52 * s, "Use", 0, true, [this] { G.interact(); });
        if (tool == TOOL_HAND) {
            float cx = W - 64 * s, y = H * 0.24f;
            float r = 34 * s, dy = 78 * s;
            if (g.sandbox.holding()) {
                circ(B_THROW, vec2(W - 395 * s, H - 110 * s), 52 * s, "Throw", 0, false, [this] { G.sandbox.throwHeld(G.camDir()); mRotateMode = false; });
                circ(B_ROTATE, vec2(cx, y), r, "Rot", 2, mRotateMode, [this] { mRotateMode = !mRotateMode; });
                circ(B_DIST_UP, vec2(cx, y + dy), r, "Far", 1, false);
                circ(B_DIST_DN, vec2(cx, y + dy * 2), r, "Near", 1, false);
            } else {
                circ(B_SCALE_UP, vec2(cx, y), r, "Big", 0, false, [this] { G.sandbox.scaleTarget(G.camPos(), G.camDir(), 1.25f); });
                circ(B_SCALE_DN, vec2(cx, y + dy), r, "Small", 0, false, [this] { G.sandbox.scaleTarget(G.camPos(), G.camDir(), 0.8f); });
                circ(B_DUP, vec2(cx - dy, y), r, "Copy", 0, false, [this] { G.sandbox.duplicateTarget(G.camPos(), G.camDir()); });
                circ(B_DEL, vec2(cx - dy, y + dy), r, "Del", 0, false, [this] { G.sandbox.deleteTarget(G.camPos(), G.camDir()); });
                circ(B_FREEZE, vec2(cx, y + dy * 2), r, "Lock", 0, false, [this] { G.sandbox.freezeTarget(G.camPos(), G.camDir()); });
            }
        }
    } else {
        Vehicle* v = g.driving;
        circ(B_GAS, vec2(W - 110 * s, H - 120 * s), 72 * s, "GAS", 1, false);
        circ(B_BRAKE, vec2(W - 280 * s, H - 105 * s), 62 * s, "BRAKE", 1, false);
        circ(B_HANDBRAKE, vec2(W - 400 * s, H - 200 * s), 46 * s, "HB", 1, false);
        circ(B_EXIT, vec2(W - 110 * s, H - 300 * s), 46 * s, "Exit", 0, true, [this] { G.enterOrExitVehicle(); });
        circ(B_LIGHTS, vec2(W - 220 * s, H - 300 * s), 40 * s, "Light", 2, v->headlights, [this] { if (G.driving) G.driving->headlights = !G.driving->headlights; });
        circ(B_HORN, vec2(W - 320 * s, H - 330 * s), 40 * s, "Horn", 0, false, [this] { if (G.driving) GAudio().play(SND_HORN, G.driving->position(), 1.0f, 1.0f); });
        circ(B_FLIP, vec2(W - 64 * s, H * 0.25f), 38 * s, "Flip", 0, false, [this] { G.flipVehicle(); });
        if (v->type == VEH_FORKLIFT || v->type == VEH_LOADER || v->type == VEH_TRUCK) {
            const char* up = v->type == VEH_TRUCK ? "Bed+" : "Lift";
            const char* dn = v->type == VEH_TRUCK ? "Bed-" : "Lower";
            circ(B_FORK_UP, vec2(W - 64 * s, H * 0.25f + 90 * s), 38 * s, up, 1, false);
            circ(B_FORK_DN, vec2(W - 64 * s, H * 0.25f + 175 * s), 38 * s, dn, 1, false);
        }
    }
}

void UI::processHud(float dt) {
    Game& g = G;
    float W = (float)mW;
    vec2 jc = joystickCenter();
    float jr = joystickRadius();
    mJoyActive = false;
    vec2 look(0);
    for (auto& b : mBtns) b.down = false;
    float sens = g.settings.lookSensitivity * 0.0052f;
    for (auto& t : g.input.touches) {
        if (!(t.down || t.began || t.ended)) continue;
        if (t.began && t.owner == 0) {
            for (size_t i = 0; i < mBtns.size(); ++i) {
                Btn& b = mBtns[i];
                vec2 d = t.pos - b.c;
                bool hit = b.circle ? glm::length(d) <= b.half.x * 1.15f : (std::abs(d.x) <= b.half.x * 1.08f && std::abs(d.y) <= b.half.y * 1.2f);
                if (hit) {
                    t.owner = 1000 + b.id;
                    GAudio().play2D(SND_UI_CLICK, 0.35f, 1.1f);
                    if (b.onTap) b.onTap();
                    break;
                }
            }
            if (t.owner == 0) {
                bool leftZone = t.pos.x < W * 0.42f && t.pos.y > mH * 0.3f;
                if (leftZone) {
                    t.owner = 1;
                    mJoyBase = glm::distance(t.pos, jc) < jr * 1.1f ? jc : t.pos;   // floating if touched away from the base
                } else t.owner = 2;
            }
        }
        if (t.owner >= 1000) {
            if (Btn* b = findBtn(t.owner - 1000)) b->down = t.down || t.began;
        } else if (t.owner == 1 && (t.down || t.began)) {
            vec2 d = (t.pos - mJoyBase) / jr;
            float l = glm::length(d);
            if (l > 1.0f) d /= l;
            mJoyActive = true;
            mJoyKnob = mJoyBase + d * jr;
            // small dead zone, then remap
            float lm = glm::length(d);
            vec2 m = lm < 0.12f ? vec2(0) : d * ((lm - 0.12f) / 0.88f) / std::max(lm, 1e-4f);
            g.ctl.move = vec2(m.x, -m.y);
        } else if (t.owner == 2) {
            vec2 dl = t.pos - t.prev;
            if (mRotateMode && g.sandbox.holding() && !g.driving) g.sandbox.rotateHeld(dl.x * 0.012f, dl.y * 0.012f);
            else look += vec2(-dl.x * sens, -dl.y * sens * (g.settings.invertY ? -1.0f : 1.0f));
        }
    }
    if (!mJoyActive) { mJoyBase = jc; mJoyKnob = jc; }
    g.ctl.look = look;
    if (g.driving) {
        Vehicle* v = g.driving;
        VehicleInput in;
        in.steer = g.ctl.move.x;
        float fwdSpeed = glm::dot(v->velocity(), v->rotation() * vec3(0, 0, 1));
        in.throttle = g.ctl.move.y;
        if (held(B_GAS)) in.throttle = 1.0f;
        if (held(B_BRAKE)) {
            if (fwdSpeed > 0.8f) in.brake = 1.0f;
            else in.throttle = -1.0f;    // hold brake while stopped to reverse
        }
        if (in.throttle < 0 && fwdSpeed > 1.5f) { in.brake = -in.throttle; in.throttle = 0; }
        in.handbrake = held(B_HANDBRAKE);
        in.fork = held(B_FORK_UP) ? 1.0f : held(B_FORK_DN) ? -1.0f : 0.0f;
        g.ctl.veh = in;
        g.ctl.move = vec2(0);
    } else {
        g.ctl.jump = held(B_JUMP) || g.input.keyJump;
        g.ctl.sprint = mSprint && glm::length(g.ctl.move) > 0.5f;
        if (held(B_DIST_UP)) g.sandbox.changeHoldDistance(dt * 4.0f);
        if (held(B_DIST_DN)) g.sandbox.changeHoldDistance(-dt * 4.0f);
        if (held(B_ACTION) && g.sandbox.tool == TOOL_HAMMER && g.sandbox.hammerCooldown() <= 0) g.sandbox.useTool(g.camPos(), g.camDir());
    }
    // desktop debug keys (harness)
    if (glm::length(g.input.keyMove) > 0) g.ctl.move = g.input.keyMove;
    g.ctl.look += g.input.keyLook;
}

// ------------------------------------------------------------------ ImGui touch emulation
void UI::feedImGui() {
    ImGuiIO& io = ImGui::GetIO();
    TouchPoint* tp = nullptr;
    for (auto& t : G.input.touches)
        if ((t.down || t.began || t.ended) && (t.id == mImTouch)) tp = &t;
    if (!tp) {
        mImTouch = -1;
        for (auto& t : G.input.touches)
            if (t.began && t.owner == 0) { tp = &t; break; }
        if (tp) {
            mImTouch = tp->id;
            tp->owner = 3;
            mImScrolling = false;
            mImPressDelay = 1;
            io.AddMousePosEvent(tp->pos.x, tp->pos.y);
            mImLast = tp->pos;
            ImGuiContext* ctx = ImGui::GetCurrentContext();
            mImScrollWindow = nullptr;
            // find the scrollable window under the finger (last frame's layout)
            for (int i = ctx->Windows.Size - 1; i >= 0; --i) {
                ImGuiWindow* w = ctx->Windows[i];
                if (!w->Active || w->Hidden) continue;
                if (w->Rect().Contains(ImVec2(tp->pos.x, tp->pos.y))) {
                    ImGuiWindow* sw = w;
                    while (sw && sw->ScrollMax.y <= 0 && (sw->Flags & ImGuiWindowFlags_ChildWindow)) sw = sw->ParentWindow;
                    mImScrollWindow = sw;
                    break;
                }
            }
            if (tp->ended) {   // tap within a single frame: press now, release next frame
                io.AddMouseButtonEvent(0, true);
                mImPressDelay = -1;
            }
            return;
        }
    }
    if (!tp) return;
    if (mImPressDelay == -1) { io.AddMouseButtonEvent(0, false); mImTouch = -1; mImPressDelay = 0; return; }
    if (mImPressDelay > 0) { --mImPressDelay; if (!mImScrolling) io.AddMouseButtonEvent(0, true); }
    vec2 d = tp->pos - tp->start;
    if (!mImScrolling && std::abs(d.y) > 18 * mS && std::abs(d.y) > std::abs(d.x) * 1.4f && mImScrollWindow &&
        ((ImGuiWindow*)mImScrollWindow)->ScrollMax.y > 0) {
        // vertical drag over a scrollable list: cancel the press without clicking and scroll instead
        mImScrolling = true;
        io.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
        io.AddMouseButtonEvent(0, false);
    }
    if (mImScrolling) {
        ImGuiWindow* w = (ImGuiWindow*)mImScrollWindow;
        float dy = tp->pos.y - mImLast.y;
        ImGui::SetScrollY(w, glm::clamp(w->Scroll.y - dy, 0.0f, w->ScrollMax.y));
    } else {
        io.AddMousePosEvent(tp->pos.x, tp->pos.y);
        if (tp->ended || !tp->down) io.AddMouseButtonEvent(0, false);
    }
    mImLast = tp->pos;
    if (tp->ended || !tp->down) {
        if (mImScrolling) io.AddMousePosEvent(-FLT_MAX, -FLT_MAX);
        mImTouch = -1;
    }
}

// ------------------------------------------------------------------ frame
void UI::beginFrame(float dt) {
    Game& g = G;
    if (g.input.backPressed) {
        if (g.state == GameState::MainMenu && mPanel != P_SETTINGS && mPanel != P_HELP) Platform::RequestQuit();
        else if (mPanel == P_SETTINGS || mPanel == P_MAP || mPanel == P_HELP || mPanel == P_WORLD) openPanel(mReturnPanel);
        else if (mPanel != P_NONE) openPanel(P_NONE);
        else if (g.state == GameState::Playing) openPanel(P_PAUSE);
        GAudio().play2D(SND_UI_BACK, 0.4f);
    }
    bool hud = g.state == GameState::Playing && mPanel == P_NONE;
    if (hud) {
        mHint = g.interactHint();
        layoutHud();
        processHud(dt);
        mInfoTimer -= dt;
        if (mInfoTimer <= 0 && !g.driving) {
            mInfoTimer = 0.2f;
            mTargetInfo = g.sandbox.targetInfo(g.camPos(), g.camDir());
        }
    } else {
        mBtns.clear();
        // desktop keys still work in menus? no: menus pause the controls
    }
    feedImGui();
    // all remaining unowned touches in menus are ignored
}

void UI::hudText(const vec2& p, const std::string& s, float size, unsigned col, bool center) {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    ImFont* f = mFont;
    ImVec2 ts = f->CalcTextSizeA(size, FLT_MAX, 0, s.c_str());
    vec2 o = center ? p - vec2(ts.x, ts.y) * 0.5f : p;
    dl->AddText(f, size, ImVec2(o.x + 1.5f, o.y + 1.5f), IM_COL32(0, 0, 0, 160), s.c_str());
    dl->AddText(f, size, V(o), col, s.c_str());
}

void UI::drawHud() {
    Game& g = G;
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    float W = (float)mW, H = (float)mH;
    float fs = mFontPx;
    // crosshair
    vec2 c(W * 0.5f, H * 0.5f);
    if (!g.driving) {
        unsigned cc = g.sandbox.holding() ? IM_COL32(255, 200, 60, 230) : IM_COL32(255, 255, 255, 200);
        dl->AddCircle(V(c), 7 * mS, cc, 20, 2.0f * mS);
        dl->AddCircleFilled(V(c), 1.8f * mS, cc);
    }
    // joystick
    if (!g.driving || true) {
        float jr = joystickRadius();
        dl->AddCircleFilled(V(mJoyBase), jr, IM_COL32(20, 24, 30, 90), 48);
        dl->AddCircle(V(mJoyBase), jr, COL_EDGE, 48, 2.5f * mS);
        dl->AddCircleFilled(V(mJoyKnob), jr * 0.42f, mJoyActive ? COL_BTN_DOWN : IM_COL32(255, 255, 255, 90), 32);
        if (g.driving) hudText(mJoyBase + vec2(0, jr + 18 * mS), "steer / throttle", fs * 0.7f, IM_COL32(255, 255, 255, 140), true);
    }
    // buttons
    for (auto& b : mBtns) {
        unsigned fill = b.down ? COL_BTN_DOWN : (b.active ? COL_BTN_ACTIVE : COL_BTN);
        if (b.circle) {
            dl->AddCircleFilled(V(b.c), b.half.x, fill, 40);
            dl->AddCircle(V(b.c), b.half.x, COL_EDGE, 40, 2.0f * mS);
        } else {
            dl->AddRectFilled(V(b.c - b.half), V(b.c + b.half), fill, 8 * mS);
            dl->AddRect(V(b.c - b.half), V(b.c + b.half), COL_EDGE, 8 * mS, 0, 1.5f * mS);
        }
        float size = std::min(fs * 0.95f, b.half.x * 0.62f);
        if (!b.circle) size = std::min(fs * 0.85f, b.half.y * 1.1f);
        hudText(b.c, b.label, size, COL_TEXT, true);
    }
    // context hint
    if (!mHint.empty() && !g.driving) hudText(c + vec2(0, 46 * mS), mHint, fs * 0.9f, IM_COL32(255, 230, 140, 255), true);
    if (!mTargetInfo.empty() && !g.driving) hudText(c + vec2(0, 78 * mS), mTargetInfo, fs * 0.75f, IM_COL32(220, 230, 255, 220), true);
    // health bar
    if (!g.driving) {
        vec2 p0(20 * mS, H - 30 * mS), p1(220 * mS, H - 16 * mS);
        dl->AddRectFilled(V(p0), V(p1), IM_COL32(0, 0, 0, 120), 4);
        float hp = Saturate(g.player.health / 100.0f);
        dl->AddRectFilled(V(p0), ImVec2(p0.x + (p1.x - p0.x) * hp, p1.y), hp > 0.35f ? IM_COL32(90, 210, 110, 220) : IM_COL32(230, 80, 60, 230), 4);
    } else {
        Vehicle* v = g.driving;
        char buf[128];
        snprintf(buf, sizeof(buf), "%s   %.0f km/h   gear %d", VehicleName(v->type), std::abs(v->speedKmh()), v->gear());
        hudText(vec2(W * 0.5f, 34 * mS), buf, fs * 1.05f, COL_TEXT, true);
        vec2 p0(W * 0.5f - 120 * mS, 62 * mS), p1(W * 0.5f + 120 * mS, 74 * mS);
        dl->AddRectFilled(V(p0), V(p1), IM_COL32(0, 0, 0, 120), 4);
        float hp = Saturate(v->health / 100.0f);
        dl->AddRectFilled(V(p0), ImVec2(p0.x + (p1.x - p0.x) * hp, p1.y), hp > 0.35f ? IM_COL32(90, 170, 230, 220) : IM_COL32(230, 120, 50, 230), 4);
        if (v->type == VEH_FORKLIFT || v->type == VEH_LOADER) {
            snprintf(buf, sizeof(buf), "%s %.1f m", v->type == VEH_FORKLIFT ? "Fork" : "Bucket", v->forkHeight);
            hudText(vec2(W * 0.5f, 92 * mS), buf, fs * 0.8f, COL_TEXT, true);
        }
    }
    // puzzle status near plates
    std::string ps = g.inter.plateStatus(g.driving ? g.driving->position() : g.player.feet());
    if (!ps.empty()) hudText(vec2(W * 0.5f, H * 0.2f), ps, fs, IM_COL32(255, 220, 120, 255), true);
    // toast
    if (g.toastTime > 0 && !g.toast.empty()) {
        unsigned a = (unsigned)(255 * Saturate(g.toastTime));
        hudText(vec2(W * 0.5f, H * 0.3f), g.toast, fs * 0.9f, IM_COL32(255, 255, 255, a), true);
    }
    // fps / debug
    char buf[256];
    float x = 14 * mS, y = 78 * mS;   // below the tool bar
    if (g.settings.showFps) {
        snprintf(buf, sizeof(buf), "%.0f FPS  %.1f ms", g.perf.fps, g.perf.frameMs);
        hudText(vec2(x, y), buf, fs * 0.7f, IM_COL32(200, 255, 200, 220));
        y += fs * 0.8f;
    }
    if (g.settings.showDebug) {
        auto& rs = g.renderer.stats;
        snprintf(buf, sizeof(buf), "draws %d  voxel %d  occl %d  inst %d  part %d  tris %dk  res %.0f%%", rs.drawCalls, rs.voxelDraws, rs.culledOcclusion,
                 rs.instances, rs.particles, rs.tris / 1000, g.renderer.dynamicScale * g.settings.renderScale * 100);
        hudText(vec2(x, y), buf, fs * 0.6f, IM_COL32(220, 220, 255, 220)); y += fs * 0.7f;
        snprintf(buf, sizeof(buf), "phys %.1f ms (%d steps)  upd %.1f  rnd %.1f  objs %d  debris %d  ragdolls %d  dirty %d", g.perf.physMs, g.perf.physSteps,
                 g.perf.updateMs, g.perf.renderMs, g.objs.count(), g.objs.debrisCount(), g.npcs.ragdollCount(), g.world.dirtyCount());
        hudText(vec2(x, y), buf, fs * 0.6f, IM_COL32(220, 220, 255, 220)); y += fs * 0.7f;
        snprintf(buf, sizeof(buf), "voxels destroyed %d  collapses %d  fragments %d  pos %.1f %.1f %.1f  %s %.1fh", g.destr.stats.voxelsDestroyed,
                 g.destr.stats.collapses, g.destr.stats.fragments, g.camPos().x, g.camPos().y, g.camPos().z, WeatherName(g.env.weather), g.env.timeOfDay);
        hudText(vec2(x, y), buf, fs * 0.6f, IM_COL32(220, 220, 255, 220));
    }
    if (g.sandbox.tool == TOOL_SPAWN && !g.driving && g.sandbox.spawnIndex < (int)g.sandbox.catalog.size())
        hudText(vec2(W - 80 * mS, 76 * mS), g.sandbox.catalog[g.sandbox.spawnIndex].name, fs * 0.75f, IM_COL32(255, 220, 140, 255), true);
}

bool UI::bigButton(const char* label, float w, float h) {
    if (w <= 0) w = ImGui::GetContentRegionAvail().x;
    if (h <= 0) h = mFontPx * 2.0f;
    bool r = ImGui::Button(label, ImVec2(w, h));
    if (r) GAudio().play2D(SND_UI_CLICK, 0.5f);
    return r;
}

static void BeginPanel(const char* name, float w, float h, float W, float H) {
    ImGui::SetNextWindowPos(ImVec2(W * 0.5f, H * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(std::min(w, W * 0.96f), std::min(h, H * 0.94f)), ImGuiCond_Always);
    ImGui::Begin(name, nullptr, ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoSavedSettings);
}

void UI::drawMainMenu() {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    float W = (float)mW, H = (float)mH;
    dl->AddRectFilledMultiColor(ImVec2(0, 0), ImVec2(W, H), IM_COL32(30, 40, 60, 255), IM_COL32(30, 40, 60, 255), IM_COL32(10, 10, 14, 255), IM_COL32(10, 10, 14, 255));
    // stylized voxel skyline
    for (int i = 0; i < 40; ++i) {
        float bw = W / 40.0f;
        float h = (0.15f + 0.35f * Hash01((uint32_t)i * 7919u)) * H;
        unsigned c = IM_COL32(25 + i % 3 * 6, 30 + i % 4 * 5, 42, 255);
        dl->AddRectFilled(ImVec2(i * bw, H - h), ImVec2((i + 1) * bw - 2, H), c);
        for (float wy = H - h + 10; wy < H - 20; wy += 22)
            for (float wx = i * bw + 5; wx < (i + 1) * bw - 10; wx += 12)
                if (Hash01(Hash3i(i, (int)wy, (int)wx)) > 0.72f) dl->AddRectFilled(ImVec2(wx, wy), ImVec2(wx + 5, wy + 8), IM_COL32(255, 210, 120, 160));
    }
    ImGui::PushFont(mBigFont);
    const char* title = "VOXEL SANDBOX";
    ImVec2 ts = ImGui::CalcTextSize(title);
    dl->AddText(ImVec2(W * 0.5f - ts.x * 0.5f + 3, H * 0.14f + 3), IM_COL32(0, 0, 0, 200), title);
    dl->AddText(ImVec2(W * 0.5f - ts.x * 0.5f, H * 0.14f), IM_COL32(255, 190, 70, 255), title);
    ImGui::PopFont();
    const char* sub = "Harbor Heights - physics destruction playground";
    ImVec2 ss = ImGui::CalcTextSize(sub);
    dl->AddText(ImVec2(W * 0.5f - ss.x * 0.5f, H * 0.14f + ts.y + 8), IM_COL32(220, 225, 235, 255), sub);

    float pw = 420 * mS, ph = 420 * mS;
    ImGui::SetNextWindowPos(ImVec2(W * 0.5f, H * 0.62f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(ImVec2(pw, ph));
    ImGui::Begin("##menu", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings);
    if (bigButton("PLAY")) G.startLoading();
    ImGui::Text("Quality preset:");
    float bw = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 2) / 3;
    const char* qn[] = {"Low", "Medium", "High"};
    for (int q = 0; q < 3; ++q) {
        if (q) ImGui::SameLine();
        bool sel = G.settings.quality == q;
        if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.55f, 0.15f, 1));
        if (bigButton(qn[q], bw, mFontPx * 1.7f)) { G.settings.applyPreset(q); G.applySettings(); G.saveSettings(); }
        if (sel) ImGui::PopStyleColor();
    }
    if (bigButton("Settings")) { mReturnPanel = P_NONE; openPanel(P_SETTINGS); }
    if (bigButton("Controls & Help")) { mReturnPanel = P_NONE; openPanel(P_HELP); }
    if (bigButton("Quit")) Platform::RequestQuit();
    ImGui::End();
}

void UI::drawLoading() {
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    float W = (float)mW, H = (float)mH;
    dl->AddRectFilled(ImVec2(0, 0), ImVec2(W, H), IM_COL32(12, 14, 18, 255));
    ImGui::PushFont(mBigFont);
    const char* t = "Building Harbor Heights";
    ImVec2 ts = ImGui::CalcTextSize(t);
    dl->AddText(ImVec2(W * 0.5f - ts.x * 0.5f, H * 0.32f), IM_COL32(255, 190, 70, 255), t);
    ImGui::PopFont();
    float p = Saturate(G.loadProgress);
    ImVec2 a(W * 0.2f, H * 0.52f), b(W * 0.8f, H * 0.52f + 18 * mS);
    dl->AddRectFilled(a, b, IM_COL32(40, 44, 52, 255), 6);
    dl->AddRectFilled(a, ImVec2(a.x + (b.x - a.x) * p, b.y), IM_COL32(255, 170, 50, 255), 6);
    char buf[128];
    snprintf(buf, sizeof(buf), "%s... %d%%", G.loadStage.c_str(), (int)(p * 100));
    ImVec2 bs = ImGui::CalcTextSize(buf);
    dl->AddText(ImVec2(W * 0.5f - bs.x * 0.5f, b.y + 14 * mS), IM_COL32(220, 220, 230, 255), buf);
    static const char* tips[] = {
        "Tip: knock out the lower floors and the building above will collapse.",
        "Tip: the wheel loader in the warehouse vault plows through walls.",
        "Tip: put more than 1500 kg on the yellow scale in the warehouse to open the vault.",
        "Tip: start the crane at the construction site and release the wrecking ball.",
        "Tip: the pause menu lets you change gravity, weather and the time of day."};
    int ti = (int)(Platform::TimeSeconds() / 4.0) % 5;
    ImVec2 tsz = ImGui::CalcTextSize(tips[ti]);
    dl->AddText(ImVec2(W * 0.5f - tsz.x * 0.5f, H * 0.75f), IM_COL32(170, 180, 200, 255), tips[ti]);
}

void UI::drawPause() {
    float W = (float)mW, H = (float)mH;
    BeginPanel("Paused", 560 * mS, 640 * mS, W, H);
    if (bigButton("Resume")) openPanel(P_NONE);
    if (bigButton("Spawn menu")) openPanel(P_SPAWN);
    if (bigButton("Teleport / Map")) { mReturnPanel = P_PAUSE; openPanel(P_MAP); }
    if (bigButton("World: gravity, time, weather")) { mReturnPanel = P_PAUSE; openPanel(P_WORLD); }
    if (bigButton("Settings")) { mReturnPanel = P_PAUSE; openPanel(P_SETTINGS); }
    if (bigButton("Controls & Help")) { mReturnPanel = P_PAUSE; openPanel(P_HELP); }
    float hw = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x) * 0.5f;
    if (bigButton("Respawn", hw)) { G.respawnPlayer(); openPanel(P_NONE); }
    ImGui::SameLine();
    if (bigButton("Clear debris", hw)) {
        for (auto& o : G.objs.objects())
            if (o->alive && (o->flags & OBJ_DEBRIS)) G.objs.pendingRemoval.push_back(o.get());
        G.particles.clear();
    }
    if (bigButton("Restart map", hw)) { openPanel(P_NONE); G.startLoading(); }
    ImGui::SameLine();
    if (bigButton("Main menu", hw)) { openPanel(P_NONE); G.returnToMenu(); }
    ImGui::End();
}

void UI::drawWorld() {
    float W = (float)mW, H = (float)mH;
    BeginPanel("World", 640 * mS, 640 * mS, W, H);
    ImGui::BeginChild("##w", ImVec2(0, -mFontPx * 2.6f));
    ImGui::Text("Gravity (now %.2f g)", G.gravityScale);
    float bw = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 3) / 4;
    const char* gn[] = {"Zero", "Moon", "Earth", "Double"};
    const float gv[] = {0.0f, 0.165f, 1.0f, 2.0f};
    for (int i = 0; i < 4; ++i) {
        if (i) ImGui::SameLine();
        if (bigButton(gn[i], bw, mFontPx * 1.7f)) G.setGravityScale(gv[i]);
    }
    float gs = G.gravityScale;
    ImGui::SetNextItemWidth(-1);
    if (ImGui::SliderFloat("##grav", &gs, -0.5f, 3.0f, "gravity x%.2f")) G.setGravityScale(gs);
    ImGui::Separator();
    ImGui::Text("Time scale (slow motion)");
    ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat("##ts", &G.timeScale, 0.1f, 1.0f, "%.2fx");
    ImGui::Separator();
    ImGui::Text("Time of day");
    ImGui::SetNextItemWidth(-1);
    ImGui::SliderFloat("##tod", &G.env.timeOfDay, 0.0f, 23.99f, "%.1f h");
    ImGui::Checkbox("Pause day/night cycle", &G.env.cyclePaused);
    ImGui::Separator();
    ImGui::Text("Weather (%s)", WeatherName(G.env.weather));
    float ww = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 4) / 5;
    for (int i = 0; i < (int)Weather::COUNT; ++i) {
        if (i) ImGui::SameLine();
        if (bigButton(WeatherName((Weather)i), ww, mFontPx * 1.7f)) G.env.setWeather((Weather)i);
    }
    ImGui::Checkbox("Automatic weather changes", &G.env.autoWeather);
    ImGui::Checkbox("Player fly mode (noclip)", &G.player.noclip);
    ImGui::Text("Puzzles solved: %d / %d", G.inter.puzzlesSolved(), G.inter.puzzleCount());
    ImGui::EndChild();
    if (bigButton("Back")) openPanel(mReturnPanel);
    ImGui::End();
}

void UI::drawSettings() {
    float W = (float)mW, H = (float)mH;
    Settings& s = G.settings;
    BeginPanel("Settings", 720 * mS, 680 * mS, W, H);
    ImGui::BeginChild("##set", ImVec2(0, -mFontPx * 2.6f));
    ImGui::SeparatorText("Graphics");
    const char* qn[] = {"Low", "Medium", "High"};
    float bw = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x * 2) / 3;
    for (int q = 0; q < 3; ++q) {
        if (q) ImGui::SameLine();
        bool sel = s.quality == q;
        if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.55f, 0.15f, 1));
        if (bigButton(qn[q], bw, mFontPx * 1.7f)) s.applyPreset(q);
        if (sel) ImGui::PopStyleColor();
    }
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##rs", &s.renderScale, 0.4f, 1.0f, "Resolution %.2f");
    ImGui::Checkbox("Dynamic resolution", &s.dynamicResolution);
    ImGui::Text("FPS limit");
    const int fl[] = {30, 45, 60};
    for (int i = 0; i < 3; ++i) {
        if (i) ImGui::SameLine();
        char b[16]; snprintf(b, sizeof(b), "%d%s", fl[i], s.fpsLimit == fl[i] ? " *" : "");
        if (bigButton(b, bw, mFontPx * 1.6f)) s.fpsLimit = fl[i];
    }
    const char* sq[] = {"Off", "Low", "Medium", "High"};
    ImGui::SetNextItemWidth(-1); ImGui::SliderInt("##sq", &s.shadowQuality, 0, 3, (std::string("Shadows: ") + sq[glm::clamp(s.shadowQuality, 0, 3)]).c_str());
    ImGui::Checkbox("Ambient occlusion (SSAO)", &s.ssao);
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##vd", &s.viewDistance, 50.0f, 200.0f, "View distance %.0f m");
    ImGui::SetNextItemWidth(-1); ImGui::SliderInt("##md", &s.maxDebris, 30, 400, "Max debris bodies %d");
    ImGui::SetNextItemWidth(-1); ImGui::SliderInt("##pb", &s.particleBudget, 300, 4000, "Particle budget %d");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##fov", &s.fov, 55.0f, 95.0f, "Field of view %.0f");
    ImGui::SeparatorText("Controls");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##ls", &s.lookSensitivity, 0.2f, 3.0f, "Camera sensitivity %.2f");
    ImGui::Checkbox("Invert look Y", &s.invertY);
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##jx", &s.joystickX, 0.08f, 0.35f, "Joystick X %.2f");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##jy", &s.joystickY, 0.45f, 0.85f, "Joystick Y %.2f");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##bs", &s.buttonScale, 0.7f, 1.5f, "Button size %.2f");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##us", &s.uiScale, 0.7f, 1.5f, "Menu text size %.2f");
    ImGui::SeparatorText("Audio");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##mv", &s.masterVolume, 0, 1, "Master %.2f");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##sv", &s.sfxVolume, 0, 1, "Effects %.2f");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##av", &s.ambientVolume, 0, 1, "Ambience %.2f");
    ImGui::SetNextItemWidth(-1); ImGui::SliderFloat("##uv", &s.uiVolume, 0, 1, "Interface %.2f");
    ImGui::SeparatorText("Info");
    ImGui::Checkbox("Show FPS", &s.showFps);
    ImGui::Checkbox("Show debug statistics", &s.showDebug);
    ImGui::EndChild();
    if (bigButton("Save & back")) {
        G.applySettings();
        G.saveSettings();
        resize(mW, mH);
        openPanel(mReturnPanel);
    }
    ImGui::End();
    G.applySettings();
}

void UI::drawSpawn() {
    float W = (float)mW, H = (float)mH;
    Sandbox& sb = G.sandbox;
    BeginPanel("Spawn menu", 900 * mS, 640 * mS, W, H);
    float cw = 210 * mS;
    ImGui::BeginChild("##cats", ImVec2(cw, -mFontPx * 2.6f), ImGuiChildFlags_Borders);
    for (int i = 0; i < (int)sb.categories.size(); ++i) {
        bool sel = mCategory == i;
        if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.85f, 0.55f, 0.15f, 1));
        if (bigButton(sb.categories[i].c_str(), -1, mFontPx * 1.8f)) mCategory = i;
        if (sel) ImGui::PopStyleColor();
    }
    ImGui::EndChild();
    ImGui::SameLine();
    ImGui::BeginChild("##items", ImVec2(0, -mFontPx * 2.6f), ImGuiChildFlags_Borders);
    float avail = ImGui::GetContentRegionAvail().x;
    int cols = std::max(1, (int)(avail / (190 * mS)));
    float iw = (avail - ImGui::GetStyle().ItemSpacing.x * (cols - 1)) / cols;
    int col = 0;
    for (int i = 0; i < (int)sb.catalog.size(); ++i) {
        if (mCategory >= (int)sb.categories.size() || sb.catalog[i].category != sb.categories[mCategory]) continue;
        if (col) ImGui::SameLine();
        ImGui::PushID(i);
        bool sel = sb.spawnIndex == i;
        if (sel) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.2f, 0.5f, 0.9f, 1));
        if (bigButton(sb.catalog[i].name.c_str(), iw, mFontPx * 2.6f)) {
            sb.spawnIndex = i;
            if (sb.holding()) sb.grabToggle(G.camPos(), G.camDir());
            sb.tool = TOOL_SPAWN;
            sb.spawnSelected(G.camPos(), G.camDir());
            openPanel(P_NONE);
            G.showToast("Spawned " + sb.catalog[i].name + ". Tap SPAWN button to place more.", 2.5f);
        }
        if (sel) ImGui::PopStyleColor();
        ImGui::PopID();
        col = (col + 1) % cols;
    }
    ImGui::EndChild();
    if (bigButton("Close")) openPanel(P_NONE);
    ImGui::End();
}

void UI::drawMap() {
    float W = (float)mW, H = (float)mH;
    BeginPanel("Teleport", 820 * mS, 640 * mS, W, H);
    float mapSize = std::min(ImGui::GetContentRegionAvail().y - mFontPx * 2.8f, 420 * mS);
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float worldM = VoxelWorld::SX * VOXEL_SIZE;
    auto toMap = [&](vec3 w) { return ImVec2(p0.x + w.x / worldM * mapSize, p0.y + w.z / worldM * mapSize); };
    dl->AddRectFilled(p0, ImVec2(p0.x + mapSize, p0.y + mapSize), IM_COL32(60, 90, 50, 255));
    auto zone = [&](float x0, float z0, float x1, float z1, unsigned c) { dl->AddRectFilled(toMap(vec3(x0, 0, z0) * VOXEL_SIZE), toMap(vec3(x1, 0, z1) * VOXEL_SIZE), c); };
    zone(236, 0, 276, 512, IM_COL32(50, 50, 55, 255));
    zone(0, 236, 512, 276, IM_COL32(50, 50, 55, 255));
    zone(320, 120, 384, 184, IM_COL32(170, 170, 175, 255));
    zone(60, 320, 156, 384, IM_COL32(70, 110, 160, 255));
    zone(156, 290, 228, 430, IM_COL32(70, 70, 75, 255));
    zone(296, 296, 392, 392, IM_COL32(80, 140, 70, 255));
    zone(340, 404, 372, 436, IM_COL32(170, 90, 70, 255));
    zone(440, 296, 488, 344, IM_COL32(150, 150, 150, 255));
    zone(420, 420, 428, 428, IM_COL32(230, 190, 40, 255));
    for (int i : {0, 1, 2, 3, 4}) {
        static const int hz[5][2] = {{40, 170}, {110, 170}, {184, 40}, {184, 100}, {40, 60}};
        bool rot = i == 2 || i == 3;
        zone((float)hz[i][0], (float)hz[i][1], (float)hz[i][0] + (rot ? 32 : 40), (float)hz[i][1] + (rot ? 40 : 32), IM_COL32(160, 110, 80, 255));
    }
    vec3 pp = G.driving ? G.driving->position() : G.player.feet();
    dl->AddCircleFilled(toMap(pp), 7 * mS, IM_COL32(255, 60, 60, 255));
    for (size_t i = 0; i < G.map.landmarks.size(); ++i) dl->AddCircle(toMap(G.map.landmarks[i].first), 5 * mS, IM_COL32(255, 255, 255, 255));
    ImGui::Dummy(ImVec2(mapSize, mapSize));
    ImGui::SameLine();
    ImGui::BeginChild("##lm", ImVec2(0, mapSize));
    for (size_t i = 0; i < G.map.landmarks.size(); ++i) {
        ImGui::PushID((int)i);
        if (bigButton(G.map.landmarks[i].second.c_str(), -1, mFontPx * 1.8f)) { G.teleportTo((int)i); openPanel(P_NONE); }
        ImGui::PopID();
    }
    ImGui::EndChild();
    if (bigButton("Back")) openPanel(mReturnPanel);
    ImGui::End();
}

void UI::drawHelp() {
    float W = (float)mW, H = (float)mH;
    BeginPanel("Controls & Help", 820 * mS, 640 * mS, W, H);
    ImGui::BeginChild("##help", ImVec2(0, -mFontPx * 2.6f));
    ImGui::TextWrapped(
        "MOVE: left joystick (touch anywhere on the lower left). LOOK: drag on the right half of the screen.\n"
        "JUMP / RUN: buttons near the joystick and lower right.\n"
        "USE: appears when looking at a switch, door or vehicle. Switches control elevators, gates, lights and the crane.\n\n"
        "TOOLS (top bar):\n"
        "  Hand - Grab / Drop, Throw, Rot (drag to rotate the held object), Far / Near hold distance.\n"
        "         When not holding: Big / Small scale, Copy duplicates, Del deletes, Lock freezes in place.\n"
        "  Hammer - hold Smash to break walls voxel by voxel.\n"
        "  Cannon - fires heavy iron balls.  Bomb - places a timed explosive.  Rocket - explodes on impact.\n"
        "  Spawn - places the item chosen in the SPAWN menu (furniture, construction parts, physics toys, vehicles, crash dummies).\n\n"
        "VEHICLES: walk up and press USE. Joystick steers and accelerates, GAS / BRAKE (hold BRAKE when stopped to reverse), HB handbrake, "
        "Lift / Lower for the forklift fork and loader bucket, Bed+ / Bed- tips the dump truck, Flip resets an overturned vehicle.\n\n"
        "DESTRUCTION: every building is made of voxels (25 cm). Remove supports and unsupported sections break off and fall. "
        "Glass shatters easily, wood splinters, concrete and brick need heavy hits, steel is very tough.\n\n"
        "PUZZLES: put more than 1500 kg on the yellow scale in the warehouse to open the vault. "
        "At the construction site start the crane and release the wrecking ball. Use the apartment elevator to reach the roof.\n\n"
        "PAUSE menu: gravity, slow motion, weather, time of day, teleport, settings. Android back button opens / closes menus.");
    ImGui::EndChild();
    if (bigButton("Back")) openPanel(mReturnPanel);
    ImGui::End();
}

void UI::renderLoadingOnly() {
    if (std::abs(mBuiltFontPx - mFontPx) > 0.5f) buildFonts();
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)mW, (float)mH);
    io.DeltaTime = 1.0f / 60.0f;
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    ImGui::PushFont(mFont);
    drawLoading();
    ImGui::PopFont();
    ImGui::Render();
    glViewport(0, 0, mW, mH);
    glClearColor(0.05f, 0.05f, 0.07f, 1);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

void UI::render(float dt) {
    if (std::abs(mBuiltFontPx - mFontPx) > 0.5f) buildFonts();
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)mW, (float)mH);
    io.DeltaTime = std::max(dt, 1e-4f);
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    ImGui::PushFont(mFont);
    if (G.state == GameState::MainMenu) {
        if (mPanel == P_SETTINGS) { ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), io.DisplaySize, IM_COL32(15, 18, 24, 255)); drawSettings(); }
        else if (mPanel == P_HELP) { ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), io.DisplaySize, IM_COL32(15, 18, 24, 255)); drawHelp(); }
        else drawMainMenu();
    } else if (G.state == GameState::Loading) {
        drawLoading();
    } else {
        if (mPanel == P_NONE) drawHud();
        else {
            ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(0, 0), io.DisplaySize, IM_COL32(0, 0, 0, 90));
            switch (mPanel) {
            case P_PAUSE: drawPause(); break;
            case P_SETTINGS: drawSettings(); break;
            case P_SPAWN: drawSpawn(); break;
            case P_MAP: drawMap(); break;
            case P_HELP: drawHelp(); break;
            case P_WORLD: drawWorld(); break;
            default: break;
            }
        }
    }
    ImGui::PopFont();
    ImGui::Render();
    glViewport(0, 0, mW, mH);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}
