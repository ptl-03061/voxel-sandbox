// Shared lighting code (prepended to lit fragment shaders).
precision highp float;
precision highp int;
precision highp sampler2DArray;
precision highp sampler2DShadow;

uniform vec3 uSunDir;        // direction towards the sun
uniform vec3 uSunColor;
uniform vec3 uSkyColor;
uniform vec3 uHorizonColor;
uniform vec3 uGroundColor;
uniform vec3 uFogColor;
uniform float uFogDensity;
uniform float uFogHeight;
uniform vec3 uCamPos;
uniform mat4 uLightVP;
uniform sampler2DShadow uShadowMap;
uniform float uShadowTexel;
uniform float uShadowEnabled;
uniform int uNumLights;
uniform vec4 uLightPos[8];   // xyz pos, w radius
uniform vec4 uLightColor[8];
uniform float uWetness;
uniform float uNight;        // 0 day .. 1 night
uniform float uTime;
uniform sampler2DArray uDetailTex;
uniform sampler2DArray uNormalTex;

const float PI = 3.14159265;

vec3 skyGradient(vec3 d) {
    float h = clamp(d.y, -1.0, 1.0);
    vec3 col = mix(uHorizonColor, uSkyColor, pow(clamp(h, 0.0, 1.0), 0.45));
    col = mix(col, uGroundColor * 0.6, clamp(-h * 3.0, 0.0, 1.0));
    float sd = max(dot(d, uSunDir), 0.0);
    col += uSunColor * (pow(sd, 8.0) * 0.12 + pow(sd, 64.0) * 0.25);
    return col;
}

float shadowFactor(vec3 P, vec3 N) {
    if (uShadowEnabled < 0.5) return 1.0;
    vec3 sp = P + N * 0.06;
    vec4 lc = uLightVP * vec4(sp, 1.0);
    vec3 c = lc.xyz / lc.w * 0.5 + 0.5;
    if (c.x <= 0.0 || c.x >= 1.0 || c.y <= 0.0 || c.y >= 1.0 || c.z >= 1.0) return 1.0;
    float bias = 0.0012;
    float s = 0.0;
    vec2 o = vec2(uShadowTexel);
    s += texture(uShadowMap, vec3(c.xy + vec2(-0.5, -0.5) * o * 1.5, c.z - bias));
    s += texture(uShadowMap, vec3(c.xy + vec2( 0.5, -0.5) * o * 1.5, c.z - bias));
    s += texture(uShadowMap, vec3(c.xy + vec2(-0.5,  0.5) * o * 1.5, c.z - bias));
    s += texture(uShadowMap, vec3(c.xy + vec2( 0.5,  0.5) * o * 1.5, c.z - bias));
    s *= 0.25;
    // fade shadows at the edge of the shadow volume
    vec2 e = abs(c.xy - 0.5) * 2.0;
    float fade = smoothstep(0.85, 1.0, max(e.x, e.y));
    return mix(s, 1.0, fade);
}

float D_GGX(float NdH, float a) { float a2 = a * a; float d = NdH * NdH * (a2 - 1.0) + 1.0; return a2 / (PI * d * d + 1e-5); }
float G_Smith(float NdV, float NdL, float r) { float k = (r + 1.0) * (r + 1.0) / 8.0; return (NdV / (NdV * (1.0 - k) + k)) * (NdL / (NdL * (1.0 - k) + k)); }
vec3 F_Schlick(float c, vec3 f0) { return f0 + (1.0 - f0) * pow(1.0 - c, 5.0); }

vec3 brdf(vec3 albedo, vec3 N, vec3 V, vec3 L, vec3 radiance, float rough, float metal) {
    vec3 H = normalize(V + L);
    float NdL = max(dot(N, L), 0.0);
    if (NdL <= 0.0) return vec3(0.0);
    float NdV = max(dot(N, V), 0.001);
    float NdH = max(dot(N, H), 0.0);
    vec3 f0 = mix(vec3(0.04), albedo, metal);
    vec3 F = F_Schlick(max(dot(H, V), 0.0), f0);
    float a = max(rough * rough, 0.02);
    vec3 spec = D_GGX(NdH, a) * G_Smith(NdV, NdL, rough) * F / (4.0 * NdV * NdL + 1e-4);
    vec3 kd = (1.0 - F) * (1.0 - metal);
    return (kd * albedo / PI + spec) * radiance * NdL;
}

vec3 shadeSurface(vec3 albedo, vec3 N, vec3 P, float rough, float metal, float ao, float emissive) {
    vec3 V = normalize(uCamPos - P);
    // wet surfaces get darker and shinier when facing upwards
    float wet = uWetness * clamp(N.y, 0.0, 1.0);
    albedo *= 1.0 - 0.35 * wet;
    rough = mix(rough, 0.12, wet * 0.85);
    float sh = shadowFactor(P, N);
    vec3 col = brdf(albedo, N, V, uSunDir, uSunColor * 3.2, rough, metal) * sh;
    // hemispheric ambient
    float hemi = N.y * 0.5 + 0.5;
    vec3 amb = mix(uGroundColor, uSkyColor, hemi) * 0.9 + uHorizonColor * 0.15;
    vec3 f0 = mix(vec3(0.04), albedo, metal);
    vec3 kd = (1.0 - f0) * (1.0 - metal);
    col += amb * albedo * kd * ao;
    // environment reflection approximation
    vec3 R = reflect(-V, N);
    vec3 env = skyGradient(R);
    float fres = pow(1.0 - max(dot(N, V), 0.0), 5.0);
    vec3 specEnv = env * mix(f0, vec3(1.0), fres) * (1.0 - rough) * (1.0 - rough);
    col += specEnv * ao * (0.6 + 0.4 * metal);
    // local point lights
    for (int i = 0; i < 8; ++i) {
        if (i >= uNumLights) break;
        vec3 Lv = uLightPos[i].xyz - P;
        float d = length(Lv);
        float r = uLightPos[i].w;
        if (d > r) continue;
        float att = pow(clamp(1.0 - d / r, 0.0, 1.0), 2.0) / (1.0 + d * d * 0.2);
        col += brdf(albedo, N, V, Lv / d, uLightColor[i].rgb * att * 6.0, rough, metal) + albedo * uLightColor[i].rgb * att * 0.08 * ao;
    }
    col += albedo * emissive;
    return col;
}

vec3 applyFog(vec3 col, vec3 P) {
    vec3 d = P - uCamPos;
    float dist = length(d);
    float hf = exp(-max(P.y - uFogHeight, 0.0) * 0.08);
    float f = 1.0 - exp(-dist * uFogDensity * (0.35 + 0.65 * hf));
    vec3 fc = mix(uFogColor, skyGradient(normalize(d)), 0.35);
    return mix(col, fc, clamp(f, 0.0, 1.0));
}

vec3 tonemap(vec3 x) {
    // ACES fitted
    x *= 0.9;
    vec3 c = clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
    return pow(c, vec3(1.0 / 2.2));
}
