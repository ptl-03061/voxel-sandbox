precision highp float;
in vec2 vUV;
in vec4 vColor;
flat in int vType;
in vec3 vWorld;
out vec4 fragColor;
void main() {
    float a = 1.0;
    if (vType == 0) { float r = length(vUV); a = smoothstep(1.0, 0.2, r); }
    else if (vType == 1) { a = (1.0 - abs(vUV.x)) * smoothstep(1.0, 0.6, abs(vUV.y)); }
    fragColor = vec4(vColor.rgb, vColor.a * a);
}
