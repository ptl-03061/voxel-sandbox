layout(location = 0) in vec4 aPos;   // voxel units (int16)
layout(location = 1) in vec4 aData;  // normal index, material, ao, flags

uniform mat4 uModel;
uniform mat4 uViewProj;
uniform float uVoxelSize;
uniform vec3 uOffset;               // voxel offset of this mesh inside its parent volume

out vec3 vWorld;
out vec3 vLocal;
out vec3 vN;
flat out int vNormalIdx;
flat out int vMat;
out float vAO;

const vec3 NORMALS[6] = vec3[6](vec3(1,0,0), vec3(-1,0,0), vec3(0,1,0), vec3(0,-1,0), vec3(0,0,1), vec3(0,0,-1));

void main() {
    vec3 local = aPos.xyz + uOffset;
    vec4 wp = uModel * vec4(local * uVoxelSize, 1.0);
    vWorld = wp.xyz;
    vLocal = local;
    int ni = int(aData.x + 0.5);
    vNormalIdx = ni;
    vN = mat3(uModel) * NORMALS[ni];
    vMat = int(aData.y + 0.5);
    vAO = aData.z / 3.0;
    gl_Position = uViewProj * wp;
}
