in vec3 vWorld;
in vec3 vN;
in vec3 vObj;
in vec4 vColor;
in vec4 vParams;   // roughness, metallic, emissive, texture layer

uniform float uEmissiveScale;
out vec4 fragColor;

void main() {
    vec3 N = normalize(vN);
    vec3 albedo = vColor.rgb;
    float rough = vParams.x;
    if (vParams.w > 0.5) {
        // world-space triplanar detail
        vec3 w = abs(N); w /= (w.x + w.y + w.z);
        vec4 d = texture(uDetailTex, vec3(vWorld.zy, vParams.w)) * w.x
               + texture(uDetailTex, vec3(vWorld.xz, vParams.w)) * w.y
               + texture(uDetailTex, vec3(vWorld.xy, vParams.w)) * w.z;
        albedo *= d.rgb * 2.0;
        rough = clamp(rough + d.a - 0.5, 0.03, 1.0);
    }
    vec3 col = shadeSurface(albedo, N, vWorld, rough, vParams.y, 1.0, vParams.z * (vParams.z > 5.0 ? 1.0 : uEmissiveScale));
    col = applyFog(col, vWorld);
    fragColor = vec4(tonemap(col), vColor.a);
}
