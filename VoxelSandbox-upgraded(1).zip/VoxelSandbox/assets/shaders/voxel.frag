in vec3 vWorld;
in vec3 vLocal;
in vec3 vN;
flat in int vNormalIdx;
flat in int vMat;
in float vAO;

uniform vec4 uMatColor[40];   // rgb albedo, a jitter
uniform vec4 uMatParams[40];  // roughness, metallic, emissive, texture layer
uniform vec4 uMatExtra[40];   // x: transparent
uniform float uVoxelSize;
uniform float uEmissiveScale;
uniform float uGlassPass;
uniform mat4 uModel;
uniform vec4 uTint;           // object tint (rgb multiply, a = highlight)

out vec4 fragColor;

const vec3 NORMALS[6] = vec3[6](vec3(1,0,0), vec3(-1,0,0), vec3(0,1,0), vec3(0,-1,0), vec3(0,0,1), vec3(0,0,-1));

uint hash3(ivec3 p) {
    uint h = uint(p.x) * 73856093u ^ uint(p.y) * 19349663u ^ uint(p.z) * 83492791u;
    h ^= h >> 13; h *= 0x5bd1e995u; h ^= h >> 15;
    return h;
}

void main() {
    vec4 mc = uMatColor[vMat];
    vec4 mp = uMatParams[vMat];
    vec3 nl = NORMALS[vNormalIdx];
    ivec3 cell = ivec3(floor(vLocal - nl * 0.5));
    float h = float(hash3(cell) & 1023u) / 1023.0;
    vec3 albedo = mc.rgb * (1.0 + (h - 0.5) * 2.0 * mc.a);

    // face-aligned texture coordinates in meters
    vec3 lm = vLocal * uVoxelSize;
    vec2 uv; vec3 T; vec3 B;
    if (vNormalIdx < 2) { uv = lm.zy; T = vec3(0,0,1); B = vec3(0,1,0); }
    else if (vNormalIdx < 4) { uv = lm.xz; T = vec3(1,0,0); B = vec3(0,0,1); }
    else { uv = lm.xy; T = vec3(1,0,0); B = vec3(0,1,0); }
    float layer = mp.w;
    vec4 det = texture(uDetailTex, vec3(uv, layer));
    vec3 nm = texture(uNormalTex, vec3(uv, layer)).xyz * 2.0 - 1.0;
    albedo *= det.rgb * 2.0;
    float rough = clamp(mp.x + (det.a - 0.5), 0.03, 1.0);
    vec3 nLocal = normalize(T * nm.x + B * nm.y + nl * max(nm.z, 0.2));
    vec3 N = normalize(mat3(uModel) * nLocal);
    albedo *= uTint.rgb;

    float ao = mix(0.35, 1.0, vAO);
    vec3 col = shadeSurface(albedo, N, vWorld, rough, mp.y, ao, mp.z * uEmissiveScale);
    col += uTint.a * vec3(0.25, 0.22, 0.05);
    col = applyFog(col, vWorld);
    float alpha = 1.0;
    if (uGlassPass > 0.5) {
        vec3 V = normalize(uCamPos - vWorld);
        float fres = pow(1.0 - abs(dot(N, V)), 3.0);
        alpha = clamp(0.28 + fres * 0.6, 0.0, 0.92);
    }
    fragColor = vec4(tonemap(col), alpha);
}
