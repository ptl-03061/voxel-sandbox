in vec2 vNdc;
uniform mat4 uInvViewProj;
uniform float uCloudCover;
out vec4 fragColor;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float noise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) { float s = 0.0, a = 0.5; for (int i = 0; i < 5; ++i) { s += a * noise(p); p *= 2.03; a *= 0.5; } return s; }

void main() {
    vec4 a = uInvViewProj * vec4(vNdc, -1.0, 1.0);
    vec4 b = uInvViewProj * vec4(vNdc, 1.0, 1.0);
    vec3 d = normalize(b.xyz / b.w - a.xyz / a.w);
    vec3 col = skyGradient(d);
    float sd = max(dot(d, uSunDir), 0.0);
    col += uSunColor * smoothstep(0.9993, 0.9997, sd) * 6.0;         // sun disc
    // moon opposite the sun
    float md = max(dot(d, -uSunDir), 0.0);
    col += vec3(0.7, 0.75, 0.85) * smoothstep(0.9994, 0.9997, md) * uNight * 1.5;
    if (d.y > 0.0) {
        // stars
        vec2 sp = d.xz / (d.y + 0.2) * 220.0;
        float st = step(0.9965, hash(floor(sp))) * uNight * smoothstep(0.0, 0.3, d.y);
        col += vec3(st) * (0.6 + 0.4 * sin(uTime * 3.0 + hash(floor(sp)) * 20.0));
        // clouds
        vec2 cp = d.xz / (d.y + 0.08) * 1.4 + vec2(uTime * 0.01, uTime * 0.004);
        float c = fbm(cp);
        float cover = smoothstep(1.0 - uCloudCover - 0.2, 1.0 - uCloudCover + 0.35, c);
        vec3 cloudCol = mix(uHorizonColor * 0.9 + uSunColor * 0.25, vec3(0.35, 0.37, 0.42) * (1.0 - uNight * 0.85), uCloudCover * 0.8);
        col = mix(col, cloudCol, cover * smoothstep(0.0, 0.15, d.y) * 0.9);
    }
    col = mix(col, uFogColor, clamp(uFogDensity * 18.0, 0.0, 0.85) * (1.0 - smoothstep(0.0, 0.4, d.y)));
    fragColor = vec4(tonemap(col), 1.0);
}
