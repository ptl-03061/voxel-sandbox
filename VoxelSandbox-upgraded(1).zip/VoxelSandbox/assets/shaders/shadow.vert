// Depth-only shader used for both voxel meshes (uInstanced = 0) and instanced meshes.
layout(location = 0) in vec4 aPos;
layout(location = 2) in vec4 iM0;
layout(location = 3) in vec4 iM1;
layout(location = 4) in vec4 iM2;
layout(location = 5) in vec4 iM3;

uniform mat4 uViewProj;
uniform mat4 uModel;
uniform float uVoxelSize;
uniform vec3 uOffset;
uniform float uInstanced;

void main() {
    if (uInstanced > 0.5) {
        mat4 m = mat4(iM0, iM1, iM2, iM3);
        gl_Position = uViewProj * (m * vec4(aPos.xyz, 1.0));
    } else {
        gl_Position = uViewProj * (uModel * vec4((aPos.xyz + uOffset) * uVoxelSize, 1.0));
    }
}
