layout(location = 0) in vec2 aCorner;
layout(location = 1) in vec4 iPosSize;
layout(location = 2) in vec4 iColor;
layout(location = 3) in vec4 iExtra;   // x: type (0 soft, 1 streak, 2 hard), y: rotation

uniform mat4 uViewProj;
uniform vec3 uCamRight;
uniform vec3 uCamUp;
uniform vec3 uCamPos;

out vec2 vUV;
out vec4 vColor;
flat out int vType;
out vec3 vWorld;

void main() {
    int type = int(iExtra.x + 0.5);
    vec3 right = uCamRight, up = uCamUp;
    float sx = iPosSize.w, sy = iPosSize.w;
    if (type == 1) {
        vec3 toCam = normalize(uCamPos - iPosSize.xyz);
        up = vec3(0, 1, 0);
        right = normalize(cross(up, toCam));
        sy = iPosSize.w * 14.0;
    }
    float c = cos(iExtra.y), s = sin(iExtra.y);
    vec2 rc = vec2(aCorner.x * c - aCorner.y * s, aCorner.x * s + aCorner.y * c);
    if (type == 1) rc = aCorner;
    vec3 wp = iPosSize.xyz + right * rc.x * sx + up * rc.y * sy;
    vUV = aCorner;
    vColor = iColor;
    vType = type;
    vWorld = wp;
    gl_Position = uViewProj * vec4(wp, 1.0);
}
