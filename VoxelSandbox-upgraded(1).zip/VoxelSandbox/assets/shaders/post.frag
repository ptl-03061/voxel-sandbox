precision highp float;
in vec2 vUV;
uniform sampler2D uColor;
uniform sampler2D uDepth;
uniform vec2 uScale;        // dynamic resolution scale (portion of the target used)
uniform vec2 uTexel;        // 1 / target size
uniform float uSSAO;
uniform float uNear;
uniform float uFar;
uniform float uFlash;       // explosion / lightning flash
uniform float uDamageVignette;
out vec4 fragColor;

float linDepth(float d) { float z = d * 2.0 - 1.0; return (2.0 * uNear * uFar) / (uFar + uNear - z * (uFar - uNear)); }

void main() {
    vec2 uv = vUV * uScale;
    vec3 col = texture(uColor, uv).rgb;
    if (uSSAO > 0.5) {
        float d0 = linDepth(texture(uDepth, uv).r);
        if (d0 < 60.0) {
            float occ = 0.0;
            float rad = clamp(2.2 / d0, 0.004, 0.05);
            const int N = 8;
            for (int i = 0; i < N; ++i) {
                float ang = float(i) * 2.39996 + 0.5;
                float r = rad * (0.35 + 0.65 * fract(float(i) * 0.618));
                vec2 o = vec2(cos(ang), sin(ang)) * r * vec2(uScale.y / uScale.x * uTexel.y / uTexel.x, 1.0) * uScale;
                float ds = linDepth(texture(uDepth, uv + o).r);
                float diff = d0 - ds;
                occ += smoothstep(0.03, 0.25, diff) * (1.0 - smoothstep(0.6, 1.6, diff));
            }
            col *= 1.0 - (occ / float(N)) * 0.55;
        }
    }
    // FXAA-lite edge smoothing using luminance contrast
    vec2 t = uTexel;
    vec3 n1 = texture(uColor, uv + vec2(t.x, 0.0)).rgb;
    vec3 n2 = texture(uColor, uv - vec2(t.x, 0.0)).rgb;
    vec3 n3 = texture(uColor, uv + vec2(0.0, t.y)).rgb;
    vec3 n4 = texture(uColor, uv - vec2(0.0, t.y)).rgb;
    vec3 lw = vec3(0.299, 0.587, 0.114);
    float l0 = dot(col, lw);
    float lmin = min(l0, min(min(dot(n1, lw), dot(n2, lw)), min(dot(n3, lw), dot(n4, lw))));
    float lmax = max(l0, max(max(dot(n1, lw), dot(n2, lw)), max(dot(n3, lw), dot(n4, lw))));
    float edge = smoothstep(0.08, 0.3, lmax - lmin);
    col = mix(col, (col * 2.0 + n1 + n2 + n3 + n4) / 6.0, edge * 0.6);
    // grading + vignette
    col = mix(vec3(dot(col, lw)), col, 1.08);
    vec2 c = vUV - 0.5;
    float vig = 1.0 - dot(c, c) * 0.55;
    col *= vig;
    col = mix(col, vec3(0.6, 0.1, 0.05), uDamageVignette * smoothstep(0.2, 0.7, length(c)));
    col += vec3(uFlash);
    fragColor = vec4(col, 1.0);
}
