// Bounding-box proxy used for hardware occlusion queries.
layout(location = 0) in vec3 aPos;
uniform mat4 uViewProj;
uniform vec3 uMin;
uniform vec3 uMax;
void main() {
    vec3 p = mix(uMin, uMax, aPos + 0.5);
    gl_Position = uViewProj * vec4(p, 1.0);
}
